"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const HTTPError_1 = require("../models/HTTPError");
const Enum_1 = require("../utils/Enum");
class TestStationService {
    constructor(testStationDAO) {
        this.getTestStationEmails = (pNumber) => {
            return this.testStationDAO.getTestStationEmailByPNumber(pNumber)
                .then((data) => {
                if (data.Count === 0) {
                    throw new HTTPError_1.HTTPError(404, Enum_1.ERRORS.RESOURCE_NOT_FOUND);
                }
                return data.Items;
            })
                .catch((error) => {
                if (!(error instanceof HTTPError_1.HTTPError)) {
                    console.log(error);
                    error.statusCode = 500;
                    error.body = Enum_1.ERRORS.INTERNAL_SERVER_ERROR;
                }
                throw new HTTPError_1.HTTPError(error.statusCode, error.body);
            });
        };
        this.testStationDAO = testStationDAO;
    }
    /**
     * Fetch a list of all test stations (ATFs) from DynamoDB
     */
    getTestStationList() {
        return this.testStationDAO.getAll(Enum_1.TEST_STATION_STATUS.ACTIVE)
            .then((data) => {
            if (data.Count === 0) {
                throw new HTTPError_1.HTTPError(404, Enum_1.ERRORS.RESOURCE_NOT_FOUND);
            }
            return data.Items;
        })
            .catch((error) => {
            if (!(error instanceof HTTPError_1.HTTPError)) {
                console.log(error);
                error.statusCode = 500;
                error.body = Enum_1.ERRORS.INTERNAL_SERVER_ERROR;
            }
            throw new HTTPError_1.HTTPError(error.statusCode, error.body);
        });
    }
    /**
     * Add the provided Test Stations (ATFs) details to the DB. Currently unused.
     * @param testStationItems (TestStation array)
     */
    insertTestStation(testStationItem) {
        return this.testStationDAO.createItem(testStationItem)
            .then((data) => {
            if (data.UnprocessedItems) {
                return data.UnprocessedItems;
            }
        })
            .catch((error) => {
            if (error) {
                console.error(error);
            }
            throw new HTTPError_1.HTTPError(500, Enum_1.ERRORS.INTERNAL_SERVER_ERROR);
        });
    }
    /**
     * Add the provided Test Stations (ATFs) details to the DB. Currently unused.
     * @param testStationItem: new body of the test station
     * @param id: the id of the test station being updated
     */
    updateTestStation(testStationItem, id) {
        const transactExpression = {
            ConditionExpression: "testStationId = :testStationId",
            ExpressionAttributeValues: {
                ":testStationId": id
            }
        };
        return this.testStationDAO.transactWrite(testStationItem, transactExpression)
            .then((data) => {
            if (data.UnprocessedItems) {
                return data.UnprocessedItems;
            }
        })
            .catch((error) => {
            if (error) {
                console.error(error);
            }
            throw new HTTPError_1.HTTPError(500, error);
        });
    }
    /**
     * Remove specified Test Stations from the DB
     * @param testStationItemsKeys
     */
    deleteTestStationsList(testStationItemsKeys) {
        return this.testStationDAO.deleteMultiple(testStationItemsKeys)
            .then((data) => {
            if (data.UnprocessedItems) {
                return data.UnprocessedItems;
            }
        })
            .catch((error) => {
            if (error) {
                console.error(error);
            }
            throw new HTTPError_1.HTTPError(500, Enum_1.ERRORS.INTERNAL_SERVER_ERROR);
        });
    }
}
exports.TestStationService = TestStationService;
