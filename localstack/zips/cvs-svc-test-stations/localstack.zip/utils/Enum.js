"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ERRORS;
(function (ERRORS) {
    ERRORS["RESOURCE_NOT_FOUND"] = "No resources match the search criteria.";
    ERRORS["INTERNAL_SERVER_ERROR"] = "Internal Server Error";
    ERRORS["DYNAMODB_CONFIG_NOT_DEFINED"] = "DynamoDB config is not defined in the config file.";
    ERRORS["FUNCTION_CONFIG_NOT_DEFINED"] = "Functions were not defined in the config file.";
})(ERRORS = exports.ERRORS || (exports.ERRORS = {}));
var HTTPRESPONSE;
(function (HTTPRESPONSE) {
    HTTPRESPONSE["AWS_EVENT_EMPTY"] = "AWS event is empty. Check your test event.";
    HTTPRESPONSE["NOT_VALID_JSON"] = "Body is not a valid JSON.";
})(HTTPRESPONSE = exports.HTTPRESPONSE || (exports.HTTPRESPONSE = {}));
var TEST_STATION_STATUS;
(function (TEST_STATION_STATUS) {
    TEST_STATION_STATUS["ACTIVE"] = "active";
})(TEST_STATION_STATUS = exports.TEST_STATION_STATUS || (exports.TEST_STATION_STATUS = {}));
var RESPONSE_STATUS;
(function (RESPONSE_STATUS) {
    RESPONSE_STATUS["SUCCESS"] = "success";
})(RESPONSE_STATUS = exports.RESPONSE_STATUS || (exports.RESPONSE_STATUS = {}));
