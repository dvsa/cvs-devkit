"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Configuration_1 = require("../utils/Configuration");
/* workaround AWSXRay.captureAWS(...) call obscures types provided by the AWS sdk.
https://github.com/aws/aws-xray-sdk-node/issues/14
*/
/* tslint:disable */
let AWS;
// TODO: Temporarily disable xray as localstack won't allow it unless we have the pro version 
// if (process.env._X_AMZN_TRACE_ID) {
//   AWS = require("aws-xray-sdk").captureAWS(require("aws-sdk"));
// } else {
//   console.log("Serverless Offline detected; skipping AWS X-Ray setup");
// }
AWS = require("aws-sdk");
/* tslint:enable */
class TestStationDAO {
    constructor() {
        const config = Configuration_1.Configuration.getInstance().getDynamoDBConfig();
        this.tableName = config.table;
        if (!TestStationDAO.dbClient) {
            TestStationDAO.dbClient = new AWS.DynamoDB.DocumentClient(config.params);
        }
    }
    /**
     * Get all email addresses for a given test station ID
     * @param testStationPNumber
     */
    getTestStationEmailByPNumber(testStationPNumber) {
        const params = {
            TableName: this.tableName,
            IndexName: "testStationPNumberIndex",
            KeyConditionExpression: "#testStationPNumber = :testStationPNumber",
            ExpressionAttributeNames: {
                "#testStationPNumber": "testStationPNumber"
            },
            ExpressionAttributeValues: {
                ":testStationPNumber": testStationPNumber
            }
        };
        return TestStationDAO.dbClient.query(params).promise();
    }
    /**
     * Get All test stations in the DB, filtered by status
     * If the statusFilter is set to null, get all test stations
     * @returns ultimately, an array of TestStation objects, wrapped in a PromiseResult, wrapped in a Promise
     */
    getAll(statusFilter) {
        let scanParams = { TableName: this.tableName };
        if (statusFilter) {
            const filter = {
                FilterExpression: "#testStationStatus = :testStationStatus",
                ExpressionAttributeNames: {
                    "#testStationStatus": "testStationStatus",
                },
                ExpressionAttributeValues: {
                    ":testStationStatus": statusFilter,
                }
            };
            scanParams = Object.assign(Object.assign({}, scanParams), filter);
        }
        return TestStationDAO.dbClient.scan(scanParams).promise();
    }
    /**
     * Write data about multiple Test Stations to the DB.
     * @param testStationItems: ITestStation[]
     * @returns DynamoDB BatchWriteItemOutput, wrapped in promises
     */
    createMultiple(testStationItems) {
        const params = this.generatePartialParams();
        testStationItems.map((testStationItem) => {
            params.RequestItems[this.tableName].push({
                PutRequest: {
                    Item: testStationItem
                }
            });
        });
        return TestStationDAO.dbClient.batchWrite(params).promise();
    }
    /**
     * Write data about multiple Test Stations to the DB.
     * @param testStationItem: ITestStation[]
     * @returns DynamoDB BatchWriteItemOutput, wrapped in promises
     */
    createItem(testStationItem) {
        const params = {
            TableName: this.tableName,
            Item: testStationItem,
            ConditionExpression: "attribute_not_exists(testStationId)"
        };
        return TestStationDAO.dbClient.put(params).promise();
    }
    /**
     * Removes multiple Test Stations from the DB
     * @param primaryKeysToBeDeleted
     */
    deleteMultiple(primaryKeysToBeDeleted) {
        const params = this.generatePartialParams();
        primaryKeysToBeDeleted.forEach((key) => {
            params.RequestItems[this.tableName].push({
                DeleteRequest: {
                    Key: {
                        testStationId: key
                    }
                }
            });
        });
        return TestStationDAO.dbClient.batchWrite(params).promise();
    }
    /**
     * Performs a write transaction on the specified table.
     * @param item - the item to be inserted or updated during the transaciton.
     * @param oldItem - the current item that already exists in the database.
     */
    transactWrite(item, transactExpression) {
        const query = {
            TransactItems: [
                {
                    Put: {
                        TableName: this.tableName,
                        Item: item,
                        ConditionExpression: transactExpression.ConditionExpression,
                        ExpressionAttributeValues: transactExpression.ExpressionAttributeValues
                    }
                }
            ]
        };
        return TestStationDAO.dbClient.transactWrite(query).promise();
    }
    /**
     * Internal method for getting a common parameter template
     */
    generatePartialParams() {
        return {
            RequestItems: {
                [this.tableName]: Array()
            }
        };
    }
}
exports.TestStationDAO = TestStationDAO;
