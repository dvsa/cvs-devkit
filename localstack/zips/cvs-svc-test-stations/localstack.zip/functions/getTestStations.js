"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const TestStationService_1 = require("../services/TestStationService");
const TestStationDAO_1 = require("../models/TestStationDAO");
const HTTPResponse_1 = require("../models/HTTPResponse");
const HTTPError_1 = require("../models/HTTPError");
exports.getTestStations = async () => {
    const testStationDAO = new TestStationDAO_1.TestStationDAO();
    const service = new TestStationService_1.TestStationService(testStationDAO);
    return service.getTestStationList()
        .then((data) => {
        return new HTTPResponse_1.HTTPResponse(200, data);
    })
        .catch((error) => {
        console.error(error);
        return new HTTPError_1.HTTPError(error.statusCode, error.body);
    });
};
