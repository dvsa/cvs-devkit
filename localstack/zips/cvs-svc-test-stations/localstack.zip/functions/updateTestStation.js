"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const TestStationService_1 = require("../services/TestStationService");
const TestStationDAO_1 = require("../models/TestStationDAO");
const HTTPResponse_1 = require("../models/HTTPResponse");
const HTTPError_1 = require("../models/HTTPError");
exports.updateTestStation = async (event) => {
    var _a;
    console.log("Event: ", event);
    const testStationDAO = new TestStationDAO_1.TestStationDAO();
    const service = new TestStationService_1.TestStationService(testStationDAO);
    const testStationId = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.testStationId;
    return service.updateTestStation(event.body, testStationId)
        .then((data) => {
        return new HTTPResponse_1.HTTPResponse(202, data);
    })
        .catch((error) => {
        console.error(error);
        throw new HTTPError_1.HTTPError(error.statusCode, error.body);
    });
};
