"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const TestStationService_1 = require("../services/TestStationService");
const TestStationDAO_1 = require("../models/TestStationDAO");
const HTTPResponse_1 = require("../models/HTTPResponse");
const HTTPError_1 = require("../models/HTTPError");
exports.createTestStation = async (event) => {
    console.log("Event: ", event);
    const testStationDAO = new TestStationDAO_1.TestStationDAO();
    const service = new TestStationService_1.TestStationService(testStationDAO);
    return service.insertTestStation(event.body)
        .then((data) => {
        return new HTTPResponse_1.HTTPResponse(202, data);
    })
        .catch((error) => {
        console.error(error);
        throw new HTTPError_1.HTTPError(error.statusCode, error.body);
    });
};
