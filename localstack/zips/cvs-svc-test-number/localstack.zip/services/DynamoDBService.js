"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoDBService = void 0;
const Configuration_1 = require("../utils/Configuration");
/* tslint:disable */
let AWS;
// TODO: Temp disabling xray as it is not given by the free localstack version
// if (process.env._X_AMZN_TRACE_ID) {
//     AWS = require("aws-xray-sdk").captureAWS(require("aws-sdk"));
// } else {
//     console.log("Serverless Offline detected; skipping AWS X-Ray setup")
//     AWS = require("aws-sdk");
// }
AWS = require("aws-sdk");
/* tslint:enable */
class DynamoDBService {
    /**
     * Constructor for the DynamoDBService
     */
    constructor() {
        const config = Configuration_1.Configuration.getInstance().getDynamoDBConfig();
        this.tableName = config.table;
        if (!DynamoDBService.client) {
            console.log("config for DynamoDB Client: ", config.params);
            DynamoDBService.client = new AWS.DynamoDB.DocumentClient(config.params);
        }
    }
    /**
     * Scan the entire table and retrieve all data
     * @returns Promise<PromiseResult<DocumentClient.ScanOutput, AWS.AWSError>>
     */
    scan() {
        return DynamoDBService.client.scan({ TableName: this.tableName })
            .promise();
    }
    /**
     * Retrieves the item with the given key
     * @param key - the key of the item you wish to fetch
     * @param attributes - optionally, you can request only a set of attributes
     * @returns Promise<PromiseResult<DocumentClient.GetItemOutput, AWS.AWSError>>
     */
    get(key, attributes) {
        const query = {
            TableName: this.tableName,
            Key: key,
        };
        if (attributes) {
            Object.assign(query, { AttributesToGet: attributes });
        }
        return DynamoDBService.client.get(query)
            .promise();
    }
    /**
     * Replaces the provided item, or inserts it if it does not exist
     * @param item - item to be inserted or updated
     * @returns Promise<PromiseResult<DocumentClient.PutItemOutput, AWS.AWSError>>
     */
    put(item) {
        const query = {
            TableName: this.tableName,
            Item: item,
            ReturnValues: "ALL_OLD",
            ConditionExpression: "testNumber <> :testNumberVal",
            ExpressionAttributeValues: {
                ":testNumberVal": item.testNumber
            }
        };
        return DynamoDBService.client.put(query)
            .promise();
    }
    /**
     * Deletes the item with the given key and returns the item deleted
     * @param key - the key of the item you wish to delete
     * @returns Promise<PromiseResult<DocumentClient.DeleteItemOutput, AWS.AWSError>>
     */
    delete(key) {
        const query = {
            TableName: this.tableName,
            Key: key,
            ReturnValues: "ALL_OLD",
        };
        return DynamoDBService.client.delete(query)
            .promise();
    }
    /**
     * Retrieves a list of batches containing results for the given keys
     * @param keys - a list of keys you wish to retrieve
     * @returns Promise<PromiseResult<BatchGetItemOutput, AWS.AWSError>>
     */
    batchGet(keys) {
        const keyList = keys.slice();
        const keyBatches = [];
        while (keyList.length > 0) {
            keyBatches.push(keyList.splice(0, 100));
        }
        const promiseBatch = keyBatches.map((batch) => {
            const query = {
                RequestItems: {
                    [this.tableName]: {
                        Keys: batch,
                    },
                },
            };
            return DynamoDBService.client.batchGet(query)
                .promise();
        });
        return Promise.all(promiseBatch);
    }
    /**
     * Updates or creates the items provided, and returns a list of result batches
     * @param items - items to add or update
     * @returns Promise<PromiseResult<DocumentClient.BatchWriteItemOutput, AWS.AWSError>[]>
     */
    batchPut(items) {
        const itemList = items.slice();
        const itemBatches = [];
        while (itemList.length > 0) {
            itemBatches.push(itemList.splice(0, 25));
        }
        const promiseBatch = itemBatches.map((batch) => {
            const query = {
                RequestItems: {
                    [this.tableName]: batch.map((item) => ({ PutRequest: { Item: item } })),
                },
            };
            return DynamoDBService.client.batchWrite(query)
                .promise();
        });
        return Promise.all(promiseBatch);
    }
    /**
     * Deletes the items provided, and returns a list of result batches
     * @param keys - keys for the items to delete
     * @returns Promise<PromiseResult<DocumentClient.BatchWriteItemOutput, AWS.AWSError>[]>
     */
    batchDelete(keys) {
        const keyList = keys.slice();
        const keyBatches = [];
        while (keyList.length > 0) {
            keyBatches.push(keyList.splice(0, 25));
        }
        const promiseBatch = keyBatches.map((batch) => {
            const query = {
                RequestItems: {
                    [this.tableName]: batch.map((item) => ({ DeleteRequest: { Key: item } })),
                },
            };
            return DynamoDBService.client.batchWrite(query)
                .promise();
        });
        return Promise.all(promiseBatch);
    }
    /**
     * Performs a write transaction on the specified table.
     * @param item - the item to be inserted or updated during the transaciton.
     * @param oldItem - the current item that already exists in the database.
     */
    transactWrite(item, transactExpression) {
        const query = {
            TransactItems: [
                {
                    Put: {
                        TableName: this.tableName,
                        Item: item,
                        ConditionExpression: transactExpression.ConditionExpression,
                        ExpressionAttributeValues: transactExpression.ExpressionAttributeValues
                    }
                }
            ]
        };
        return DynamoDBService.client.transactWrite(query).promise();
    }
}
exports.DynamoDBService = DynamoDBService;
