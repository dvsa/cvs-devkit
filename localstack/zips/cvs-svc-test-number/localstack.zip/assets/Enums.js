"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NUMBER_KEY = exports.NUMBER_TYPE = void 0;
var NUMBER_TYPE;
(function (NUMBER_TYPE) {
    NUMBER_TYPE["TRAILER_ID"] = "trailerId";
    NUMBER_TYPE["TEST_NUMBER"] = "testNumber";
    NUMBER_TYPE["SYSTEM_NUMBER"] = "systemNumber";
})(NUMBER_TYPE = exports.NUMBER_TYPE || (exports.NUMBER_TYPE = {}));
var NUMBER_KEY;
(function (NUMBER_KEY) {
    NUMBER_KEY[NUMBER_KEY["TEST_NUMBER"] = 1] = "TEST_NUMBER";
    NUMBER_KEY[NUMBER_KEY["TRAILER_ID"] = 2] = "TRAILER_ID";
    NUMBER_KEY[NUMBER_KEY["SYSTEM_NUMBER"] = 3] = "SYSTEM_NUMBER";
})(NUMBER_KEY = exports.NUMBER_KEY || (exports.NUMBER_KEY = {}));
