"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Configuration = void 0;
// @ts-ignore
const yml = __importStar(require("node-yaml"));
var HTTPMethods;
(function (HTTPMethods) {
    HTTPMethods["GET"] = "GET";
    HTTPMethods["POST"] = "POST";
    HTTPMethods["PUT"] = "PUT";
    HTTPMethods["DELETE"] = "DELETE";
})(HTTPMethods || (HTTPMethods = {}));
class Configuration {
    constructor(configPath) {
        this.config = yml.readSync(configPath);
        // Replace environment variable references
        let stringifiedConfig = JSON.stringify(this.config);
        const envRegex = /\${(\w+\b):?(\w+\b)?}/g;
        const matches = stringifiedConfig.match(envRegex);
        if (matches) {
            matches.forEach((match) => {
                envRegex.lastIndex = 0;
                const captureGroups = envRegex.exec(match);
                // Insert the environment variable if available. If not, insert placeholder. If no placeholder, leave it as is.
                stringifiedConfig = stringifiedConfig.replace(match, (process.env[captureGroups[1]] || captureGroups[2] || captureGroups[1]));
            });
        }
        this.config = JSON.parse(stringifiedConfig);
    }
    /**
     * Retrieves the singleton instance of Configuration
     * @returns Configuration
     */
    static getInstance() {
        if (!this.instance) {
            this.instance = new Configuration("../config/config.yml");
        }
        return Configuration.instance;
    }
    /**
     * Retrieves the entire config as an object
     * @returns any
     */
    getConfig() {
        return this.config;
    }
    /**
     * Retrieves the lambda functions declared in the config
     * @returns IFunctionEvent[]
     */
    getFunctions() {
        if (!this.config.functions) {
            throw new Error("Functions were not defined in the config file.");
        }
        return this.config.functions.map((fn) => {
            const [name, params] = Object.entries(fn)[0];
            const path = (params.proxy) ? params.path.replace("{+proxy}", params.proxy) : params.path;
            return {
                name,
                method: params.method.toUpperCase(),
                path,
                function: require(`../functions/${name}`)[name]
            };
        });
    }
    /**
     * Retrieves the DynamoDB config
     * @returns any
     */
    getDynamoDBConfig() {
        if (!this.config.dynamodb) {
            throw new Error("DynamoDB config is not defined in the config file.");
        }
        // Not defining BRANCH will default to remote
        let env;
        switch (process.env.BRANCH) {
            case "local":
                env = "local";
                break;
            case "local-global":
                env = "local-global";
                break;
            case "localstack":
                env = "localstack";
                break;
            default:
                env = "remote";
        }
        return this.config.dynamodb[env];
    }
    /**
     * Retrieves the test number initial value
     * @returns any
     */
    getTestNumberInitialValue() {
        return this.config.testNumberinitialValue;
    }
    /**
     * Retrieves the trailer id initial value
     * @returns any
     */
    getTrailerIdInitialValue() {
        return this.config.trailerIdInitialValue;
    }
    /**
     * Retrieves the system number initial value
     * @returns any
     */
    getSystemNumberInitialValue() {
        return this.config.systemNumberInitialValue;
    }
    /**
     * Retrieves the test number initial value
     * @returns number
     */
    getMaxAttempts() {
        return this.config.maxAttempts;
    }
}
exports.Configuration = Configuration;
