"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateTrailerId = void 0;
const NumberService_1 = require("../services/NumberService");
const HTTPResponse_1 = require("../utils/HTTPResponse");
const DynamoDBService_1 = require("../services/DynamoDBService");
const generateTrailerId = async (event, context) => {
    const numberService = new NumberService_1.NumberService(new DynamoDBService_1.DynamoDBService());
    return numberService.createTrailerId(1, null)
        .then((trailerId) => {
        return new HTTPResponse_1.HTTPResponse(200, trailerId);
    })
        .catch((error) => {
        console.log(error.body);
        return error;
    });
};
exports.generateTrailerId = generateTrailerId;
