"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateTestNumber = void 0;
const NumberService_1 = require("../services/NumberService");
const HTTPResponse_1 = require("../utils/HTTPResponse");
const DynamoDBService_1 = require("../services/DynamoDBService");
const generateTestNumber = async (event, context) => {
    const numberService = new NumberService_1.NumberService(new DynamoDBService_1.DynamoDBService());
    return numberService.createTestNumber(1, null)
        .then((testNumber) => {
        return new HTTPResponse_1.HTTPResponse(200, testNumber);
    })
        .catch((error) => {
        console.log(error.body);
        return error;
    });
};
exports.generateTestNumber = generateTestNumber;
