"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authorizer = void 0;
const StatementBuilder_1 = __importDefault(require("../services/StatementBuilder"));
const signature_check_1 = require("../services/signature-check");
const roles_1 = require("../services/roles");
const tokens_1 = require("../services/tokens");
const configuration_1 = require("../services/configuration");
const http_verbs_1 = require("../services/http-verbs");
/**
 * Lambda custom authorizer function to verify whether a JWT has been provided
 * and to verify its integrity and validity.
 * @param event - AWS Lambda event object
 * @param context - AWS Lambda Context object
 * @returns - Promise<APIGatewayAuthorizerResult>
 */
exports.authorizer = async (event, context) => {
    try {
        // fail-fast if config is missing or invalid
        const config = await configuration_1.configuration();
        const jwt = tokens_1.getValidJwt(event.authorizationToken);
        const validRoles = roles_1.getValidRoles(jwt);
        if (validRoles.length === 0) {
            reportNoValidRoles(jwt, event, context);
            return unauthorisedPolicy();
        }
        // by this point we know authorizationToken meets formatting requirements
        // remove 'Bearer ' when verifying signature
        await signature_check_1.checkSignature(event.authorizationToken.substring(7), jwt);
        let statements = [];
        for (const role of validRoles) {
            const items = roleToStatements(role, config);
            statements = statements.concat(items);
        }
        return {
            principalId: jwt.payload.sub,
            policyDocument: newPolicyDocument(statements)
        };
    }
    catch (error) {
        console.error(error.message);
        dumpArguments(event, context);
        return unauthorisedPolicy();
    }
};
const roleToStatements = (role, config) => {
    const associatedResources = configuration_1.getAssociatedResources(role, config);
    let statements = [];
    for (const associatedResource of associatedResources) {
        const parts = associatedResource.substring(1).split('/');
        const resource = parts[0];
        let childResource = null;
        if (parts.length > 1) {
            childResource = parts.slice(1).join('/');
        }
        if (role.access === 'read') {
            statements = statements.concat(readRoleToStatements(resource, childResource));
        }
        else {
            statements.push(writeRoleToStatement(resource, childResource));
        }
    }
    return statements;
};
const readRoleToStatements = (resource, childResource) => {
    const statements = [];
    for (const httpVerb of http_verbs_1.availableHttpVerbs()) {
        if (http_verbs_1.isSafe(httpVerb)) {
            statements.push(new StatementBuilder_1.default()
                .setEffect('Allow')
                .setHttpVerb(httpVerb)
                .setResource(resource)
                .setChildResource(childResource)
                .build());
        }
    }
    return statements;
};
const writeRoleToStatement = (resource, childResource) => {
    return new StatementBuilder_1.default()
        .setEffect('Allow')
        .setHttpVerb('*')
        .setResource(resource)
        .setChildResource(childResource)
        .build();
};
const unauthorisedPolicy = () => {
    const statements = [
        new StatementBuilder_1.default()
            .setEffect('Deny')
            .build()
    ];
    return {
        principalId: 'Unauthorised',
        policyDocument: newPolicyDocument(statements)
    };
};
const newPolicyDocument = (statements) => {
    return {
        Version: '2012-10-17',
        Statement: statements
    };
};
const reportNoValidRoles = (jwt, event, context) => {
    const roles = jwt.payload.roles;
    if (roles && roles.length === 0) {
        console.error('no valid roles on token (token has no roles at all)');
    }
    else {
        console.error(`no valid roles on token (${roles.length} invalid role(s): ${roles})`);
    }
    dumpArguments(event, context);
};
const dumpArguments = (event, context) => {
    console.error('Event dump  : ', JSON.stringify(event));
    console.error('Context dump: ', JSON.stringify(context));
};
