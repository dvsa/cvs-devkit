"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const authorizer_1 = require("./functions/authorizer");
Object.defineProperty(exports, "handler", { enumerable: true, get: function () { return authorizer_1.authorizer; } });
