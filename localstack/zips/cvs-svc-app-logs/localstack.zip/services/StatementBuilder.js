"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const resource_arn_1 = require("./resource-arn");
const env_utils_1 = require("./env-utils");
// see https://docs.aws.amazon.com/apigateway/latest/developerguide/api-gateway-lambda-authorizer-output.html
class StatementBuilder {
    constructor() {
        this.effect = 'Deny';
        this.action = 'execute-api:Invoke';
        // Resource fields
        this.regionId = env_utils_1.getEnvVar('AWS_REGION', 'eu-west-1');
        this.accountId = env_utils_1.getEnvVar('AWS_ACCOUNT_ID', '*');
        this.apiId = env_utils_1.getEnvVar('AWS_APIG_ID', '*');
        this.stage = env_utils_1.getEnvVar('AWS_APIG_STAGE', '*');
        this.httpVerb = '*';
        this.resource = null;
        this.childResource = null;
    }
    /**
     * Setter for the Statement's Effect
     * @param effect - the effect of this Statement
     * @returns StatementBuilder
     */
    setEffect(effect) {
        this.effect = effect;
        return this;
    }
    /**
     * Setter for the Statement's Action
     * @param action - action for this statement
     * @returns StatementBuilder
     */
    setAction(action) {
        this.action = action;
        return this;
    }
    /**
     * Setter for the Statement's resource region
     * @param regionId - the ARN's region
     * @returns StatementBuilder
     */
    setRegionId(regionId) {
        this.regionId = regionId;
        return this;
    }
    /**
     * Setter for the Statement's resource account-id
     * @param accountId - the ARN's account-id
     * @returns StatementBuilder
     */
    setAccountId(accountId) {
        this.accountId = accountId;
        return this;
    }
    /**
     * Setter for the Statement's resource API id
     * @param apiId - the ARN's API id
     * @returns StatementBuilder
     */
    setApiId(apiId) {
        this.apiId = apiId;
        return this;
    }
    /**
     * Setter for the Statement's resource stage-name
     * @param stage - the ARN's stage-name
     * @returns StatementBuilder
     */
    setStage(stage) {
        this.stage = stage;
        return this;
    }
    /**
     * Setter for the Statement's resource HTTP verb
     * @param httpVerb - the ARN's HTTP verb
     * @returns StatementBuilder
     */
    setHttpVerb(httpVerb) {
        this.httpVerb = httpVerb;
        return this;
    }
    /**
     * Setter for the Statement's resource path specifier
     * @param resource - the ARN's path specifier
     * @returns StatementBuilder
     */
    setResource(resource) {
        this.resource = resource;
        return this;
    }
    /**
     * Setter for the Statement's child resource path specifier
     * @param childResource - the ARN's child path specifier
     * @returns StatementBuilder
     */
    setChildResource(childResource) {
        this.childResource = childResource;
        return this;
    }
    /**
     * Builder method to return the built Statement
     * @returns the Statement that has been built
     */
    build() {
        const resourceArn = resource_arn_1.arnToString({
            region: this.regionId,
            accountId: this.accountId,
            apiId: this.apiId,
            stage: this.stage,
            httpVerb: this.httpVerb,
            resource: this.resource,
            childResource: this.childResource
        });
        return {
            Action: this.action,
            Effect: this.effect,
            Resource: resourceArn
        };
    }
}
exports.default = StatementBuilder;
