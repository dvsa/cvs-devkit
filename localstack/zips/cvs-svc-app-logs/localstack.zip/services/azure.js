"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCertificateChain = void 0;
const axios_1 = __importDefault(require("axios"));
exports.getCertificateChain = async (tenantId, keyId) => {
    const keys = await getKeys(tenantId);
    const certificateChain = keys.get(keyId);
    if (!certificateChain) {
        throw new Error(`no public key with ID '${keyId}' under tenant ${tenantId}`);
    }
    return certificateChain;
};
const getKeys = async (tenantId) => {
    const response = await axios_1.default.get(`https://login.microsoftonline.com/${tenantId}/discovery/keys`);
    const map = new Map();
    for (const key of response.data.keys) {
        const keyId = key.kid;
        const certificateChain = `-----BEGIN CERTIFICATE-----\n${key.x5c[0]}\n-----END CERTIFICATE-----`;
        map.set(keyId, certificateChain);
    }
    return map;
};
