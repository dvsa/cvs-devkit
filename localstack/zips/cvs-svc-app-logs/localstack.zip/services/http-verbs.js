"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isSafe = exports.toHttpVerb = exports.availableHttpVerbs = void 0;
const httpVerbs = [
    '*',
    'HEAD',
    'OPTIONS',
    'GET',
    'POST',
    'PUT',
    'PATCH',
    'DELETE',
    'TRACE'
];
exports.availableHttpVerbs = () => {
    return httpVerbs;
};
exports.toHttpVerb = (candidate) => {
    if (!httpVerbs.includes(candidate.toUpperCase())) {
        throw new Error(`not a recognized HTTP verb: '${candidate}'`);
    }
    return candidate.toUpperCase();
};
// "safe" defined as per RFC2616, section 9
exports.isSafe = (httpVerb) => {
    return httpVerb === 'GET' || httpVerb === 'HEAD';
};
