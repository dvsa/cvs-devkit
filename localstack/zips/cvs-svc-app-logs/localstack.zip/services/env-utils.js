"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getEnvVar = void 0;
exports.getEnvVar = (envVar, defaultValue) => {
    const value = process.env[envVar];
    if (!value || !value.trim()) {
        return defaultValue;
    }
    return value;
};
