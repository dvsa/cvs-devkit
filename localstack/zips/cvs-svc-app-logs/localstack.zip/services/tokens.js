"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getValidJwt = void 0;
const JWT = __importStar(require("jsonwebtoken"));
exports.getValidJwt = (authorizationToken) => {
    checkFormat(authorizationToken);
    authorizationToken = authorizationToken.substring(7); // remove 'Bearer '
    const decoded = JWT.decode(authorizationToken, { complete: true });
    if (!decoded) {
        throw new Error('JWT.decode failed, input is likely not a JWT');
    }
    return decoded;
};
const checkFormat = (authorizationToken) => {
    if (!authorizationToken) {
        throw new Error('no caller-supplied-token (no authorization header on original request)');
    }
    const [bearerPrefix, token] = authorizationToken.split(' ');
    if ('Bearer' !== bearerPrefix) {
        throw new Error('caller-supplied-token must start with \'Bearer \' (case-sensitive)');
    }
    if (!token || !token.trim()) {
        throw new Error('\'Bearer \' prefix present, but token is blank or missing');
    }
};
