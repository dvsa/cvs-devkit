"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const TestTypesDAO_1 = __importDefault(require("../models/TestTypesDAO"));
const TestTypesService_1 = require("../services/TestTypesService");
const HTTPResponse_1 = require("../models/HTTPResponse");
exports.getTestTypes = async () => {
    const testTypesDAO = new TestTypesDAO_1.default();
    const testTypesService = new TestTypesService_1.TestTypesService(testTypesDAO);
    // GET /test-types
    return testTypesService.getTestTypesList()
        .then((data) => {
        return new HTTPResponse_1.HTTPResponse(200, data);
    })
        .catch((error) => {
        return new HTTPResponse_1.HTTPResponse(error.statusCode, error.body);
    });
};
