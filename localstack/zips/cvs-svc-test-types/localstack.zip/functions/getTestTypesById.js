"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const TestTypesDAO_1 = __importDefault(require("../models/TestTypesDAO"));
const TestTypesService_1 = require("../services/TestTypesService");
const HTTPResponse_1 = require("../models/HTTPResponse");
const joi_1 = __importDefault(require("joi"));
const parseMissingQueryParams_1 = require("../utils/parseMissingQueryParams");
const ITestType_1 = require("../models/ITestType");
const Enums_1 = require("../assets/Enums");
exports.getTestTypesById = (event, context, callback) => {
    const testTypesDAO = new TestTypesDAO_1.default();
    const testTypesService = new TestTypesService_1.TestTypesService(testTypesDAO);
    // Validate query parameters
    const queryParamSchema = joi_1.default.object().keys({
        fields: joi_1.default.string().regex(/^(testTypeClassification|defaultTestCode|linkedTestCode),?\s*((testTypeClassification|defaultTestCode|linkedTestCode),?\s*)?((testTypeClassification|defaultTestCode|linkedTestCode),?\s*)?$/).required(),
        vehicleType: joi_1.default.string().only(Object.values(ITestType_1.ForVehicleType)).required(),
        vehicleSize: joi_1.default.string().only(Object.values(ITestType_1.ForVehicleSize)),
        vehicleConfiguration: joi_1.default.string().only(Object.values(ITestType_1.ForVehicleConfiguration)).allow(null),
        euVehicleCategory: joi_1.default.string().allow(null),
        vehicleClass: joi_1.default.string().allow(null),
        vehicleSubclass: joi_1.default.string().allow(null),
        vehicleWheels: joi_1.default.number().min(0).max(99).allow(null),
        vehicleAxles: joi_1.default.number().min(0).max(99).allow(null)
    }).strict();
    const queryParams = parseMissingQueryParams_1.parseAndCastQueryParams(event.queryStringParameters, Object.values(Enums_1.NUM_PARAMETERS));
    const validation = joi_1.default.validate(queryParams, queryParamSchema);
    if (validation.error) {
        return Promise.resolve(new HTTPResponse_1.HTTPResponse(400, `Query parameter ${validation.error.details[0].message}`));
    }
    // Splitting fields into an array and cleaning up unwanted whitespace
    Object.assign(queryParams, { fields: queryParams.fields.replace(/\s/g, "").split(",") });
    return testTypesService.getTestTypesById(event.pathParameters.id, queryParams)
        .then((data) => {
        return new HTTPResponse_1.HTTPResponse(200, data);
    })
        .catch((error) => {
        return new HTTPResponse_1.HTTPResponse(error.statusCode, error.body);
    });
};
