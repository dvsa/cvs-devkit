"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ERRORS;
(function (ERRORS) {
    ERRORS["NotifyConfigNotDefined"] = "The Notify config is not defined in the config file.";
    ERRORS["DynamoDBConfigNotDefined"] = "DynamoDB config is not defined in the config file.";
    ERRORS["LambdaInvokeConfigNotDefined"] = "Lambda Invoke config is not defined in the config file.";
    ERRORS["EventIsEmpty"] = "Event is empty";
    ERRORS["NoBranch"] = "Please define BRANCH environment variable";
    ERRORS["InternalServerError"] = "Internal Server Error";
})(ERRORS = exports.ERRORS || (exports.ERRORS = {}));
var HTTPRESPONSE;
(function (HTTPRESPONSE) {
    HTTPRESPONSE["AWS_EVENT_EMPTY"] = "AWS event is empty. Check your test event.";
    HTTPRESPONSE["NOT_VALID_JSON"] = "Body is not a valid JSON.";
    HTTPRESPONSE["RESOURCE_NOT_FOUND"] = "No resources match the search criteria.";
})(HTTPRESPONSE = exports.HTTPRESPONSE || (exports.HTTPRESPONSE = {}));
var HTTPMethods;
(function (HTTPMethods) {
    HTTPMethods["GET"] = "GET";
    HTTPMethods["POST"] = "POST";
    HTTPMethods["PUT"] = "PUT";
    HTTPMethods["DELETE"] = "DELETE";
})(HTTPMethods = exports.HTTPMethods || (exports.HTTPMethods = {}));
var NUM_PARAMETERS;
(function (NUM_PARAMETERS) {
    NUM_PARAMETERS["VEHICLE_AXLES"] = "vehicleAxles";
    NUM_PARAMETERS["VEHICLE_WHEELS"] = "vehicleWheels";
})(NUM_PARAMETERS = exports.NUM_PARAMETERS || (exports.NUM_PARAMETERS = {}));
