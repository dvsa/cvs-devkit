"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ForVehicleConfiguration;
(function (ForVehicleConfiguration) {
    ForVehicleConfiguration["Articulated"] = "articulated";
    ForVehicleConfiguration["Rigid"] = "rigid";
    ForVehicleConfiguration["CentreAxleDrawbar"] = "centre axle drawbar";
    ForVehicleConfiguration["SemiCarTransporter"] = "semi-car transporter";
    ForVehicleConfiguration["SemiTrailer"] = "semi-trailer";
    ForVehicleConfiguration["LowLoader"] = "low loader";
    ForVehicleConfiguration["Other"] = "other";
    ForVehicleConfiguration["Drawbar"] = "drawbar";
    ForVehicleConfiguration["FourInLine"] = "four-in-line";
    ForVehicleConfiguration["Dolly"] = "dolly";
    ForVehicleConfiguration["FullDrawbar"] = "full drawbar";
})(ForVehicleConfiguration = exports.ForVehicleConfiguration || (exports.ForVehicleConfiguration = {}));
var ForVehicleSize;
(function (ForVehicleSize) {
    ForVehicleSize["Small"] = "small";
    ForVehicleSize["Large"] = "large";
})(ForVehicleSize = exports.ForVehicleSize || (exports.ForVehicleSize = {}));
var ForVehicleType;
(function (ForVehicleType) {
    ForVehicleType["Hgv"] = "hgv";
    ForVehicleType["Psv"] = "psv";
    ForVehicleType["Trl"] = "trl";
    ForVehicleType["Car"] = "car";
    ForVehicleType["Lgv"] = "lgv";
    ForVehicleType["Motorcycle"] = "motorcycle";
})(ForVehicleType = exports.ForVehicleType || (exports.ForVehicleType = {}));
var ForEuVehicleCategory;
(function (ForEuVehicleCategory) {
    ForEuVehicleCategory["N2"] = "n2";
    ForEuVehicleCategory["N3"] = "n3";
    ForEuVehicleCategory["O1"] = "o1";
    ForEuVehicleCategory["O2"] = "o2";
    ForEuVehicleCategory["O3"] = "o3";
    ForEuVehicleCategory["O4"] = "o4";
})(ForEuVehicleCategory = exports.ForEuVehicleCategory || (exports.ForEuVehicleCategory = {}));
var ForVehicleSubclass;
(function (ForVehicleSubclass) {
    ForVehicleSubclass["A"] = "a";
    ForVehicleSubclass["C"] = "c";
    ForVehicleSubclass["S"] = "s";
    ForVehicleSubclass["L"] = "l";
    ForVehicleSubclass["M"] = "m";
    ForVehicleSubclass["N"] = "n";
    ForVehicleSubclass["P"] = "p";
    ForVehicleSubclass["T"] = "t";
    ForVehicleSubclass["R"] = "r";
})(ForVehicleSubclass = exports.ForVehicleSubclass || (exports.ForVehicleSubclass = {}));
var TestTypeClassification;
(function (TestTypeClassification) {
    TestTypeClassification["AnnualNOCERTIFICATE"] = "Annual NO CERTIFICATE";
    TestTypeClassification["AnnualWithCertificate"] = "Annual With Certificate";
    TestTypeClassification["NonAnnual"] = "NON ANNUAL";
})(TestTypeClassification = exports.TestTypeClassification || (exports.TestTypeClassification = {}));
