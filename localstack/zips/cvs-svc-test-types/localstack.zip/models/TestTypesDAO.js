"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Configuration_1 = require("../utils/Configuration");
/* tslint:disable */
let AWS;
// TODO: Temporarily disabling it as pro version of localstack is required for it otherwise teraform won't deploy
// if (process.env._X_AMZN_TRACE_ID) {
//   AWS = require("aws-xray-sdk").captureAWS(require("aws-sdk"));
// } else {
//   console.log("Serverless Offline detected; skipping AWS X-Ray setup")
//   AWS = require("aws-sdk");
// }
AWS = require("aws-sdk");
/* tslint:enable */
class TestTypesDAO {
    constructor() {
        const config = Configuration_1.Configuration.getInstance().getDynamoDBConfig();
        this.tableName = config.table;
        if (!TestTypesDAO.dbClient) {
            TestTypesDAO.dbClient = new AWS.DynamoDB.DocumentClient(config.params);
        }
    }
    /**
     * Get All test Types  in the DB
     * @returns ultimately, an array of TestTypes objects, wrapped in a PromiseResult, wrapped in a Promise
     */
    getAll() {
        return TestTypesDAO.dbClient.scan({ TableName: this.tableName }).promise();
    }
    /**
    * Write data about multiple Test Types to the DB.
    * @param testTypesItems: ITestType[]
    * @returns DynamoDB BatchWriteItemOutput, wrapped in promises
    */
    createMultiple(testTypesItems) {
        const params = this.generatePartialParams();
        testTypesItems.forEach((testTypesItem) => {
            params.RequestItems[this.tableName].push({
                PutRequest: {
                    Item: testTypesItem
                }
            });
        });
        return TestTypesDAO.dbClient.batchWrite(params).promise();
    }
    /**
     * Removes multiple Test Types from the DB
     * @param primaryKeysToBeDeleted
     */
    deleteMultiple(primaryKeysToBeDeleted) {
        const params = this.generatePartialParams();
        primaryKeysToBeDeleted.forEach((compositeKey) => {
            params.RequestItems[this.tableName].push({
                DeleteRequest: {
                    Key: {
                        id: compositeKey[0],
                        name: compositeKey[1]
                    }
                }
            });
        });
        return TestTypesDAO.dbClient.batchWrite(params).promise();
    }
    /**
    * Internal method for getting a common parameter template
    */
    generatePartialParams() {
        return {
            RequestItems: {
                [this.tableName]: Array()
            }
        };
    }
}
exports.default = TestTypesDAO;
