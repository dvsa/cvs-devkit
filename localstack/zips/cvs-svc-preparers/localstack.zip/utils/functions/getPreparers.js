"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const PreparersDAO_1 = __importDefault(require("../models/PreparersDAO"));
const PreparersService_1 = __importDefault(require("../services/PreparersService"));
const HTTPResponse_1 = __importDefault(require("../models/HTTPResponse"));
const getPreparers = () => {
    const preparersDAO = new PreparersDAO_1.default();
    const preparersService = new PreparersService_1.default(preparersDAO);
    return preparersService.getPreparersList()
        .then((data) => {
        return new HTTPResponse_1.default(200, data);
    })
        .catch((error) => {
        return new HTTPResponse_1.default(error.statusCode, error.body);
    });
};
exports.default = getPreparers;
//# sourceMappingURL=getPreparers.js.map