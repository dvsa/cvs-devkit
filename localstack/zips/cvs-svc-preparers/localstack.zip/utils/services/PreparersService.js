"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const HTTPError_1 = __importDefault(require("../models/HTTPError"));
/**
 * Fetches the entire list of preparers from the database.
 * @returns Promise
 */
class PreparersService {
    constructor(preparersDAO) {
        this.preparersDAO = preparersDAO;
    }
    getPreparersList() {
        return this.preparersDAO.getAll()
            .then((data) => {
            if (data.Count === 0) {
                throw new HTTPError_1.default(404, "No resources match the search criteria.");
            }
            return data.Items;
        })
            .catch((error) => {
            if (!(error instanceof HTTPError_1.default)) {
                console.log(error);
                error.statusCode = 500;
                error.body = "Internal Server Error";
            }
            throw new HTTPError_1.default(error.statusCode, error.body);
        });
    }
    insertPreparerList(preparerItems) {
        return this.preparersDAO.createMultiple(preparerItems)
            .then((data) => {
            if (data.UnprocessedItems) {
                return data.UnprocessedItems;
            }
        })
            .catch((error) => {
            if (error) {
                console.error(error);
            }
            else {
                console.error("An unknown error occurred during preparersDAO.createMultiple - promise rejected but no message returned");
            }
            throw new HTTPError_1.default(500, "Internal Server Error");
        });
    }
    deletePreparerList(preparerItemKeys) {
        return this.preparersDAO.deleteMultiple(preparerItemKeys)
            .then((data) => {
            if (data.UnprocessedItems) {
                return data.UnprocessedItems;
            }
        })
            .catch((error) => {
            if (error) {
                console.error(error);
            }
            else {
                console.error("An unknown error occurred during preparersDAO.deleteMultiple - promise rejected but no message returned");
            }
            throw new HTTPError_1.default(500, "Internal Server Error");
        });
    }
}
exports.default = PreparersService;
//# sourceMappingURL=PreparersService.js.map