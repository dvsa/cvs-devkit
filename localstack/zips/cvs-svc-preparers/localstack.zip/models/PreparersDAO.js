"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Configuration_1 = require("../utils/Configuration");
/* workaround AWSXRay.captureAWS(...) call obscures types provided by the AWS sdk.
https://github.com/aws/aws-xray-sdk-node/issues/14
*/
/* tslint:disable */
let AWS;
// TODO: temp disable as it requires pro version from localstack
// if (process.env._X_AMZN_TRACE_ID) {
//   AWS = require('aws-xray-sdk').captureAWS(require('aws-sdk'));
// } else {
//   console.log('Serverless Offline detected; skipping AWS X-Ray setup');
//   AWS = require('aws-sdk');
// }
AWS = require('aws-sdk');
/* tslint:enable */
class PreparersDAO {
    constructor() {
        const config = Configuration_1.Configuration.getInstance().getDynamoDBConfig();
        this.tableName = config.table;
        if (!PreparersDAO.docClient) {
            PreparersDAO.docClient = new AWS.DynamoDB.DocumentClient(config.params);
        }
    }
    getAll() {
        return PreparersDAO.docClient.scan({ TableName: this.tableName }).promise();
    }
    createMultiple(preparerItems) {
        const params = this.generatePartialParams();
        preparerItems.forEach((preparerItem) => {
            params.RequestItems[this.tableName].push({
                PutRequest: {
                    Item: preparerItem
                }
            });
        });
        return PreparersDAO.docClient.batchWrite(params).promise();
    }
    deleteMultiple(primaryKeysToBeDeleted) {
        const params = this.generatePartialParams();
        primaryKeysToBeDeleted.forEach((key) => {
            params.RequestItems[this.tableName].push({
                DeleteRequest: {
                    Key: {
                        preparerId: key
                    }
                }
            });
        });
        return PreparersDAO.docClient.batchWrite(params).promise();
    }
    generatePartialParams() {
        return {
            RequestItems: {
                [this.tableName]: []
            }
        };
    }
}
exports.default = PreparersDAO;
