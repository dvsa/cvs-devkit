"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GetActivityService = void 0;
const enums_1 = require("./../assets/enums");
const Filters_1 = require("./../utils/Filters");
const HTTPResponse_1 = require("../utils/HTTPResponse");
const enums_2 = require("../assets/enums");
const moment_1 = __importDefault(require("moment"));
class GetActivityService {
    /**
     * Constructor for the ActivityService class
     * @param dynamo
     */
    constructor(dynamo) {
        this.dbClient = dynamo;
    }
    /**
     * Get activities from Dynamodb
     * @param event
     * @returns Promise - Array of activities filtered based on the given params and sorted desc
     */
    async getActivities(event) {
        return this.dbClient.scan()
            .then((data) => {
            if (data) {
                return this.filterActivities(data, event);
            }
            else {
                throw new HTTPResponse_1.HTTPResponse(404, enums_2.HTTPRESPONSE.NO_RESOURCES);
            }
        })
            .catch((error) => {
            if (error instanceof HTTPResponse_1.HTTPResponse) {
                throw new HTTPResponse_1.HTTPResponse(error.statusCode, error.body);
            }
        });
    }
    /**
     * Get activities of type visit based on startTime from Dynamodb
     * @param fromStartTime - query param used for range key
     * @returns Promise - Array of activities of type visit filtered based on the given params
     */
    async getActivitiesForCleanup(fromStartTime) {
        const activityDay = moment_1.default().format("YYYY-MM-DD");
        const activities = await this.dbClient.getActivitiesWhereStartTimeGreaterThan(activityDay, fromStartTime);
        if (!activities.Count) {
            return Promise.reject({ statusCode: 404, message: enums_2.HTTPRESPONSE.NO_RESOURCES });
        }
        return activities.Items;
    }
    /**
     * Filter activities by received parameters
     * @param response Data received from Dynamodb
     * @param event Event
     * @returns Array of activities filtered based on the given params and sorted desc
     */
    filterActivities(response, event) {
        let filteredActivities = [];
        const ActivityFilter = new Filters_1.ActivityFilters();
        if (response.Count === 0) {
            throw new HTTPResponse_1.HTTPResponse(404, enums_2.HTTPRESPONSE.NO_RESOURCES);
        }
        else {
            if (event.queryStringParameters) {
                if (event.queryStringParameters.fromStartTime) {
                    filteredActivities = ActivityFilter.filterActivitiesByStartTime(response.Items, event.queryStringParameters.fromStartTime, true);
                }
                else {
                    throw new HTTPResponse_1.HTTPResponse(400, enums_2.HTTPRESPONSE.BAD_REQUEST);
                }
                if (event.queryStringParameters.toStartTime) {
                    filteredActivities = ActivityFilter.filterActivitiesByStartTime(filteredActivities, event.queryStringParameters.toStartTime, false);
                }
                if (event.queryStringParameters.activityType) {
                    filteredActivities = ActivityFilter.filterActivitiesByParameter(filteredActivities, event.queryStringParameters.activityType, enums_1.QUERY_PARAMS.ACTIVITY_TYPE);
                }
                if (event.queryStringParameters.testStationPNumber) {
                    filteredActivities = ActivityFilter.filterActivitiesByParameter(filteredActivities, event.queryStringParameters.testStationPNumber, enums_1.QUERY_PARAMS.TEST_STATION_P_NUMBER);
                }
                if (event.queryStringParameters.testerStaffId) {
                    filteredActivities = ActivityFilter.filterActivitiesByParameter(filteredActivities, event.queryStringParameters.testerStaffId, enums_1.QUERY_PARAMS.TESTER_STAFF_ID);
                }
                const result = ActivityFilter.returnOrderedActivities(filteredActivities);
                if (result.length) {
                    return ActivityFilter.returnOrderedActivities(filteredActivities);
                }
                else {
                    throw new HTTPResponse_1.HTTPResponse(404, enums_2.HTTPRESPONSE.NO_RESOURCES);
                }
            }
            else {
                throw new HTTPResponse_1.HTTPResponse(400, enums_2.HTTPRESPONSE.BAD_REQUEST);
            }
        }
    }
}
exports.GetActivityService = GetActivityService;
