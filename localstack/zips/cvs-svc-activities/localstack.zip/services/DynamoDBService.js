"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoDBService = void 0;
// const AWSXRay = require("aws-xray-sdk");
// const AWS = AWSXRay.captureAWS(require("aws-sdk"));
const AWS = require("aws-sdk");
const Configuration_1 = require("../utils/Configuration");
class DynamoDBService {
    /**
     * Constructor for the DynamoDBService
     */
    constructor() {
        const config = Configuration_1.Configuration.getInstance().getDynamoDBConfig();
        this.tableName = config.table;
        if (!DynamoDBService.client) {
            DynamoDBService.client = new AWS.DynamoDB.DocumentClient(config.params);
        }
    }
    /**
     * Scan the entire table and retrieve all data
     * @returns Promise<PromiseResult<DocumentClient.ScanOutput, AWSError>>
     */
    scan() {
        return DynamoDBService.client.scan({ TableName: this.tableName })
            .promise();
    }
    /**
     * Retrieves the item with the given key
     * @param key - the key of the item you wish to fetch
     * @param attributes - optionally, you can request only a set of attributes
     * @returns Promise<PromiseResult<DocumentClient.GetItemOutput, AWSError>>
     */
    get(key, attributes) {
        const query = {
            TableName: this.tableName,
            Key: key,
        };
        if (attributes) {
            Object.assign(query, { AttributesToGet: attributes });
        }
        return DynamoDBService.client.get(query)
            .promise();
    }
    /**
     * Retrieves the ongoing activity for a given staffId
     * @param staffId - staff id for which to retrieve activity
     * @returns Promise<PromiseResult<DocumentClient.QueryOutput, AWSError>>
     */
    getOngoingByStaffId(staffId) {
        const query = {
            TableName: this.tableName,
            IndexName: "StaffIndex",
            KeyConditionExpression: "testerStaffId = :staffId",
            FilterExpression: "attribute_type(endTime, :NULL)",
            ExpressionAttributeValues: {
                ":staffId": staffId,
                ":NULL": "NULL"
            }
        };
        return DynamoDBService.client.query(query)
            .promise();
    }
    /**
     * Retrieves the activity of type visit where startTime is greater or equal than the query param fromStartTime
     * @param staffId - query param start time for which to retrieve activity
     * @returns Promise<PromiseResult<DocumentClient.QueryOutput, AWSError>>
     */
    getActivitiesWhereStartTimeGreaterThan(activityDay, startTime) {
        const query = {
            TableName: this.tableName,
            IndexName: "ActivityDayIndex",
            KeyConditionExpression: "activityDay = :activityDay AND startTime >= :startTime",
            ExpressionAttributeValues: {
                ":startTime": startTime,
                ":activityDay": activityDay
            }
        };
        return DynamoDBService.client.query(query).promise();
    }
    /**
     * Replaces the provided item, or inserts it if it does not exist
     * @param item - item to be inserted or updated
     * @returns Promise<PromiseResult<DocumentClient.PutItemOutput, AWSError>>
     */
    put(item) {
        const query = {
            TableName: this.tableName,
            Item: item,
            ReturnValues: "ALL_OLD"
        };
        return DynamoDBService.client.put(query)
            .promise();
    }
    /**
     * Deletes the item with the given key and returns the item deleted
     * @param key - the key of the item you wish to delete
     * @returns Promise<PromiseResult<DocumentClient.DeleteItemOutput, AWSError>>
     */
    delete(key) {
        const query = {
            TableName: this.tableName,
            Key: key,
            ReturnValues: "ALL_OLD",
        };
        return DynamoDBService.client.delete(query)
            .promise();
    }
    /**
     * Retrieves a list of batches containing results for the given keys
     * @param keys - a list of keys you wish to retrieve
     * @returns Promise<PromiseResult<BatchGetItemOutput, AWSError>>
     */
    batchGet(keys) {
        const keyList = keys.slice();
        const keyBatches = [];
        while (keyList.length > 0) {
            keyBatches.push(keyList.splice(0, 100));
        }
        const promiseBatch = keyBatches.map((batch) => {
            const query = {
                RequestItems: {
                    [this.tableName]: {
                        Keys: batch,
                    },
                },
            };
            return DynamoDBService.client.batchGet(query)
                .promise();
        });
        return Promise.all(promiseBatch);
    }
    /**
     * Updates or creates the items provided, and returns a list of result batches
     * @param items - items to add or update
     * @returns Promise<PromiseResult<DocumentClient.BatchWriteItemOutput, AWSError>[]>
     */
    batchPut(items) {
        const itemList = items.slice();
        const itemBatches = [];
        while (itemList.length > 0) {
            itemBatches.push(itemList.splice(0, 25));
        }
        const promiseBatch = itemBatches.map((batch) => {
            const query = {
                RequestItems: {
                    [this.tableName]: batch.map((item) => ({ PutRequest: { Item: item } })),
                },
            };
            return DynamoDBService.client.batchWrite(query)
                .promise();
        });
        return Promise.all(promiseBatch);
    }
}
exports.DynamoDBService = DynamoDBService;
