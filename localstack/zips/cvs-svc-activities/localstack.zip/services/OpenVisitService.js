"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const HTTPResponse_1 = require("../utils/HTTPResponse");
class OpenVisitService {
    /**
     * Constructor for the ActivityService class
     * @param dynamo
     */
    constructor(dynamo) {
        this.dbClient = dynamo;
    }
    /**
     * Does the staffId have a currently open visit?
     * @param staffId
     */
    async checkOpenVisit(staffId) {
        const visits = await this.dbClient.getOngoingByStaffId(staffId)
            .then((result) => {
            return result.Count;
        })
            .catch((error) => {
            console.log("Failed to get open visits from DynamoDB: ", error);
            throw new HTTPResponse_1.HTTPResponse(error.statusCode || 500, { error: `Failed to get open visits` });
        });
        return visits > 0;
    }
}
exports.default = OpenVisitService;
