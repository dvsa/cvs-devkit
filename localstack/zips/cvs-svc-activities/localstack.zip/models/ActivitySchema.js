"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ActivitySchema = void 0;
const Joi = __importStar(require("joi"));
const Activity_1 = require("./Activity");
const enums_1 = require("../assets/enums");
exports.ActivitySchema = Joi.object().keys({
    parentId: Joi.string().optional(),
    activityType: Joi.any().only([Activity_1.activitiesTypes]).required(),
    testStationName: Joi.string().required(),
    testStationPNumber: Joi.string().required(),
    testStationEmail: Joi.string().email().required(),
    testStationType: Joi.any().only([Activity_1.stationTypes]).required(),
    testerName: Joi.string().min(1).max(60).required(),
    testerStaffId: Joi.string().required(),
    testerEmail: Joi.any().when("activityType", {
        is: enums_1.ActivityType.VISIT,
        then: Joi.string().email().required(),
        otherwise: Joi.any().forbidden(),
    }),
    startTime: Joi.string().optional(),
    endTime: Joi.string().optional().allow(null),
    waitReason: Joi.array().items([Activity_1.waitReasons]).optional(),
    notes: Joi.string().allow(null)
});
