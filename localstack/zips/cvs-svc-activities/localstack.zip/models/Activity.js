"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.activitiesTypes = exports.stationTypes = exports.waitReasons = void 0;
const enums_1 = require("../assets/enums");
exports.waitReasons = ["Waiting for vehicle", "Break", "Admin", "Site issue", "Other"];
exports.stationTypes = [enums_1.StationType.ATF, enums_1.StationType.GVTS, enums_1.StationType.HQ];
exports.activitiesTypes = [enums_1.ActivityType.VISIT, enums_1.ActivityType.WAIT, enums_1.ActivityType.UNACCOUNTABLE_TIME];
