"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StationType = exports.ActivityType = exports.QUERY_PARAMS = exports.ENV_VARIABLES = exports.ERRORS = exports.HTTPRESPONSE = void 0;
var HTTPRESPONSE;
(function (HTTPRESPONSE) {
    HTTPRESPONSE["NO_RESOURCES"] = "No resources match the search criteria";
    HTTPRESPONSE["BAD_REQUEST"] = "Bad Request";
    HTTPRESPONSE["NOT_EXIST"] = "Activity id does not exist";
    HTTPRESPONSE["PARENT_ID_NOT_EXIST"] = "Parent id does not exist";
    HTTPRESPONSE["ALREADY_ENDED"] = "Activity already ended";
    HTTPRESPONSE["ONGOING_ACTIVITY_STAFF_ID"] = "Staff ID";
    HTTPRESPONSE["ONGING_ACTIVITY"] = "already has an ongoing activity";
    HTTPRESPONSE["NOT_VALID_JSON"] = "Body is not a valid JSON.";
    HTTPRESPONSE["AWS_EVENT_EMPTY"] = "AWS event is empty. Check your test event.";
    HTTPRESPONSE["PARENT_ID_NOT_REQUIRED"] = "ParentId not required for visit activity type.";
    HTTPRESPONSE["PARENT_ID_REQUIRED"] = "ParentId is required.";
    HTTPRESPONSE["START_TIME_EMPTY"] = "Start Time not provided.";
    HTTPRESPONSE["END_TIME_EMPTY"] = "End Time not provided.";
    HTTPRESPONSE["ACTIVITY_UPDATED"] = "Activity updated";
})(HTTPRESPONSE = exports.HTTPRESPONSE || (exports.HTTPRESPONSE = {}));
var ERRORS;
(function (ERRORS) {
    ERRORS["FUNCTION_NOT_DEFINED"] = "Functions were not defined in the config file.";
    ERRORS["DYNAMODB_NOT_DEFINED"] = "DynamoDB config is not defined in the config file.";
})(ERRORS = exports.ERRORS || (exports.ERRORS = {}));
var ENV_VARIABLES;
(function (ENV_VARIABLES) {
    ENV_VARIABLES["LOCAL"] = "local";
    ENV_VARIABLES["REMOTE"] = "remote";
})(ENV_VARIABLES = exports.ENV_VARIABLES || (exports.ENV_VARIABLES = {}));
var QUERY_PARAMS;
(function (QUERY_PARAMS) {
    QUERY_PARAMS["ACTIVITY_TYPE"] = "activityType";
    QUERY_PARAMS["TEST_STATION_P_NUMBER"] = "testStationPNumber";
    QUERY_PARAMS["TESTER_STAFF_ID"] = "testerStaffId";
    QUERY_PARAMS["END_TIME"] = "endTime";
})(QUERY_PARAMS = exports.QUERY_PARAMS || (exports.QUERY_PARAMS = {}));
var ActivityType;
(function (ActivityType) {
    ActivityType["VISIT"] = "visit";
    ActivityType["WAIT"] = "wait";
    ActivityType["UNACCOUNTABLE_TIME"] = "unaccountable time";
})(ActivityType = exports.ActivityType || (exports.ActivityType = {}));
var StationType;
(function (StationType) {
    StationType["ATF"] = "atf";
    StationType["GVTS"] = "gvts";
    StationType["HQ"] = "hq";
})(StationType = exports.StationType || (exports.StationType = {}));
