"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getActivitiesForCleanup = void 0;
const GetActivitiesService_1 = require("./../services/GetActivitiesService");
const HTTPResponse_1 = require("../utils/HTTPResponse");
const DynamoDBService_1 = require("../services/DynamoDBService");
const enums_1 = require("../assets/enums");
const getActivitiesForCleanup = async (event, context) => {
    const fromStartTime = event.queryStringParameters && event.queryStringParameters.fromStartTime;
    if (!fromStartTime) {
        return new HTTPResponse_1.HTTPResponse(400, enums_1.HTTPRESPONSE.BAD_REQUEST);
    }
    const activityService = new GetActivitiesService_1.GetActivityService(new DynamoDBService_1.DynamoDBService());
    try {
        const data = await activityService.getActivitiesForCleanup(fromStartTime);
        return new HTTPResponse_1.HTTPResponse(200, data);
    }
    catch (error) {
        console.error(error);
        return new HTTPResponse_1.HTTPResponse(error.statusCode, error.message);
    }
};
exports.getActivitiesForCleanup = getActivitiesForCleanup;
