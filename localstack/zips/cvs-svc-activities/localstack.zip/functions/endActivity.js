"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.endActivity = void 0;
const ActivityService_1 = require("../services/ActivityService");
const HTTPResponse_1 = require("../utils/HTTPResponse");
const DynamoDBService_1 = require("../services/DynamoDBService");
const endActivity = async (event, context) => {
    const activityService = new ActivityService_1.ActivityService(new DynamoDBService_1.DynamoDBService());
    const id = event.pathParameters.id;
    return activityService.endActivity(id)
        .then((wasVisitAlreadyClosed) => {
        return new HTTPResponse_1.HTTPResponse(200, wasVisitAlreadyClosed);
    })
        .catch((error) => {
        console.log(error.body);
        return error;
    });
};
exports.endActivity = endActivity;
