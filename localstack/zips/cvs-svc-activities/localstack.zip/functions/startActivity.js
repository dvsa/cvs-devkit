"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.startActivity = void 0;
const ActivityService_1 = require("../services/ActivityService");
const HTTPResponse_1 = require("../utils/HTTPResponse");
const DynamoDBService_1 = require("../services/DynamoDBService");
const startActivity = async (event, context) => {
    const activityService = new ActivityService_1.ActivityService(new DynamoDBService_1.DynamoDBService());
    return activityService.createActivity(event.body)
        .then((id) => {
        return new HTTPResponse_1.HTTPResponse(201, id);
    })
        .catch((error) => {
        console.log(error.body);
        return error;
    });
};
exports.startActivity = startActivity;
