"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateActivity = void 0;
const ActivityService_1 = require("../services/ActivityService");
const HTTPResponse_1 = require("../utils/HTTPResponse");
const enums_1 = require("../assets/enums");
const DynamoDBService_1 = require("../services/DynamoDBService");
const updateActivity = async (event, context) => {
    const activityService = new ActivityService_1.ActivityService(new DynamoDBService_1.DynamoDBService());
    // Is body valid: present, not empty, and an array
    if (!event.body || event.body.length === 0 || Object.keys(event.body).length === 0 || !Array.isArray(event.body)) {
        return new HTTPResponse_1.HTTPResponse(400, enums_1.HTTPRESPONSE.BAD_REQUEST);
    }
    return activityService.updateActivity(event.body)
        .then(() => {
        return new HTTPResponse_1.HTTPResponse(204, enums_1.HTTPRESPONSE.ACTIVITY_UPDATED);
    })
        .catch((error) => {
        console.log(error.body);
        return error;
    });
};
exports.updateActivity = updateActivity;
