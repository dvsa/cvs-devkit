"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.openVisitCheck = void 0;
const HTTPResponse_1 = require("../utils/HTTPResponse");
const DynamoDBService_1 = require("../services/DynamoDBService");
const OpenVisitService_1 = __importDefault(require("../services/OpenVisitService"));
const enums_1 = require("../assets/enums");
const openVisitCheck = async (event) => {
    var _a;
    const staffID = (_a = event.queryStringParameters) === null || _a === void 0 ? void 0 : _a.testerStaffId;
    if (!staffID) {
        return new HTTPResponse_1.HTTPResponse(400, enums_1.HTTPRESPONSE.BAD_REQUEST);
    }
    const openVisitService = new OpenVisitService_1.default(new DynamoDBService_1.DynamoDBService());
    return openVisitService.checkOpenVisit(staffID)
        .then((data) => {
        return new HTTPResponse_1.HTTPResponse(200, data);
    })
        .catch((error) => {
        return error;
    });
};
exports.openVisitCheck = openVisitCheck;
