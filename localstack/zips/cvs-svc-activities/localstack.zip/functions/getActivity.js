"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getActivity = void 0;
const GetActivitiesService_1 = require("./../services/GetActivitiesService");
const HTTPResponse_1 = require("../utils/HTTPResponse");
const DynamoDBService_1 = require("../services/DynamoDBService");
const getActivity = async (event, context) => {
    const activityService = new GetActivitiesService_1.GetActivityService(new DynamoDBService_1.DynamoDBService());
    return activityService.getActivities(event)
        .then((data) => {
        return new HTTPResponse_1.HTTPResponse(200, data);
    })
        .catch((error) => {
        return error;
    });
};
exports.getActivity = getActivity;
