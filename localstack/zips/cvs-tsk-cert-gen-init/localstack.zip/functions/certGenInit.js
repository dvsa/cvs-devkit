"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.certGenInit = void 0;
const aws_sdk_1 = require("aws-sdk");
const SQService_1 = require("../services/SQService");
const StreamService_1 = require("../services/StreamService");
const Utils_1 = require("../utils/Utils");
/**
 * λ function to process a DynamoDB stream of test results into a queue for certificate generation.
 * @param event - DynamoDB Stream event
 * @param context - λ Context
 * @param callback - callback function
 */
const certGenInit = async (event, context, callback) => {
    if (!event) {
        console.error("ERROR: event is not defined.");
        return;
    }
    // Convert the received event into a readable array of filtered test results
    const expandedRecords = StreamService_1.StreamService.getTestResultStream(event);
    const certGenFilteredRecords = Utils_1.Utils.filterCertificateGenerationRecords(expandedRecords);
    // Instantiate the Simple Queue Service
    // const sqService: SQService = new SQService(new SQS());
    console.log(process.env);
    console.log("process.env");
    const sqsQueue = new aws_sdk_1.SQS({
        endpoint: `http://${process.env.LOCALSTACK_HOSTNAME}:4566`,
        region: "eu-west-1",
        apiVersion: "2012-11-05"
    });
    const sqService = new SQService_1.SQService(sqsQueue);
    const sendMessagePromises = [];
    certGenFilteredRecords.forEach((record) => {
        sendMessagePromises.push(sqService.sendCertGenMessage(JSON.stringify(record)));
    });
    expandedRecords.forEach((record) => {
        sendMessagePromises.push(sqService.sendUpdateStatusMessage(JSON.stringify(record)));
    });
    return Promise.all(sendMessagePromises).catch((error) => {
        console.error(error);
        console.log("expandedRecords");
        console.log(JSON.stringify(expandedRecords));
        console.log("certGenFilteredRecords");
        console.log(JSON.stringify(certGenFilteredRecords));
        if (error.code !== "InvalidParameterValue") {
            throw error;
        }
    });
};
exports.certGenInit = certGenInit;
