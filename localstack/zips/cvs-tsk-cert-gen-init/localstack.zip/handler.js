"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const certGenInit_1 = require("./functions/certGenInit");
Object.defineProperty(exports, "handler", { enumerable: true, get: function () { return certGenInit_1.certGenInit; } });
const aws_sdk_1 = require("aws-sdk");
const isOffline = (!process.env.BRANCH || process.env.BRANCH === "local");
if (isOffline) {
    aws_sdk_1.config.credentials = {
        accessKeyId: "offline",
        secretAccessKey: "offline"
    };
}
console.log("AWSConfig.credentials");
console.log(aws_sdk_1.config.credentials);
