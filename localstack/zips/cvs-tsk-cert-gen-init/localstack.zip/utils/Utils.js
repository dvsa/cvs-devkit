"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Utils = void 0;
/**
 * Utils functions
 */
class Utils {
    /**
     * Filter records to be sent to SQS
     * @param records
     */
    static filterCertificateGenerationRecords(records) {
        return records
            .filter((record) => {
            return record.testStatus === "submitted";
        })
            .filter((record) => {
            return (record.testTypes.testResult === "pass" || record.testTypes.testResult === "fail" || record.testTypes.testResult === "prs");
        })
            .filter((record) => {
            if (record.testTypes && record.testTypes.testTypeClassification) {
                return record.testTypes.testTypeClassification === "Annual With Certificate";
            }
            return false;
        });
    }
}
exports.Utils = Utils;
