"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StreamService = void 0;
const aws_sdk_1 = require("aws-sdk");
/**
 * Service class for interpreting and formatting
 * incoming DynamoDB streams
 */
class StreamService {
    /**
     * Extract INSERT events from the DynamoDB Stream, convert them
     * to a JS object and expand the test results into multiple ones for each test type
     * Example:
     * Convert
     * test-result
     *  ├── test-type-1
     *  ├── test-type-2
     *  └── test-type-3
     *  into
     *  test-result
     *  └── test-type-1
     *  test-result
     *  └── test-type-2
     *  test-result
     *  └── test-type-3
     * @param event
     */
    static getTestResultStream(event) {
        // Create from a test result with multiple test types, multiple test result with one test type each
        const records = event.Records.filter((record) => {
            return record.eventName === "INSERT" || record.eventName === "MODIFY";
        })
            .map((record) => {
            if (record.dynamodb && record.dynamodb.NewImage) {
                return aws_sdk_1.DynamoDB.Converter.unmarshall(record.dynamodb.NewImage);
            }
        });
        return StreamService.expandRecords(records);
    }
    /**
     * Helper method for expanding a single record with multiple test types
     * into multiple records with a single test type
     * @param records
     */
    static expandRecords(records) {
        return records
            .map((record) => {
            const splittedRecords = [];
            const templateRecord = Object.assign({}, record);
            Object.assign(templateRecord, {});
            record.testTypes.forEach((testType, i, array) => {
                const clonedRecord = Object.assign({}, templateRecord); // Create record from template
                Object.assign(clonedRecord, { testTypes: testType }); // Assign it the test type
                Object.assign(clonedRecord, {
                    order: {
                        current: i + 1,
                        total: array.length
                    }
                });
                splittedRecords.push(clonedRecord);
            });
            return splittedRecords;
        })
            .reduce((acc, val) => acc.concat(val), []); // Flatten the array
    }
}
exports.StreamService = StreamService;
