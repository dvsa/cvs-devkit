"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SQService = void 0;
const sqs_1 = __importDefault(require("aws-sdk/clients/sqs"));
const ServiceDecorator_1 = require("../models/injector/ServiceDecorator");
/* tslint:disable */
// const AWSXRay = require("aws-xray-sdk");
/* tslint:enable */
/**
 * Service class for interfacing with the Simple Queue Service
 */
let SQService = class SQService {
    /**
     * Constructor for the ActivityService class
     * @param sqsClient - The Simple Queue Service client
     */
    constructor(sqsClient) {
        // const config: any = Configuration.getInstance().getConfig();
        // // this.sqsClient = AWSXRay.captureAWSClient(sqsClient);
        this.sqsClient = sqsClient;
        console.log("sqsClient");
        console.log(sqsClient);
    }
    /**
     * Send a message to cert-gen queue
     * @param messageBody
     */
    sendCertGenMessage(messageBody) {
        return this.sendMessage(messageBody, "cert-gen-localstack-queue");
    }
    /**
     * Send a message to update-status queue
     * @param messageBody
     */
    sendUpdateStatusMessage(messageBody) {
        return this.sendMessage(messageBody, "update-status-localstack-queue");
    }
    /**
     * Send a message to the specified queue (the AWS SQS queue URL is resolved based on the queueName for each message )
     * @param messageBody - A string message body
     * @param messageAttributes - A MessageAttributeMap
     * @param queueName - The queue name
     */
    async sendMessage(messageBody, queueName, messageAttributes) {
        // Get the queue URL for the provided queue name
        console.log('queueName');
        console.log({ queueName });
        console.log('process.env.LOCALSTACK_HOSTNAME in sendMessage()');
        console.log(process.env.LOCALSTACK_HOSTNAME);
        const params = {
            QueueUrl: `http://${process.env.LOCALSTACK_HOSTNAME}:4566/000000000000/${queueName}`,
            MessageBody: messageBody
        };
        console.log('params');
        console.log(params);
        if (messageAttributes) {
            Object.assign({}, params, { MessageAttributes: messageAttributes });
        }
        // console.log('call params')
        // this.sqsClient.sendMessage(params as SQS.Types.SendMessageRequest).promise().then(d => console.info('data from params: \n', d)).catch(e => console.error(e));
        // Send a message to the queue
        return this.sqsClient.sendMessage(params).promise();
    }
    /**
     * Get the messages in the queue
     */
    async getMessages() {
        // Get the messages from the queue
        console.log('process.env.LOCALSTACK_HOSTNAME in getMessages()');
        console.log(process.env.LOCALSTACK_HOSTNAME);
        return this.sqsClient.receiveMessage({ QueueUrl: `http://${process.env.LOCALSTACK_HOSTNAME}:4566/000000000000/cert-gen-localstack-queue` })
            .promise();
    }
};
SQService = __decorate([
    ServiceDecorator_1.Service(),
    __metadata("design:paramtypes", [sqs_1.default])
], SQService);
exports.SQService = SQService;
