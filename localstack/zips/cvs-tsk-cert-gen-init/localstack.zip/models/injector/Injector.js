"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Injector = void 0;
require("reflect-metadata");
/**
 * The Injector stores services and resolves requested instances.
 */
exports.Injector = new class {
    /**
     * Resolves instances by injecting required services
     * @param {Type<any>} target
     * @param {Type<any>} injections - optionally, you can override the expected injection with another one
     * @returns {T}
     */
    resolve(target, injections) {
        if (!injections) {
            // tokens are required dependencies, while injections are resolved tokens from the Injector
            const targetTokens = Reflect.getMetadata("design:paramtypes", target) || [];
            const targetInjections = targetTokens.map((token) => exports.Injector.resolve(token));
            return new target(...targetInjections);
        }
        const manualInjections = injections.map((token) => exports.Injector.resolve(token));
        return new target(...manualInjections);
    }
};
