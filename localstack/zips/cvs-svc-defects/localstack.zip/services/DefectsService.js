"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DefectsService = void 0;
const HTTPError_1 = require("../models/HTTPError");
class DefectsService {
    constructor(defectsDAO) {
        this.defectsDAO = defectsDAO;
    }
    getDefectList() {
        return this.defectsDAO
            .getAll()
            .then((data) => {
            if (data.Count === 0) {
                throw new HTTPError_1.HTTPError(404, "No resources match the search criteria.");
            }
            return data.Items.map((defect) => {
                delete defect.id;
                return defect;
            }).sort((first, second) => {
                return first.imNumber - second.imNumber;
            });
        })
            .catch((error) => {
            if (!(error instanceof HTTPError_1.HTTPError)) {
                console.error(error);
                error.statusCode = 500;
                error.body = "Internal Server Error";
            }
            throw new HTTPError_1.HTTPError(error.statusCode, error.body);
        });
    }
    insertDefectList(defectItems) {
        return this.defectsDAO
            .createMultiple(defectItems)
            .then((data) => {
            if (data.UnprocessedItems) {
                return data.UnprocessedItems;
            }
        })
            .catch((error) => {
            if (error) {
                console.error(error);
                throw new HTTPError_1.HTTPError(500, "Internal Server Error");
            }
        });
    }
    deleteDefectList(defectItemKeys) {
        return this.defectsDAO
            .deleteMultiple(defectItemKeys)
            .then((data) => {
            if (data.UnprocessedItems) {
                return data.UnprocessedItems;
            }
        })
            .catch((error) => {
            if (error) {
                console.error(error);
                throw new HTTPError_1.HTTPError(500, "Internal ServerError");
            }
        });
    }
}
exports.DefectsService = DefectsService;
