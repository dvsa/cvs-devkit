"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DefectsDAO = void 0;
const Configuration_1 = require("../utils/Configuration");
/* workaround AWSXRay.captureAWS(...) call obscures types provided by the AWS sdk.
https://github.com/aws/aws-xray-sdk-node/issues/14
*/
/* tslint:disable */
let AWS;
// if (process.env._X_AMZN_TRACE_ID) {
//   AWS = require("aws-xray-sdk").captureAWS(require("aws-sdk"));
// } else {
//   console.log("Serverless Offline detected; skipping AWS X-Ray setup");
// }
AWS = require("aws-sdk");
/* tslint:enable */
class DefectsDAO {
    constructor() {
        const config = Configuration_1.Configuration.getInstance().getDynamoDBConfig();
        this.tableName = config.table;
        console.log('config is:\n');
        console.log({ config });
        if (!DefectsDAO.dbClient) {
            DefectsDAO.dbClient = new AWS.DynamoDB.DocumentClient(config.params);
        }
    }
    getAll() {
        return DefectsDAO.dbClient.scan({ TableName: this.tableName }).promise();
    }
    generatePartialParams() {
        return {
            RequestItems: {
                [this.tableName]: [],
            },
        };
    }
    createMultiple(defectItems) {
        const params = this.generatePartialParams();
        defectItems.map((defectItem) => {
            params.RequestItems[this.tableName].push({
                PutRequest: {
                    Item: defectItem,
                },
            });
        });
        return DefectsDAO.dbClient.batchWrite(params).promise();
    }
    deleteMultiple(primaryKeysToBeDeleted) {
        const params = this.generatePartialParams();
        primaryKeysToBeDeleted.forEach((key) => {
            params.RequestItems[this.tableName].push({
                DeleteRequest: {
                    Key: {
                        id: key,
                    },
                },
            });
        });
        return DefectsDAO.dbClient.batchWrite(params).promise();
    }
}
exports.DefectsDAO = DefectsDAO;
