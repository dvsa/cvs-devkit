"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDefects = void 0;
const DefectsDAO_1 = require("../models/DefectsDAO");
const DefectsService_1 = require("../services/DefectsService");
const HTTPResponse_1 = require("../models/HTTPResponse");
exports.getDefects = async () => {
    const defectsDAO = new DefectsDAO_1.DefectsDAO();
    const defectsService = new DefectsService_1.DefectsService(defectsDAO);
    return defectsService
        .getDefectList()
        .then((data) => {
        return new HTTPResponse_1.HTTPResponse(200, data);
    })
        .catch((error) => {
        return new HTTPResponse_1.HTTPResponse(error.statusCode, error.body);
    });
};
