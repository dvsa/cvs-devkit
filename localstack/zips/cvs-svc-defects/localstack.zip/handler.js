"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const Enums_1 = require("./assets/Enums");
const path_parser_1 = __importDefault(require("path-parser"));
const Configuration_1 = require("./utils/Configuration");
const HTTPResponse_1 = require("./models/HTTPResponse");
const handler = async (event, context, callback) => {
    console.log('LOGGING EVENT IN HANDLER:');
    console.log({ event });
    // Request integrity checks
    if (!event) {
        return new HTTPResponse_1.HTTPResponse(400, Enums_1.HTTPRESPONSE.AWS_EVENT_EMPTY);
    }
    if (event.body) {
        let payload = {};
        try {
            payload = JSON.parse(event.body);
        }
        catch (_a) {
            return new HTTPResponse_1.HTTPResponse(400, Enums_1.HTTPRESPONSE.NOT_VALID_JSON);
        }
        Object.assign(event, { body: payload });
    }
    // Finding an appropriate λ matching the request
    const config = Configuration_1.Configuration.getInstance();
    console.log('config in Handler');
    console.log(config);
    const functions = config.getFunctions();
    console.log('functions in Handler');
    const serverlessConfig = config.getConfig().serverless;
    console.log(functions);
    console.log('serverlessConfig in Handler');
    console.log(serverlessConfig);
    const matchingLambdaEvents = functions
        .filter((fn) => {
        // Find λ with matching httpMethod
        return event.httpMethod === fn.method;
    })
        .filter((fn) => {
        // Find λ with matching path
        const localPath = new path_parser_1.default(fn.path);
        const remotePath = new path_parser_1.default(`${serverlessConfig.basePath}${fn.path}`); // Remote paths also have environment
        const pathFromLambdaEvents = localPath.test(event.path) || remotePath.test(event.path);
        console.log('pathFromLambdaEvents in Handler');
        console.log(pathFromLambdaEvents);
        return pathFromLambdaEvents;
    });
    // Exactly one λ should match the above filtering.
    if (matchingLambdaEvents.length === 1) {
        const lambdaEvent = matchingLambdaEvents[0];
        const lambdaFn = lambdaEvent.function;
        const localPath = new path_parser_1.default(lambdaEvent.path);
        const remotePath = new path_parser_1.default(`${serverlessConfig.basePath}${lambdaEvent.path}`); // Remote paths also have environment
        const lambdaPathParams = localPath.test(event.path) || remotePath.test(event.path);
        const clonedObject = Object.assign(event, { pathParameters: lambdaPathParams });
        console.log('clonedObject in Handler');
        console.log(clonedObject);
        console.log(`HTTP ${event.httpMethod} ${event.path} -> λ ${lambdaEvent.name}`);
        console.log({ event });
        console.log({ context });
        console.log({ callback });
        console.log({ lambdaFn });
        // Explicit conversion because typescript can't figure it out
        return lambdaFn(event, context, callback);
    }
    // If filtering results in less or more λ functions than expected, we return an error.
    console.error(`Error: Route ${event.httpMethod} ${event.path} was not found.
    Dumping event:
    ${JSON.stringify(event)}
    Dumping context:
    ${JSON.stringify(context)}`);
    return new HTTPResponse_1.HTTPResponse(400, {
        error: `Route ${event.httpMethod} ${event.path} was not found.`,
    });
};
exports.handler = handler;
