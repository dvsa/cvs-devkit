"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HTTPRESPONSE = exports.ERRORS = void 0;
var ERRORS;
(function (ERRORS) {
    ERRORS["NotifyConfigNotDefined"] = "The Notify config is not defined in the config file.";
    ERRORS["DynamoDBConfigNotDefined"] = "DynamoDB config is not defined in the config file.";
    ERRORS["LambdaInvokeConfigNotDefined"] = "Lambda Invoke config is not defined in the config file.";
    ERRORS["EventIsEmpty"] = "Event is empty";
    ERRORS["NoBranch"] = "Please define BRANCH environment variable";
})(ERRORS = exports.ERRORS || (exports.ERRORS = {}));
var HTTPRESPONSE;
(function (HTTPRESPONSE) {
    HTTPRESPONSE["AWS_EVENT_EMPTY"] = "AWS event is empty. Check your test event.";
    HTTPRESPONSE["NOT_VALID_JSON"] = "Body is not a valid JSON.";
})(HTTPRESPONSE = exports.HTTPRESPONSE || (exports.HTTPRESPONSE = {}));
