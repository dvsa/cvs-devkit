"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ERRORS;
(function (ERRORS) {
    ERRORS["NOTIFY_CONFIG_NOT_DEFINED"] = "The Notify config is not defined in the config file.";
    ERRORS["DYNAMO_DB_CONFIG_NOT_DEFINED"] = "DynamoDB config is not defined in the config file.";
    ERRORS["LAMBDA_INVOKE_CONFIG_NOT_DEFINED"] = "Lambda Invoke config is not defined in the config file.";
    ERRORS["EVENT_IS_EMPTY"] = "Event is empty";
    ERRORS["NO_BRANCH"] = "Please define BRANCH environment variable";
    ERRORS["NO_UNIQUE_RECORD"] = "Failed to uniquely identify record";
    ERRORS["TRAILER_ID_GENERATION_FAILED"] = "TrailerId generation failed!";
    ERRORS["SYSTEM_NUMBER_GENERATION_FAILED"] = "System Number generation failed!";
    ERRORS["CANNOT_UPDATE_ARCHIVED_RECORD"] = "You are not allowed to update an archived tech-record";
    ERRORS["CANNOT_USE_UPDATE_TO_ARCHIVE"] = "Cannot use update API to archive tech record";
    ERRORS["CANNOT_ARCHIVE_CHANGED_RECORD"] = "Cannot archive tech record with attribute changes";
    ERRORS["CURRENT_OR_PROVISIONAL_RECORD_FOUND"] = "Has existing Current or Provisional record";
    ERRORS["CANNOT_CHANGE_CURRENT_TO_PROVISIONAL"] = "Cannot change current status to provisional";
    ERRORS["STATUS_CODE_SHOULD_BE_PROVISIONAL"] = "Status code should be provisional";
    ERRORS["MISSING_PAYLOAD"] = "Missing payload!";
    ERRORS["MISSING_USER"] = "Microsoft user details not provided";
    ERRORS["VEHICLE_TYPE_ERROR"] = "\"vehicleType\" must be one of [hgv, psv, trl, car, lgv, motorcycle]";
})(ERRORS = exports.ERRORS || (exports.ERRORS = {}));
var HTTPRESPONSE;
(function (HTTPRESPONSE) {
    HTTPRESPONSE["RESOURCE_NOT_FOUND"] = "No resources match the search criteria.";
    HTTPRESPONSE["INTERNAL_SERVER_ERROR"] = "Internal Server Error";
    HTTPRESPONSE["MORE_THAN_ONE_MATCH"] = "The provided partial VIN returned more than one match.";
    HTTPRESPONSE["NO_STATUS_UPDATE_REQUIRED"] = "No status update required";
    HTTPRESPONSE["NO_EU_VEHICLE_CATEGORY_UPDATE_REQUIRED"] = "No EU vehicle category update required";
    HTTPRESPONSE["INVALID_EU_VEHICLE_CATEGORY"] = "Invalid EU vehicle category";
    HTTPRESPONSE["EU_VEHICLE_CATEGORY_MORE_THAN_ONE_TECH_RECORD"] = "The vehicle has more than one non archived Tech record.";
})(HTTPRESPONSE = exports.HTTPRESPONSE || (exports.HTTPRESPONSE = {}));
var STATUS;
(function (STATUS) {
    STATUS["ARCHIVED"] = "archived";
    STATUS["CURRENT"] = "current";
    STATUS["PROVISIONAL"] = "provisional";
    STATUS["PROVISIONAL_OVER_CURRENT"] = "provisional_over_current";
    STATUS["ALL"] = "all";
})(STATUS = exports.STATUS || (exports.STATUS = {}));
var SEARCHCRITERIA;
(function (SEARCHCRITERIA) {
    SEARCHCRITERIA["ALL"] = "all";
    SEARCHCRITERIA["VIN"] = "vin";
    SEARCHCRITERIA["VRM"] = "vrm";
    SEARCHCRITERIA["PARTIALVIN"] = "partialVin";
    SEARCHCRITERIA["TRAILERID"] = "trailerId";
    SEARCHCRITERIA["SYSTEM_NUMBER"] = "systemNumber";
})(SEARCHCRITERIA = exports.SEARCHCRITERIA || (exports.SEARCHCRITERIA = {}));
var UPDATE_TYPE;
(function (UPDATE_TYPE) {
    UPDATE_TYPE["ADR"] = "adrUpdate";
    UPDATE_TYPE["TECH_RECORD_UPDATE"] = "techRecordUpdate";
})(UPDATE_TYPE = exports.UPDATE_TYPE || (exports.UPDATE_TYPE = {}));
var VEHICLE_TYPE;
(function (VEHICLE_TYPE) {
    VEHICLE_TYPE["HGV"] = "hgv";
    VEHICLE_TYPE["TRL"] = "trl";
    VEHICLE_TYPE["PSV"] = "psv";
    VEHICLE_TYPE["CAR"] = "car";
    VEHICLE_TYPE["LGV"] = "lgv";
    VEHICLE_TYPE["MOTORCYCLE"] = "motorcycle";
})(VEHICLE_TYPE = exports.VEHICLE_TYPE || (exports.VEHICLE_TYPE = {}));
var EU_VEHICLE_CATEGORY;
(function (EU_VEHICLE_CATEGORY) {
    EU_VEHICLE_CATEGORY["M1"] = "m1";
    EU_VEHICLE_CATEGORY["M2"] = "m2";
    EU_VEHICLE_CATEGORY["M3"] = "m3";
    EU_VEHICLE_CATEGORY["N1"] = "n1";
    EU_VEHICLE_CATEGORY["N2"] = "n2";
    EU_VEHICLE_CATEGORY["N3"] = "n3";
    EU_VEHICLE_CATEGORY["O1"] = "o1";
    EU_VEHICLE_CATEGORY["O2"] = "o2";
    EU_VEHICLE_CATEGORY["O3"] = "o3";
    EU_VEHICLE_CATEGORY["O4"] = "o4";
    EU_VEHICLE_CATEGORY["L1EA"] = "l1e-a";
    EU_VEHICLE_CATEGORY["L1E"] = "l1e";
    EU_VEHICLE_CATEGORY["L2E"] = "l2e";
    EU_VEHICLE_CATEGORY["L3E"] = "l3e";
    EU_VEHICLE_CATEGORY["L4E"] = "l4e";
    EU_VEHICLE_CATEGORY["L5E"] = "l5e";
    EU_VEHICLE_CATEGORY["L6E"] = "l6e";
    EU_VEHICLE_CATEGORY["L7E"] = "l7e";
})(EU_VEHICLE_CATEGORY = exports.EU_VEHICLE_CATEGORY || (exports.EU_VEHICLE_CATEGORY = {}));
exports.VEHICLE_TYPE_VALIDATION = [
    "psv",
    "trl",
    "hgv",
    "car",
    "lgv",
    "motorcycle"
];
exports.FUEL_PROPULSION_SYSTEM = [
    "DieselPetrol",
    "Hybrid",
    "Electric",
    "CNG",
    "Fuel cell",
    "LNG",
    "Other"
];
exports.VEHICLE_CLASS_DESCRIPTION = [
    "motorbikes over 200cc or with a sidecar",
    "not applicable",
    "small psv (ie: less than or equal to 22 seats)",
    "motorbikes up to 200cc",
    "trailer",
    "large psv(ie: greater than 23 seats)",
    "3 wheelers",
    "heavy goods vehicle",
    "MOT class 4",
    "MOT class 7",
    "MOT class 5"
];
exports.VEHICLE_CONFIGURATION = [
    "rigid",
    "articulated",
    "centre axle drawbar",
    "semi-car transporter",
    "semi-trailer",
    "low loader",
    "other",
    "drawbar",
    "four-in-line",
    "dolly",
    "full drawbar"
];
exports.EU_VEHICLE_CATEGORY_VALIDATION = [
    "m1",
    "m2",
    "m3",
    "n1",
    "n2",
    "n3",
    "o1",
    "o2",
    "o3",
    "o4",
    "l1e-a",
    "l1e",
    "l2e",
    "l3e",
    "l4e",
    "l5e",
    "l6e",
    "l7e"
];
exports.APPROVAL_TYPE = [
    "NTA",
    "ECTA",
    "IVA",
    "NSSTA",
    "ECSSTA"
];
exports.BODY_TYPE_DESCRIPTION = [
    "articulated",
    "single decker",
    "double decker",
    "other",
    "petrol/oil tanker",
    "skeletal",
    "tipper",
    "box",
    "flat",
    "refuse",
    "skip loader",
    "refrigerated"
];
exports.MICROFILM_DOCUMENT_TYPE = [
    "PSV Miscellaneous",
    "AAT - Trailer Annual Test",
    "AIV - HGV International App",
    "COIF Modification",
    "Trailer COC + Int Plate",
    "RCT - Trailer Test Cert paid",
    "HGV COC + Int Plate",
    "PSV Carry/Auth",
    "OMO Report",
    "AIT - Trailer International App",
    "IPV - HGV EEC Plate/Cert",
    "XCV - HGV Test Cert free",
    "AAV - HGV Annual Test",
    "COIF Master",
    "Tempo 100 Sp Ord",
    "Deleted",
    "PSV N/ALT",
    "XPT - Tr Plating Cert paid",
    "FFV - HGV First Test",
    "Repl Vitesse 100",
    "TCV - HGV Test Cert",
    "ZZZ -  Miscellaneous",
    "Test Certificate",
    "XCT - Trailer Test Cert free",
    "C52 - COC and VTG52A",
    "Tempo 100 Report",
    "Main File Amendment",
    "PSV Doc",
    "PSV COC",
    "PSV Repl COC",
    "TAV - COC",
    "NPT - Trailer Alteration",
    "OMO Certificate",
    "PSV Repl COIF",
    "PSV Repl COF",
    "COIF Application",
    "XPV - HGV Plating Cert Free",
    "TCT  - Trailer Test Cert",
    "Tempo 100 App",
    "PSV Decision on N/ALT",
    "Special Order PSV",
    "NPV - HGV Alteration",
    "No Description Found",
    "Vitesse 100 Sp Ord",
    "Brake Test Details",
    "COIF Productional",
    "RDT - Test Disc Paid",
    "RCV -  HGV Test Cert",
    "FFT -  Trailer First Test",
    "IPT - Trailer EEC Plate/Cert",
    "XDT - Test Disc Free",
    "PRV - HGV Plating Cert paid",
    "COF Cert",
    "PRT - Tr Plating Cert paid",
    "Tempo 100 Permit"
];
exports.PLATE_REASON_FOR_ISSUE = [
    "Free replacement",
    "Replacement",
    "Destroyed",
    "Provisional",
    "Original",
    "Manual"
];
exports.FITMENT_CODE = [
    "double",
    "single"
];
exports.SPEED_CATEGORY_SYMBOL = [
    "a7",
    "a8",
    "b",
    "c",
    "d",
    "e",
    "f",
    "g",
    "j",
    "k",
    "l",
    "m",
    "n",
    "p",
    "q"
];
exports.VEHICLE_SIZE = [
    "small",
    "large"
];
exports.RETARDER_BRAKE = [
    "electric",
    "exhaust",
    "friction",
    "hydraulic",
    "other",
    "none",
];
exports.RECORD_COMPLETENESS = [
    "complete",
    "testable",
    "skeleton"
];
exports.FRAME_DESCRIPTION = [
    "Channel section",
    "Space frame",
    "I section",
    "Tubular",
    "Frame section",
    "Other",
    "integral",
    "Box section",
    "U section"
];
exports.LETTER_TYPE = [
    "Trailer authorization",
    "Trailer rejection"
];
exports.STATUS_CODES = [
    "current",
    "provisional",
    "archived"
];
exports.VEHICLE_SUBCLASS = [
    "n",
    "p",
    "a",
    "s",
    "c",
    "l",
    "t",
    "e",
    "m",
    "r",
    "w"
];
var RECORD_COMPLETENESS_ENUM;
(function (RECORD_COMPLETENESS_ENUM) {
    RECORD_COMPLETENESS_ENUM["COMPLETE"] = "complete";
    RECORD_COMPLETENESS_ENUM["TESTABLE"] = "testable";
    RECORD_COMPLETENESS_ENUM["SKELETON"] = "skeleton";
})(RECORD_COMPLETENESS_ENUM = exports.RECORD_COMPLETENESS_ENUM || (exports.RECORD_COMPLETENESS_ENUM = {}));
var REASON_FOR_CREATION;
(function (REASON_FOR_CREATION) {
    REASON_FOR_CREATION["EU_VEHICLE_CATEGORY_UPDATED"] = "EU vehicle category updated";
})(REASON_FOR_CREATION = exports.REASON_FOR_CREATION || (exports.REASON_FOR_CREATION = {}));
