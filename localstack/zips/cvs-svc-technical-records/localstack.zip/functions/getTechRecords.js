"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const Enums_1 = require("../assets/Enums");
const TechRecordsDAO_1 = __importDefault(require("../models/TechRecordsDAO"));
const HTTPResponse_1 = __importDefault(require("../models/HTTPResponse"));
const TechRecordsService_1 = __importDefault(require("../services/TechRecordsService"));
const metadataEnums_1 = require("../utils/metadataEnums");
const PayloadValidation_1 = require("../utils/validations/PayloadValidation");
const getTechRecords = (event) => {
    var _a, _b;
    const techRecordsDAO = new TechRecordsDAO_1.default();
    const techRecordsService = new TechRecordsService_1.default(techRecordsDAO);
    const status = ((_a = event.queryStringParameters) === null || _a === void 0 ? void 0 : _a.status) ? event.queryStringParameters.status : Enums_1.STATUS.PROVISIONAL_OVER_CURRENT;
    const searchCriteria = ((_b = event.queryStringParameters) === null || _b === void 0 ? void 0 : _b.searchCriteria) ? event.queryStringParameters.searchCriteria : Enums_1.SEARCHCRITERIA.ALL;
    const metadata = (event.queryStringParameters) ? event.queryStringParameters.metadata : null;
    const searchIdentifier = (event.pathParameters) ? decodeURIComponent(event.pathParameters.searchIdentifier) : null;
    // searchTerm too long or too short
    if (!searchIdentifier || searchIdentifier.length < 3 || searchIdentifier.length > 21) {
        return Promise.resolve(new HTTPResponse_1.default(400, "The search identifier should be between 3 and 21 characters."));
    }
    // TODO Not currently used. Probably should be. isValidSearchCriteria() just returns true to bypass at  the moment.
    if (!PayloadValidation_1.isValidSearchCriteria(searchCriteria)) {
        return Promise.resolve(new HTTPResponse_1.default(400, "The search criteria specified is not valid."));
    }
    return techRecordsService.getTechRecordsList(searchIdentifier, status, searchCriteria)
        .then((data) => {
        if (!(data instanceof Array)) {
            return new HTTPResponse_1.default(200, Array.of(data));
        }
        if (metadata === "true") {
            data.forEach((record) => {
                Object.assign(record, { metadata: metadataEnums_1.metaData });
            });
        }
        return new HTTPResponse_1.default(200, data);
    })
        .catch((error) => {
        console.log(error);
        return new HTTPResponse_1.default(error.statusCode, error.body);
    });
};
exports.getTechRecords = getTechRecords;
