"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const TechRecordsDAO_1 = __importDefault(require("../models/TechRecordsDAO"));
const TechRecordsService_1 = __importDefault(require("../services/TechRecordsService"));
const HTTPResponse_1 = __importDefault(require("../models/HTTPResponse"));
const Enums_1 = require("../assets/Enums");
async function updateTechRecordStatus(event) {
    const techRecordsService = new TechRecordsService_1.default(new TechRecordsDAO_1.default());
    const systemNumber = event.pathParameters.systemNumber;
    const testStatus = event.queryStringParameters.testStatus;
    const testResult = event.queryStringParameters.testResult;
    const testTypeId = event.queryStringParameters.testTypeId;
    const newStatus = event.queryStringParameters ? Enums_1.STATUS[event.queryStringParameters.newStatus] : undefined;
    const createdById = event.queryStringParameters.createdById;
    const createdByName = event.queryStringParameters.createdByName;
    if (!TechRecordsService_1.default.isStatusUpdateRequired(testStatus, testResult, testTypeId)) {
        return new HTTPResponse_1.default(200, Enums_1.HTTPRESPONSE.NO_STATUS_UPDATE_REQUIRED);
    }
    try {
        const updatedTechRec = await techRecordsService.updateTechRecordStatusCode(systemNumber, newStatus, createdById, createdByName);
        return new HTTPResponse_1.default(200, updatedTechRec);
    }
    catch (error) {
        return new HTTPResponse_1.default(error.statusCode, error.body);
    }
}
exports.updateTechRecordStatus = updateTechRecordStatus;
