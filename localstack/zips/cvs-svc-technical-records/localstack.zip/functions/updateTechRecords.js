"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const TechRecordsDAO_1 = __importDefault(require("../models/TechRecordsDAO"));
const TechRecordsService_1 = __importDefault(require("../services/TechRecordsService"));
const HTTPResponse_1 = __importDefault(require("../models/HTTPResponse"));
const formatErrorMessage_1 = require("../utils/formatErrorMessage");
const Enums_1 = require("../assets/Enums");
const updateTechRecords = (event) => {
    const techRecordsDAO = new TechRecordsDAO_1.default();
    const techRecordsService = new TechRecordsService_1.default(techRecordsDAO);
    const techRec = event.body ? event.body.techRecord : null;
    const msUserDetails = event.body ? event.body.msUserDetails : null;
    const systemNumber = event.pathParameters ? event.pathParameters.systemNumber : null;
    if (!systemNumber) {
        return Promise.resolve(new HTTPResponse_1.default(400, formatErrorMessage_1.formatErrorMessage("Invalid path parameter 'systemNumber'")));
    }
    if (!techRec || !techRec.length) {
        return Promise.resolve(new HTTPResponse_1.default(400, formatErrorMessage_1.formatErrorMessage("Body is not a valid TechRecord")));
    }
    if (!msUserDetails || !msUserDetails.msUser || !msUserDetails.msOid) {
        return Promise.resolve(new HTTPResponse_1.default(400, formatErrorMessage_1.formatErrorMessage(Enums_1.ERRORS.MISSING_USER)));
    }
    const oldStatusCodeString = event.queryStringParameters && event.queryStringParameters.oldStatusCode;
    const oldStatusCode = oldStatusCodeString ? Enums_1.STATUS[oldStatusCodeString.toUpperCase()] : undefined;
    const techRecord = {
        vin: event.body.vin,
        systemNumber,
        secondaryVrms: event.body.secondaryVrms,
        primaryVrm: event.body.primaryVrm,
        trailerId: event.body.trailerId,
        techRecord: techRec
    };
    return techRecordsService.updateTechRecord(techRecord, msUserDetails, oldStatusCode)
        .then((updatedTechRec) => {
        return new HTTPResponse_1.default(200, updatedTechRec);
    })
        .catch((error) => {
        console.log(error);
        return new HTTPResponse_1.default(error.statusCode, error.body);
    });
};
exports.updateTechRecords = updateTechRecords;
