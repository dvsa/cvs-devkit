"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const TechRecordsDAO_1 = __importDefault(require("../models/TechRecordsDAO"));
const TechRecordsService_1 = __importDefault(require("../services/TechRecordsService"));
const HTTPResponse_1 = __importDefault(require("../models/HTTPResponse"));
const Enums_1 = require("../assets/Enums");
const formatErrorMessage_1 = require("../utils/formatErrorMessage");
async function archiveTechRecordStatus(event) {
    const techRecordsService = new TechRecordsService_1.default(new TechRecordsDAO_1.default());
    const systemNumber = event.pathParameters.systemNumber;
    const techRec = event.body && event.body.techRecord;
    const msUserDetails = event.body && event.body.msUserDetails ? event.body.msUserDetails : null;
    if (!techRec || !techRec.length) {
        return Promise.resolve(new HTTPResponse_1.default(400, formatErrorMessage_1.formatErrorMessage(Enums_1.ERRORS.MISSING_PAYLOAD)));
    }
    if (!msUserDetails || !msUserDetails.msUser || !msUserDetails.msOid) {
        return Promise.resolve(new HTTPResponse_1.default(400, formatErrorMessage_1.formatErrorMessage(Enums_1.ERRORS.MISSING_USER)));
    }
    const techRecord = {
        vin: "",
        systemNumber,
        techRecord: techRec
    };
    return techRecordsService.archiveTechRecordStatus(systemNumber, techRecord, msUserDetails)
        .then((updatedTechRec) => {
        return new HTTPResponse_1.default(200, updatedTechRec);
    })
        .catch((error) => {
        console.log(error);
        return new HTTPResponse_1.default(error.statusCode, error.body);
    });
}
exports.archiveTechRecordStatus = archiveTechRecordStatus;
