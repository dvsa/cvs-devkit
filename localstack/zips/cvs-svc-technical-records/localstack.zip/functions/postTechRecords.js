"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const TechRecordsDAO_1 = __importDefault(require("../models/TechRecordsDAO"));
const TechRecordsService_1 = __importDefault(require("../services/TechRecordsService"));
const HTTPResponse_1 = __importDefault(require("../models/HTTPResponse"));
const ValidationUtils_1 = require("../utils/validations/ValidationUtils");
const postTechRecords = (event) => {
    const techRecordsDAO = new TechRecordsDAO_1.default();
    const techRecordsService = new TechRecordsService_1.default(techRecordsDAO);
    const techRec = event.body ? event.body.techRecord : null;
    const msUserDetails = event.body ? event.body.msUserDetails : null;
    const vin = event.body ? event.body.vin : null;
    const primaryVrm = event.body ? event.body.primaryVrm : null;
    const secondaryVrms = event.body ? event.body.secondaryVrms : null;
    if (!vin || vin.length < 3 || vin.length > 21 || typeof vin !== "string") {
        return Promise.resolve(new HTTPResponse_1.default(400, "Invalid body field 'vin'"));
    }
    if (!techRec || !techRec.length) {
        return Promise.resolve(new HTTPResponse_1.default(400, "Body is not a valid TechRecord"));
    }
    if (!msUserDetails || !msUserDetails.msUser || !msUserDetails.msOid) {
        return Promise.resolve(new HTTPResponse_1.default(400, "Microsoft user details not provided"));
    }
    const techRecord = {
        vin,
        partialVin: ValidationUtils_1.populatePartialVin(vin),
        techRecord: techRec,
        systemNumber: "",
        primaryVrm,
        secondaryVrms
    };
    return techRecordsService.insertTechRecord(techRecord, msUserDetails)
        .then((data) => {
        return new HTTPResponse_1.default(201, "Technical Record created");
    })
        .catch((error) => {
        console.log(error);
        return new HTTPResponse_1.default(error.statusCode, error.body);
    });
};
exports.postTechRecords = postTechRecords;
