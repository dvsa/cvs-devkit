"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const TechRecordsDAO_1 = __importDefault(require("../models/TechRecordsDAO"));
const TechRecordsService_1 = __importDefault(require("../services/TechRecordsService"));
const HTTPResponse_1 = __importDefault(require("../models/HTTPResponse"));
const formatErrorMessage_1 = require("../utils/formatErrorMessage");
const addProvisionalTechRecord = (event) => {
    const techRecordsDAO = new TechRecordsDAO_1.default();
    const techRecordsService = new TechRecordsService_1.default(techRecordsDAO);
    const sysNum = event.pathParameters.systemNumber;
    const techRec = event.body ? event.body.techRecord : null;
    const msUserDetails = event.body ? event.body.msUserDetails : null;
    if (!techRec || !techRec.length) {
        return Promise.resolve(new HTTPResponse_1.default(400, formatErrorMessage_1.formatErrorMessage("Body is not a valid TechRecord")));
    }
    if (!msUserDetails || !msUserDetails.msUser || !msUserDetails.msOid) {
        return Promise.resolve(new HTTPResponse_1.default(400, formatErrorMessage_1.formatErrorMessage("Microsoft user details not provided")));
    }
    const techRecord = {
        vin: "",
        techRecord: techRec,
        systemNumber: sysNum
    };
    return techRecordsService.addProvisionalTechRecord(techRecord, msUserDetails)
        .then((addedProvisionalTechRecord) => {
        return new HTTPResponse_1.default(200, addedProvisionalTechRecord);
    })
        .catch((error) => {
        console.log(error);
        return new HTTPResponse_1.default(error.statusCode, error.body);
    });
};
exports.addProvisionalTechRecord = addProvisionalTechRecord;
