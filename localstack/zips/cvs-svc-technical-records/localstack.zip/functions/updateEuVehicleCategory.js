"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const TechRecordsDAO_1 = __importDefault(require("../models/TechRecordsDAO"));
const TechRecordsService_1 = __importDefault(require("../services/TechRecordsService"));
const HTTPResponse_1 = __importDefault(require("../models/HTTPResponse"));
const Enums_1 = require("../assets/Enums");
async function updateEuVehicleCategory(event) {
    const techRecordsService = new TechRecordsService_1.default(new TechRecordsDAO_1.default());
    const systemNumber = event.pathParameters.systemNumber;
    const createdById = event.queryStringParameters ? event.queryStringParameters.createdById : undefined;
    const createdByName = event.queryStringParameters ? event.queryStringParameters.createdByName : undefined;
    // to handle when l1e-a is pushed as a value.
    const euVehicleCategoryString = event.queryStringParameters.euVehicleCategory === "l1e-a" ? "l1ea" : event.queryStringParameters.euVehicleCategory;
    const euVehicleCategory = Enums_1.EU_VEHICLE_CATEGORY[euVehicleCategoryString.toUpperCase()];
    try {
        if (euVehicleCategory) {
            return await techRecordsService.updateEuVehicleCategory(systemNumber, euVehicleCategory, createdById, createdByName);
        }
        else {
            return new HTTPResponse_1.default(400, Enums_1.HTTPRESPONSE.INVALID_EU_VEHICLE_CATEGORY);
        }
    }
    catch (error) {
        return new HTTPResponse_1.default(error.statusCode, error.body);
    }
}
exports.updateEuVehicleCategory = updateEuVehicleCategory;
