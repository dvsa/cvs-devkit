"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const Configuration_1 = __importDefault(require("../utils/Configuration"));
const Enums_1 = require("../assets/Enums");
const ValidationUtils_1 = require("../utils/validations/ValidationUtils");
const LambdaService_1 = require("../services/LambdaService");
const dbConfig = Configuration_1.default.getInstance().getDynamoDBConfig();
/* tslint:disable */
let AWS;
// if (process.env._X_AMZN_TRACE_ID) {
//   AWS = require("aws-xray-sdk").captureAWS(require("aws-sdk"));
// } else {
//   console.log("Serverless Offline detected; skipping AWS X-Ray setup");
//   AWS = require("aws-sdk");
// }
AWS = require("aws-sdk");
/* tslint:enable */
const dbClient = new AWS.DynamoDB.DocumentClient(dbConfig.params);
class TechRecordsDAO {
    constructor() {
        this.tableName = dbConfig.table;
        if (!TechRecordsDAO.lambdaInvokeEndpoints) {
            TechRecordsDAO.lambdaInvokeEndpoints = Configuration_1.default.getInstance().getEndpoints();
        }
    }
    getBySearchTerm(searchTerm, searchCriteria) {
        searchTerm = searchTerm.toUpperCase();
        const query = {
            TableName: this.tableName,
            IndexName: "",
            KeyConditionExpression: "",
            ExpressionAttributeNames: {},
            ExpressionAttributeValues: {}
        };
        if (isSysNumSearch(searchCriteria)) { // Query for a specific System Number
            Object.assign(query.ExpressionAttributeValues, {
                ":systemNumber": searchTerm
            });
            Object.assign(query.ExpressionAttributeNames, {
                "#systemNumber": "systemNumber"
            });
            query.IndexName = "SysNumIndex";
            query.KeyConditionExpression = "#systemNumber = :systemNumber";
        }
        else if (isVinSearch(searchTerm, searchCriteria)) { // Query for a full VIN
            Object.assign(query, { IndexName: "VinIndex" });
            Object.assign(query.ExpressionAttributeValues, {
                ":vin": searchTerm
            });
            Object.assign(query.ExpressionAttributeNames, {
                "#vin": "vin"
            });
            query.IndexName = "VinIndex";
            query.KeyConditionExpression = "#vin = :vin";
        }
        else if (isTrailerSearch(searchTerm, searchCriteria)) { // Query for a Trailer ID
            Object.assign(query.ExpressionAttributeValues, {
                ":trailerId": searchTerm
            });
            Object.assign(query.ExpressionAttributeNames, {
                "#trailerId": "trailerId"
            });
            query.IndexName = "TrailerIdIndex";
            query.KeyConditionExpression = "#trailerId = :trailerId";
        }
        else if (isPartialVinSearch(searchTerm, searchCriteria)) { // Query for a partial VIN
            Object.assign(query.ExpressionAttributeValues, {
                ":partialVin": searchTerm
            });
            Object.assign(query.ExpressionAttributeNames, {
                "#partialVin": "partialVin"
            });
            query.IndexName = "PartialVinIndex";
            query.KeyConditionExpression = "#partialVin = :partialVin";
        }
        else if (isVrmSearch(searchTerm, searchCriteria)) { // Query for a VRM
            Object.assign(query.ExpressionAttributeValues, {
                ":vrm": searchTerm
            });
            Object.assign(query.ExpressionAttributeNames, {
                "#vrm": "primaryVrm"
            });
            query.IndexName = "VRMIndex";
            query.KeyConditionExpression = "#vrm = :vrm";
        }
        return dbClient.query(query).promise();
    }
    createSingle(techRecord) {
        techRecord = exports.capitaliseGeneralVehicleAttributes(techRecord);
        const query = {
            TableName: this.tableName,
            Item: techRecord,
            ConditionExpression: "vin <> :vin AND systemNumber <> :systemNumber",
            ExpressionAttributeValues: {
                ":vin": techRecord.vin,
                ":systemNumber": techRecord.systemNumber
            }
        };
        return dbClient.put(query).promise();
    }
    updateSingle(techRecord) {
        techRecord.partialVin = ValidationUtils_1.populatePartialVin(techRecord.vin);
        techRecord = exports.capitaliseGeneralVehicleAttributes(techRecord);
        const query = {
            TableName: this.tableName,
            Key: {
                systemNumber: techRecord.systemNumber,
                vin: techRecord.vin
            },
            UpdateExpression: "set techRecord = :techRecord",
            ConditionExpression: "vin = :vin AND systemNumber = :systemNumber",
            ExpressionAttributeValues: {
                ":vin": techRecord.vin,
                ":systemNumber": techRecord.systemNumber,
                ":techRecord": techRecord.techRecord
            },
            ReturnValues: "ALL_NEW"
        };
        if (techRecord.primaryVrm) {
            query.UpdateExpression += ", primaryVrm = :primaryVrm";
            Object.assign(query.ExpressionAttributeValues, {
                ":primaryVrm": techRecord.primaryVrm
            });
        }
        if (techRecord.secondaryVrms && techRecord.secondaryVrms.length) {
            query.UpdateExpression += ", secondaryVrms = :secondaryVrms";
            Object.assign(query.ExpressionAttributeValues, {
                ":secondaryVrms": techRecord.secondaryVrms
            });
        }
        if (techRecord.trailerId) {
            query.UpdateExpression += ", trailerId = :trailerId";
            Object.assign(query.ExpressionAttributeValues, {
                ":trailerId": techRecord.trailerId
            });
        }
        return dbClient.update(query).promise();
    }
    getTrailerId() {
        const event = {
            path: "/trailerId/",
            httpMethod: "POST",
            resource: "/trailerId/"
        };
        return LambdaService_1.LambdaService.invoke(TechRecordsDAO.lambdaInvokeEndpoints.functions.numberGenerationService.name, event);
    }
    getSystemNumber() {
        const event = {
            path: "/system-number/",
            httpMethod: "POST",
            resource: "/system-number/"
        };
        return LambdaService_1.LambdaService.invoke(TechRecordsDAO.lambdaInvokeEndpoints.functions.numberGenerationService.name, event);
    }
    createMultiple(techRecordItems) {
        const params = this.generatePartialParams();
        techRecordItems.forEach((techRecordItem) => {
            params.RequestItems[this.tableName].push({
                PutRequest: {
                    Item: techRecordItem
                }
            });
        });
        return dbClient.batchWrite(params).promise();
    }
    deleteMultiple(primaryKeysToBeDeleted) {
        const params = this.generatePartialParams();
        primaryKeysToBeDeleted.forEach(([primaryKey, secondaryKey]) => {
            params.RequestItems[this.tableName].push({
                DeleteRequest: {
                    Key: {
                        systemNumber: primaryKey,
                        vin: secondaryKey
                    }
                }
            });
        });
        return dbClient.batchWrite(params).promise();
    }
    generatePartialParams() {
        return {
            RequestItems: {
                [this.tableName]: []
            }
        };
    }
}
exports.default = TechRecordsDAO;
const ONLY_DIGITS_REGEX = /^\d+$/;
const DIGITS_AND_SPECIAL_REGEX = /^[\d /\\*-]+$/;
const TRAILER_REGEX = /^[a-zA-Z]\d{6}$/;
const isSysNumSearch = (searchCriteria) => {
    return Enums_1.SEARCHCRITERIA.SYSTEM_NUMBER === searchCriteria;
};
const isVinSearch = (searchTerm, searchCriteria) => {
    return Enums_1.SEARCHCRITERIA.VIN === searchCriteria || Enums_1.SEARCHCRITERIA.ALL === searchCriteria && searchTerm.length >= 9;
};
exports.isVinSearch = isVinSearch;
const isTrailerSearch = (searchTerm, searchCriteria) => {
    return Enums_1.SEARCHCRITERIA.TRAILERID === searchCriteria || Enums_1.SEARCHCRITERIA.ALL === searchCriteria && isTrailerId(searchTerm);
};
exports.isTrailerSearch = isTrailerSearch;
const isPartialVinSearch = (searchTerm, searchCriteria) => {
    return Enums_1.SEARCHCRITERIA.PARTIALVIN === searchCriteria || Enums_1.SEARCHCRITERIA.ALL === searchCriteria && searchTerm.length === 6 && DIGITS_AND_SPECIAL_REGEX.test(searchTerm);
};
exports.isPartialVinSearch = isPartialVinSearch;
const isVrmSearch = (searchTerm, searchCriteria) => {
    return Enums_1.SEARCHCRITERIA.VRM === searchCriteria || Enums_1.SEARCHCRITERIA.ALL === searchCriteria && searchTerm.length >= 3 && searchTerm.length <= 8;
};
exports.isVrmSearch = isVrmSearch;
const isTrailerId = (searchTerm) => {
    // Exactly 8 numbers
    const isAllNumbersTrailerId = searchTerm.length === 8 && ONLY_DIGITS_REGEX.test(searchTerm);
    // A letter followed by exactly 6 numbers
    const isLetterAndNumbersTrailerId = TRAILER_REGEX.test(searchTerm);
    return isAllNumbersTrailerId || isLetterAndNumbersTrailerId;
};
exports.isTrailerId = isTrailerId;
exports.capitaliseGeneralVehicleAttributes = (techRecord) => {
    var _a, _b, _c, _d, _e;
    techRecord.vin = (_a = techRecord.vin) === null || _a === void 0 ? void 0 : _a.toUpperCase();
    techRecord.partialVin = (_b = techRecord.partialVin) === null || _b === void 0 ? void 0 : _b.toUpperCase();
    techRecord.primaryVrm = (_c = techRecord.primaryVrm) === null || _c === void 0 ? void 0 : _c.toUpperCase();
    techRecord.trailerId = (_d = techRecord.trailerId) === null || _d === void 0 ? void 0 : _d.toUpperCase();
    techRecord.secondaryVrms = (_e = techRecord.secondaryVrms) === null || _e === void 0 ? void 0 : _e.map((vrm) => vrm.toUpperCase());
    return techRecord;
};
