"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatErrorMessage = (errorMessage) => {
    return {
        errors: Array.of(errorMessage)
    };
};
