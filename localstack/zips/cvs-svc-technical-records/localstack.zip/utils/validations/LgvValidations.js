"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const joi_1 = __importDefault(require("@hapi/joi"));
const Enums_1 = require("../../assets/Enums");
const CommonSchema_1 = require("./CommonSchema");
exports.lgvValidation = CommonSchema_1.commonSchemaLgvMotorcycleCar.keys({
    vehicleSubclass: joi_1.default.array().items(joi_1.default.string().valid(...Enums_1.VEHICLE_SUBCLASS)).required(),
    vehicleClass: joi_1.default.object().keys({
        code: joi_1.default.any().when("description", {
            is: joi_1.default.string().valid(...Enums_1.VEHICLE_CLASS_DESCRIPTION).required(),
            then: joi_1.default.string().optional(),
            otherwise: joi_1.default.object().forbidden()
        }),
        description: joi_1.default.string().valid(...Enums_1.VEHICLE_CLASS_DESCRIPTION).required()
    }).optional().allow(null)
}).required();
