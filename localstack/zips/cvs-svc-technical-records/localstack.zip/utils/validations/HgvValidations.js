"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const joi_1 = __importDefault(require("@hapi/joi"));
const CommonSchema_1 = require("./CommonSchema");
const Enums_1 = require("../../assets/Enums");
const AdrValidation_1 = require("./AdrValidation");
exports.hgvValidation = CommonSchema_1.commonSchema.keys({
    axles: joi_1.default.array().items(CommonSchema_1.axlesSchema.keys({
        weights: CommonSchema_1.weightsSchema.keys({
            eecWeight: joi_1.default.number().min(0).max(99999).optional().allow(null)
        }).required(),
    })).min(1).required(),
    roadFriendly: joi_1.default.boolean().required(),
    drawbarCouplingFitted: joi_1.default.boolean().required(),
    offRoad: joi_1.default.boolean().optional().required(),
    make: joi_1.default.string().max(30).required(),
    model: joi_1.default.string().max(30).required(),
    speedLimiterMrk: joi_1.default.boolean().required(),
    tachoExemptMrk: joi_1.default.boolean().required(),
    euroStandard: joi_1.default.string().required(),
    fuelPropulsionSystem: joi_1.default.string().valid(...Enums_1.FUEL_PROPULSION_SYSTEM).required(),
    numberOfWheelsDriven: joi_1.default.number().min(0).max(9999).required().allow(null),
    emissionsLimit: joi_1.default.number().min(0).max(99).optional().allow(null),
    trainDesignWeight: joi_1.default.number().min(0).max(99999).optional().allow(null),
    grossEecWeight: joi_1.default.number().min(0).max(99999).optional().allow(null),
    trainGbWeight: joi_1.default.number().min(0).max(99999).required(),
    trainEecWeight: joi_1.default.number().min(0).max(99999).optional().allow(null),
    maxTrainGbWeight: joi_1.default.number().min(0).max(99999).required(),
    maxTrainEecWeight: joi_1.default.number().min(0).max(99999).optional().allow(null),
    maxTrainDesignWeight: joi_1.default.number().min(0).max(99999).optional().allow(null),
    tyreUseCode: joi_1.default.string().max(2).optional().allow(null),
    dimensions: joi_1.default.object().keys({
        length: joi_1.default.number().min(0).max(99999).required(),
        width: joi_1.default.number().min(0).max(99999).required(),
        axleSpacing: joi_1.default.array().items(joi_1.default.object().keys({
            value: joi_1.default.number().min(0).max(99999).optional().allow(null),
            axles: joi_1.default.string().optional()
        })).optional()
    }).required(),
    frontAxleToRearAxle: joi_1.default.number().min(0).max(99999).required(),
    frontAxleTo5thWheelCouplingMin: joi_1.default.number().min(0).max(99999).optional().allow(null),
    frontAxleTo5thWheelCouplingMax: joi_1.default.number().min(0).max(99999).optional().allow(null),
    frontAxleTo5thWheelMin: joi_1.default.number().min(0).max(99999).optional().allow(null),
    frontAxleTo5thWheelMax: joi_1.default.number().min(0).max(99999).optional().allow(null),
    notes: joi_1.default.string().optional().allow(null),
    adrDetails: AdrValidation_1.adrValidation
}).required();
