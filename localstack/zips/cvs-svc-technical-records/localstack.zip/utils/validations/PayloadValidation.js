"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const Enums_1 = require("../../assets/Enums");
const joi_1 = __importDefault(require("@hapi/joi"));
const Configuration_1 = __importDefault(require("../Configuration"));
const fromValidation = __importStar(require("./"));
const checkIfTankOrBattery = (payload) => {
    let isTankOrBattery = false;
    if (payload.adrDetails && payload.adrDetails.vehicleDetails && payload.adrDetails.vehicleDetails.type) {
        const vehicleDetailsType = payload.adrDetails.vehicleDetails.type.toLowerCase();
        if ((vehicleDetailsType.indexOf("battery") !== -1) || (vehicleDetailsType.indexOf("tank") !== -1)) {
            isTankOrBattery = true;
        }
    }
    return isTankOrBattery;
};
const featureFlagValidation = (validationSchema, payload, validateEntireRecord, options) => {
    const allowAdrUpdatesOnlyFlag = Configuration_1.default.getInstance().getAllowAdrUpdatesOnlyFlag();
    if (allowAdrUpdatesOnlyFlag && !validateEntireRecord) {
        Object.assign(options, { stripUnknown: true });
        const { adrDetails, reasonForCreation } = payload;
        return fromValidation.validateOnlyAdr.validate({ adrDetails, reasonForCreation }, options);
    }
    else {
        return validationSchema.validate(payload, options);
    }
};
exports.validatePayload = (payload, validateEntireRecord = true) => {
    const isTankOrBattery = checkIfTankOrBattery(payload);
    const abortOptions = { abortEarly: false };
    const hgvTrlOptions = Object.assign(Object.assign({}, abortOptions), { context: { isTankOrBattery } });
    if (payload.vehicleType === Enums_1.VEHICLE_TYPE.HGV) {
        return featureFlagValidation(fromValidation.hgvValidation, payload, validateEntireRecord, hgvTrlOptions);
    }
    else if (payload.vehicleType === Enums_1.VEHICLE_TYPE.PSV) {
        return fromValidation.psvValidation.validate(payload, abortOptions);
    }
    else if (payload.vehicleType === Enums_1.VEHICLE_TYPE.TRL) {
        return featureFlagValidation(fromValidation.trlValidation, payload, validateEntireRecord, hgvTrlOptions);
    }
    else if (payload.vehicleType === Enums_1.VEHICLE_TYPE.LGV) {
        return fromValidation.lgvValidation.validate(payload, abortOptions);
    }
    else if (payload.vehicleType === Enums_1.VEHICLE_TYPE.CAR) {
        return fromValidation.carValidation.validate(payload, abortOptions);
    }
    else if (payload.vehicleType === Enums_1.VEHICLE_TYPE.MOTORCYCLE) {
        return fromValidation.motorcycleValidation.validate(payload, abortOptions);
    }
    else {
        return {
            error: {
                details: [{ message: Enums_1.ERRORS.VEHICLE_TYPE_ERROR }]
            }
        };
    }
};
exports.validatePrimaryVrm = joi_1.default.string().min(1).max(9);
exports.validateSecondaryVrms = joi_1.default.array().items(joi_1.default.string().min(1).max(9));
exports.validateTrailerId = joi_1.default.string().min(7).max(8);
exports.isValidSearchCriteria = (specifiedCriteria) => {
    const vals = Object.values(Enums_1.SEARCHCRITERIA);
    // return vals.includes(specifiedCriteria); //TODO reinstate for proper input validation
    return true;
};
