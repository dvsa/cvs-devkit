"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* tslint:disable */
const Joi = require("@hapi/joi")
    .extend(require("@hapi/joi-date"));
const Enums_1 = require("../../assets/Enums");
exports.coreMandatoryVehicleAttributes = Joi.object().keys({
    vin: Joi.string().required(),
    systemNumber: Joi.string().required()
}).required();
exports.psvHgvCarLgvMotoCoreMandatoryVehicleAttributes = exports.coreMandatoryVehicleAttributes.keys({
    primaryVrm: Joi.string().required()
}).required();
exports.trlCoreMandatoryVehicleAttributes = exports.coreMandatoryVehicleAttributes.keys({
    trailerId: Joi.string().required()
}).required();
// common fields for core mandatory attributes for all vehicle types
exports.coreMandatoryCommonSchema = Joi.object().keys({
    vehicleType: Joi.string().valid(...Enums_1.VEHICLE_TYPE_VALIDATION).required(),
    noOfAxles: Joi.number().required(),
    statusCode: Joi.string().valid(...Enums_1.STATUS_CODES).required(),
    reasonForCreation: Joi.string().required(),
    createdAt: Joi.string().required()
}).required();
// common fields for core mandatory attributes for hgv, psv and trl
exports.coreMandatoryCommonSchemaPsvHgvTrl = exports.coreMandatoryCommonSchema.keys({
    vehicleConfiguration: Joi.string().valid(...Enums_1.VEHICLE_CONFIGURATION).required(),
    vehicleClass: Joi.object().keys({
        code: Joi.string().required(),
        description: Joi.string().valid(...Enums_1.VEHICLE_CLASS_DESCRIPTION).required()
    }).required()
}).required();
exports.coreMandatoryCommonSchemaLgvMotorcycleCar = exports.coreMandatoryCommonSchema;
exports.psvCoreMandatorySchema = exports.coreMandatoryCommonSchemaPsvHgvTrl.keys({
    vehicleSize: Joi.string().valid(...Enums_1.VEHICLE_SIZE).required(),
    seatsLowerDeck: Joi.number().required(),
    seatsUpperDeck: Joi.number().required(),
    numberOfWheelsDriven: Joi.number().required()
}).required();
exports.trlCoreMandatorySchema = exports.coreMandatoryCommonSchemaPsvHgvTrl;
exports.hgvCoreMandatorySchema = exports.coreMandatoryCommonSchemaPsvHgvTrl.keys({
    numberOfWheelsDriven: Joi.number().required()
});
exports.carCoreMandatorySchema = exports.coreMandatoryCommonSchemaLgvMotorcycleCar.keys({
    vehicleSubclass: Joi.array().items(Joi.string().valid(...Enums_1.VEHICLE_SUBCLASS)).required()
}).required();
exports.lgvCoreMandatorySchema = exports.carCoreMandatorySchema;
exports.motorcycleCoreMandatorySchema = exports.coreMandatoryCommonSchemaLgvMotorcycleCar.keys({
    vehicleClass: Joi.object().keys({
        code: Joi.string().required(),
        description: Joi.string().valid(...Enums_1.VEHICLE_CLASS_DESCRIPTION).required()
    }).required(),
    numberOfWheelsDriven: Joi.number().required()
}).required();
