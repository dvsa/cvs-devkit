"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* tslint:disable */
const Joi = require("@hapi/joi")
    .extend(require("@hapi/joi-date"));
const Enums_1 = require("../../assets/Enums");
const CommonSchema_1 = require("../validations/CommonSchema");
exports.nonCoreTyresSchema = Joi.object().keys({
    tyreCode: Joi.number().required(),
    tyreSize: Joi.string().required(),
    fitmentCode: Joi.string().valid(...Enums_1.FITMENT_CODE).required()
}).required();
exports.nonCoreAxlesSchema = Joi.object().keys({
    weights: CommonSchema_1.weightsSchema,
    tyres: exports.nonCoreTyresSchema
}).required();
exports.nonCoreApplicantDetailsSchema = Joi.object().keys({
    name: Joi.string().max(150).required(),
    address1: Joi.string().max(60).required(),
    address2: Joi.string().max(60).required(),
    postTown: Joi.string().max(60).required()
}).required();
exports.nonCoreMandatoryCommonSchemaPsvHgvTrl = Joi.object().keys({
    approvalType: Joi.string().valid(...Enums_1.APPROVAL_TYPE).required(),
    manufactureYear: Joi.number().required(),
    bodyType: Joi.object().keys({
        code: Joi.any().when("description", {
            is: Joi.string().valid(...Enums_1.BODY_TYPE_DESCRIPTION).required(),
            then: Joi.string().optional(),
            otherwise: Joi.object().forbidden()
        }),
        description: Joi.string().valid(...Enums_1.BODY_TYPE_DESCRIPTION).required()
    }).required(),
    grossGbWeight: Joi.number().min(0).max(99999).required(),
    grossDesignWeight: Joi.number().min(0).max(99999).required(),
    brakes: CommonSchema_1.brakesSchema,
    euVehicleCategory: Joi.string().valid(...Enums_1.EU_VEHICLE_CATEGORY_VALIDATION).required(),
    axles: Joi.array().items(exports.nonCoreAxlesSchema).min(1).required()
}).required();
exports.psvNonCoreMandatorySchema = exports.nonCoreMandatoryCommonSchemaPsvHgvTrl.keys({
    euroStandard: Joi.string().required(),
    regnDate: Joi.date().format("YYYY-MM-DD").required(),
    speedLimiterMrk: Joi.boolean().required(),
    tachoExemptMrk: Joi.boolean().required(),
    fuelPropulsionSystem: Joi.string().valid(...Enums_1.FUEL_PROPULSION_SYSTEM).required(),
    axles: Joi.array().items(exports.nonCoreAxlesSchema.keys({
        parkingBrakeMrk: Joi.boolean().required(),
        axleNumber: Joi.number().required(),
        weights: CommonSchema_1.weightsSchema.keys({
            ladenWeight: Joi.number().required(),
            kerbWeight: Joi.number().required()
        }).required(),
        tyres: exports.nonCoreTyresSchema.keys({
            speedCategorySymbol: Joi.string().valid(...Enums_1.SPEED_CATEGORY_SYMBOL).required(),
        }).required(),
    })).min(1).required(),
    standingCapacity: Joi.number().required(),
    numberOfSeatbelts: Joi.string().required(),
    bodyMake: Joi.string().required(),
    bodyModel: Joi.string().required(),
    chassisMake: Joi.string().required(),
    chassisModel: Joi.string().required(),
    grossKerbWeight: Joi.number().required(),
    grossLadenWeight: Joi.number().required(),
    dda: Joi.object().keys({
        certificateIssued: Joi.boolean().required()
    }).required(),
    brakes: CommonSchema_1.brakesSchema.keys({
        brakeCode: Joi.string().required(),
        dataTrBrakeOne: Joi.string().required(),
        dataTrBrakeTwo: Joi.string().required(),
        dataTrBrakeThree: Joi.string().required(),
        brakeForceWheelsNotLocked: Joi.object().keys({
            parkingBrakeForceA: Joi.number().required(),
            secondaryBrakeForceA: Joi.number().required(),
            serviceBrakeForceA: Joi.number().required()
        }).required(),
        brakeForceWheelsUpToHalfLocked: Joi.object().keys({
            parkingBrakeForceB: Joi.number().required(),
            secondaryBrakeForceB: Joi.number().required(),
            serviceBrakeForceB: Joi.number().required()
        }).required()
    }).required()
}).required();
exports.hgvNonCoreMandatorySchema = exports.nonCoreMandatoryCommonSchemaPsvHgvTrl.keys({
    make: Joi.string().required(),
    model: Joi.string().required(),
    trainGbWeight: Joi.number().required(),
    maxTrainGbWeight: Joi.number().required(),
    tyreUseCode: Joi.string().required(),
    euroStandard: Joi.string().required(),
    dimensions: Joi.object().keys({
        length: Joi.number().required(),
        width: Joi.number().required(),
    }).required(),
    frontAxleTo5thWheelMin: Joi.number().required(),
    frontAxleTo5thWheelMax: Joi.number().required(),
    frontAxleToRearAxle: Joi.number().required(),
    notes: Joi.string().required(),
    regnDate: Joi.date().format("YYYY-MM-DD").required(),
    speedLimiterMrk: Joi.boolean().required(),
    tachoExemptMrk: Joi.boolean().required(),
    fuelPropulsionSystem: Joi.string().valid(...Enums_1.FUEL_PROPULSION_SYSTEM).required(),
    roadFriendly: Joi.boolean().required(),
    drawbarCouplingFitted: Joi.boolean().required(),
    offRoad: Joi.boolean().optional().required(),
    applicantDetails: exports.nonCoreApplicantDetailsSchema
});
exports.trlNonCoreMandatorySchema = exports.nonCoreMandatoryCommonSchemaPsvHgvTrl.keys({
    primaryVrm: Joi.string().required(),
    make: Joi.string().required(),
    model: Joi.string().required(),
    firstUseDate: Joi.date().format("YYYY-MM-DD").required(),
    maxLoadOnCoupling: Joi.number().required(),
    tyreUseCode: Joi.string().required(),
    suspensionType: Joi.string().required(),
    couplingType: Joi.string().required(),
    dimensions: Joi.object().keys({
        length: Joi.number().required(),
        width: Joi.number().required(),
        axleSpacing: Joi.array().items(Joi.object().keys({
            value: Joi.number().required(),
            axles: Joi.string().required()
        })).min(1).required()
    }).required(),
    frontAxleToRearAxle: Joi.number().required(),
    rearAxleToRearTrl: Joi.number().required(),
    couplingCenterToRearAxleMin: Joi.number().required(),
    couplingCenterToRearAxleMax: Joi.number().required(),
    couplingCenterToRearTrlMin: Joi.number().required(),
    couplingCenterToRearTrlMax: Joi.number().required(),
    centreOfRearmostAxleToRearOfTrl: Joi.number().required(),
    notes: Joi.string().required(),
    axles: Joi.array().items(exports.nonCoreAxlesSchema.keys({
        parkingBrakeMrk: Joi.boolean().required(),
        brakes: Joi.object().keys({
            brakeActuator: Joi.number().required(),
            leverLength: Joi.number().required(),
        }).required()
    })).min(1).required(),
    brakes: CommonSchema_1.brakesSchema.keys({
        antilockBrakingSystem: Joi.boolean().required()
    }).required(),
    roadFriendly: Joi.boolean().required(),
    applicantDetails: exports.nonCoreApplicantDetailsSchema,
    purchaserDetails: exports.nonCoreApplicantDetailsSchema,
    manufacturerDetails: exports.nonCoreApplicantDetailsSchema
});
