"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const HTTPError_1 = __importDefault(require("../../models/HTTPError"));
const Enums_1 = require("../../assets/Enums");
const coreMandatoryValidation = __importStar(require("./CoreMandatoryValidations"));
const nonCoreMandatoryValidation = __importStar(require("./NonCoreMandatoryValidations"));
const validateRecordCompleteness = (validationSchema, techRecordFields) => {
    if (validationSchema) {
        return validationSchema.validate(techRecordFields, { stripUnknown: true });
    }
    else {
        return undefined;
    }
};
const validateVehicleAttributes = (vehicleType, vehicleAttributes) => {
    if (vehicleType !== Enums_1.VEHICLE_TYPE.TRL) {
        return validateRecordCompleteness(coreMandatoryValidation.psvHgvCarLgvMotoCoreMandatoryVehicleAttributes, vehicleAttributes);
    }
    else {
        return validateRecordCompleteness(coreMandatoryValidation.trlCoreMandatoryVehicleAttributes, vehicleAttributes);
    }
};
const validateCoreAndNonCoreMandatoryTechRecordAttributes = (vehicleType, techRecordWrapper) => {
    let coreMandatoryValidationResult;
    let nonCoreMandatoryValidationResult;
    let coreMandatorySchema;
    let nonCoreMandatorySchema;
    let techRecord = techRecordWrapper.techRecord[0];
    if (vehicleType === Enums_1.VEHICLE_TYPE.HGV) {
        coreMandatorySchema = coreMandatoryValidation.hgvCoreMandatorySchema;
        nonCoreMandatorySchema = nonCoreMandatoryValidation.hgvNonCoreMandatorySchema;
    }
    else if (vehicleType === Enums_1.VEHICLE_TYPE.PSV) {
        coreMandatorySchema = coreMandatoryValidation.psvCoreMandatorySchema;
        nonCoreMandatorySchema = nonCoreMandatoryValidation.psvNonCoreMandatorySchema;
    }
    else if (vehicleType === Enums_1.VEHICLE_TYPE.TRL) {
        techRecord = Object.assign(Object.assign({}, techRecord), { primaryVrm: techRecordWrapper.primaryVrm });
        coreMandatorySchema = coreMandatoryValidation.trlCoreMandatorySchema;
        nonCoreMandatorySchema = nonCoreMandatoryValidation.trlNonCoreMandatorySchema;
    }
    else if (vehicleType === Enums_1.VEHICLE_TYPE.LGV) {
        coreMandatorySchema = coreMandatoryValidation.lgvCoreMandatorySchema;
    }
    else if (vehicleType === Enums_1.VEHICLE_TYPE.CAR) {
        coreMandatorySchema = coreMandatoryValidation.carCoreMandatorySchema;
    }
    else if (vehicleType === Enums_1.VEHICLE_TYPE.MOTORCYCLE) {
        coreMandatorySchema = coreMandatoryValidation.motorcycleCoreMandatorySchema;
    }
    else {
        throw new HTTPError_1.default(400, Enums_1.ERRORS.VEHICLE_TYPE_ERROR);
    }
    coreMandatoryValidationResult = validateRecordCompleteness(coreMandatorySchema, techRecord);
    nonCoreMandatoryValidationResult = validateRecordCompleteness(nonCoreMandatorySchema, techRecord);
    return { coreMandatoryValidationResult, nonCoreMandatoryValidationResult };
};
exports.computeRecordCompleteness = (techRecordWrapper) => {
    var _a, _b, _c;
    let recordCompleteness = Enums_1.RECORD_COMPLETENESS_ENUM.COMPLETE;
    let isCoreMandatoryValid = true;
    let isNonCoreMandatoryValid = true;
    if (!techRecordWrapper.systemNumber) {
        throw new HTTPError_1.default(400, Enums_1.ERRORS.SYSTEM_NUMBER_GENERATION_FAILED);
    }
    const generalAttributes = {
        systemNumber: techRecordWrapper.systemNumber,
        vin: techRecordWrapper.vin,
        primaryVrm: techRecordWrapper.primaryVrm,
        trailerId: techRecordWrapper.trailerId
    };
    const vehicleType = techRecordWrapper.techRecord[0].vehicleType;
    if (!vehicleType) {
        return Enums_1.RECORD_COMPLETENESS_ENUM.SKELETON;
    }
    if ((_a = validateVehicleAttributes(vehicleType, generalAttributes)) === null || _a === void 0 ? void 0 : _a.error) {
        return Enums_1.RECORD_COMPLETENESS_ENUM.SKELETON;
    }
    const mandatoryAttributesValidationResult = validateCoreAndNonCoreMandatoryTechRecordAttributes(vehicleType, techRecordWrapper);
    isCoreMandatoryValid = !((_b = mandatoryAttributesValidationResult.coreMandatoryValidationResult) === null || _b === void 0 ? void 0 : _b.error);
    isNonCoreMandatoryValid = !((_c = mandatoryAttributesValidationResult.nonCoreMandatoryValidationResult) === null || _c === void 0 ? void 0 : _c.error);
    if (!isCoreMandatoryValid) {
        recordCompleteness = Enums_1.RECORD_COMPLETENESS_ENUM.SKELETON;
    }
    else if (isCoreMandatoryValid && !isNonCoreMandatoryValid) {
        recordCompleteness = Enums_1.RECORD_COMPLETENESS_ENUM.TESTABLE;
    }
    else {
        recordCompleteness = Enums_1.RECORD_COMPLETENESS_ENUM.COMPLETE;
    }
    return recordCompleteness;
};
