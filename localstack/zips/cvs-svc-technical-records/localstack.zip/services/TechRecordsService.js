"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const HTTPError_1 = __importDefault(require("../models/HTTPError"));
const Enums_1 = require("../assets/Enums");
const fromValidation = __importStar(require("../utils/validations"));
const HTTPResponse_1 = __importDefault(require("../models/HTTPResponse"));
const formatErrorMessage_1 = require("../utils/formatErrorMessage");
const lodash_1 = require("lodash");
const ComputeRecordCompleteness_1 = require("../utils/record-completeness/ComputeRecordCompleteness");
/**
 * Fetches the entire list of Technical Records from the database.
 * @returns Promise
 */
class TechRecordsService {
    constructor(techRecordsDAO) {
        this.techRecordsDAO = techRecordsDAO;
    }
    getTechRecordsList(searchTerm, status, searchCriteria = Enums_1.SEARCHCRITERIA.ALL) {
        return this.techRecordsDAO.getBySearchTerm(searchTerm, searchCriteria)
            .then((data) => {
            if (data.Count === 0) {
                throw new HTTPError_1.default(404, Enums_1.HTTPRESPONSE.RESOURCE_NOT_FOUND);
            }
            // Formatting the object for lambda function
            let techRecordItems = data.Items;
            if (status !== Enums_1.STATUS.ALL) {
                techRecordItems = this.filterTechRecordsByStatus(techRecordItems, status);
            }
            techRecordItems = this.formatTechRecordItemsForResponse(techRecordItems);
            return techRecordItems;
        })
            .catch((error) => {
            if (!(error instanceof HTTPError_1.default)) {
                console.error(error);
                error.statusCode = 500;
                error.body = Enums_1.HTTPRESPONSE.INTERNAL_SERVER_ERROR;
            }
            throw new HTTPError_1.default(error.statusCode, error.body);
        });
    }
    filterTechRecordsByStatus(techRecordItems, status) {
        const recordsToReturn = [];
        for (let techRecordItem of techRecordItems) {
            techRecordItem = this.filterTechRecordsForIndividualVehicleByStatus(techRecordItem, status);
            if (techRecordItem.techRecord.length > 0) {
                recordsToReturn.push(techRecordItem);
            }
        }
        return recordsToReturn;
    }
    filterTechRecordsForIndividualVehicleByStatus(techRecordItem, status) {
        const originalTechRecordItem = lodash_1.cloneDeep(techRecordItem);
        let provisionalOverCurrent = false;
        if (status === Enums_1.STATUS.PROVISIONAL_OVER_CURRENT) {
            provisionalOverCurrent = true;
            status = Enums_1.STATUS.PROVISIONAL;
        }
        techRecordItem.techRecord = techRecordItem.techRecord
            .filter((techRecord) => {
            return techRecord.statusCode === status;
        });
        const { length } = originalTechRecordItem.techRecord;
        const { statusCode } = originalTechRecordItem.techRecord[0];
        if (provisionalOverCurrent && length === 1 && techRecordItem.techRecord.length > 0 && (statusCode === Enums_1.STATUS.CURRENT || statusCode === Enums_1.STATUS.PROVISIONAL)) {
            return techRecordItem;
        }
        if (provisionalOverCurrent && ((length === techRecordItem.techRecord.length) || (0 === techRecordItem.techRecord.length))) {
            techRecordItem = this.filterTechRecordsForIndividualVehicleByStatus(originalTechRecordItem, Enums_1.STATUS.CURRENT);
        }
        if (techRecordItem.techRecord.length <= 0) {
            throw new HTTPError_1.default(404, Enums_1.HTTPRESPONSE.RESOURCE_NOT_FOUND);
        }
        return techRecordItem;
    }
    formatTechRecordItemsForResponse(techRecordItems) {
        const recordsToReturn = [];
        for (let techRecordItem of techRecordItems) {
            techRecordItem = this.formatTechRecordItemForResponse(techRecordItem);
            recordsToReturn.push(techRecordItem);
        }
        return recordsToReturn;
    }
    formatTechRecordItemForResponse(techRecordItem) {
        // Adding primary and secondary VRMs in the same array
        const vrms = [];
        if (techRecordItem.primaryVrm) {
            vrms.push({ vrm: techRecordItem.primaryVrm, isPrimary: true });
        }
        if (techRecordItem.secondaryVrms) {
            for (const secondaryVrm of techRecordItem.secondaryVrms) {
                vrms.push({ vrm: secondaryVrm, isPrimary: false });
            }
        }
        Object.assign(techRecordItem, {
            vrms
        });
        // Cleaning up unneeded properties
        delete techRecordItem.primaryVrm; // No longer needed
        delete techRecordItem.secondaryVrms; // No longer needed
        delete techRecordItem.partialVin; // No longer needed
        techRecordItem.techRecord.forEach((techRecord) => {
            if (techRecord.euroStandard !== undefined && techRecord.euroStandard !== null) {
                techRecord.euroStandard = techRecord.euroStandard.toString();
            }
        });
        return techRecordItem;
    }
    mapValidationErrors(validationError) {
        return {
            errors: validationError.details.map((detail) => {
                return detail.message;
            })
        };
    }
    checkValidationErrors(validation) {
        if (validation.error) {
            throw new HTTPError_1.default(400, this.mapValidationErrors(validation.error));
        }
    }
    async insertTechRecord(techRecord, msUserDetails) {
        const isPayloadValid = fromValidation.validatePayload(techRecord.techRecord[0]);
        this.checkValidationErrors(isPayloadValid);
        if (!this.validateVrms(techRecord)) {
            return Promise.reject({ statusCode: 400, body: "Primary or secondaryVrms are not valid" });
        }
        techRecord.systemNumber = await this.generateSystemNumber();
        if (techRecord.techRecord[0].vehicleType === Enums_1.VEHICLE_TYPE.TRL) {
            techRecord.trailerId = await this.setTrailerId();
        }
        techRecord.techRecord[0] = isPayloadValid.value;
        fromValidation.populateFields(techRecord.techRecord[0]);
        this.setAuditDetailsAndStatusCodeForNewRecord(techRecord.techRecord[0], msUserDetails);
        techRecord.techRecord[0].recordCompleteness = ComputeRecordCompleteness_1.computeRecordCompleteness(techRecord);
        return this.techRecordsDAO.createSingle(techRecord)
            .then((data) => {
            return data;
        })
            .catch((error) => {
            throw new HTTPError_1.default(error.statusCode, error.message);
        });
    }
    async generateSystemNumber() {
        try {
            const systemNumberObj = await this.techRecordsDAO.getSystemNumber();
            if (systemNumberObj.error) {
                return Promise.reject({ statusCode: 500, body: systemNumberObj.error });
            }
            if (!systemNumberObj.systemNumber) {
                return Promise.reject({ statusCode: 500, body: Enums_1.ERRORS.SYSTEM_NUMBER_GENERATION_FAILED });
            }
            return systemNumberObj.systemNumber;
        }
        catch (error) {
            return Promise.reject({ statusCode: 500, body: error });
        }
    }
    async setTrailerId() {
        try {
            const trailerIdObj = await this.techRecordsDAO.getTrailerId();
            if (trailerIdObj.error) {
                return Promise.reject({ statusCode: 500, body: trailerIdObj.error });
            }
            if (!trailerIdObj.trailerId) {
                return Promise.reject({ statusCode: 500, body: Enums_1.ERRORS.TRAILER_ID_GENERATION_FAILED });
            }
            return trailerIdObj.trailerId;
        }
        catch (error) {
            return Promise.reject({ statusCode: 500, body: error });
        }
    }
    validateVrms(techRecord) {
        let areVrmsValid = true;
        const vehicleType = techRecord.techRecord[0].vehicleType;
        if (vehicleType !== Enums_1.VEHICLE_TYPE.TRL && !techRecord.primaryVrm) {
            areVrmsValid = false;
        }
        else {
            const isValid = fromValidation.validatePrimaryVrm.validate(techRecord.primaryVrm);
            if (isValid.error) {
                areVrmsValid = false;
            }
        }
        if (techRecord.secondaryVrms) {
            const isValid = fromValidation.validateSecondaryVrms.validate(techRecord.secondaryVrms);
            if (isValid.error) {
                areVrmsValid = false;
            }
        }
        return areVrmsValid;
    }
    setAuditDetailsAndStatusCodeForNewRecord(techRecord, msUserDetails) {
        techRecord.createdAt = new Date().toISOString();
        techRecord.createdByName = msUserDetails.msUser;
        techRecord.createdById = msUserDetails.msOid;
        techRecord.statusCode = Enums_1.STATUS.PROVISIONAL;
    }
    updateTechRecord(techRecord, msUserDetails, oldStatusCode) {
        return this.manageUpdateLogic(techRecord, msUserDetails, oldStatusCode);
    }
    manageUpdateLogic(updatedTechRecord, msUserDetails, oldStatusCode) {
        return this.createAndArchiveTechRecord(updatedTechRecord, msUserDetails, oldStatusCode)
            .then((data) => {
            return this.techRecordsDAO.updateSingle(data)
                .then((updatedData) => {
                return this.formatTechRecordItemForResponse(updatedData.Attributes);
            })
                .catch((error) => {
                throw new HTTPError_1.default(error.statusCode, formatErrorMessage_1.formatErrorMessage(error.message));
            });
        })
            .catch((error) => {
            throw new HTTPError_1.default(error.statusCode, error.body);
        });
    }
    async updateAttributesOutsideTechRecordsArray(uniqueRecord, techRecord) {
        uniqueRecord.secondaryVrms = [];
        for (const vrm of uniqueRecord.vrms) {
            if (vrm.isPrimary) {
                uniqueRecord.primaryVrm = vrm.vrm;
            }
            else {
                uniqueRecord.secondaryVrms.push(vrm.vrm);
            }
        }
        if (techRecord.secondaryVrms) {
            const areSecondaryVrmsValid = fromValidation.validateSecondaryVrms.validate(techRecord.secondaryVrms);
            if (areSecondaryVrmsValid.error) {
                return Promise.reject({ statusCode: 400, body: formatErrorMessage_1.formatErrorMessage("SecondaryVrms are invalid") });
            }
            uniqueRecord.secondaryVrms = techRecord.secondaryVrms;
        }
        if (techRecord.primaryVrm && uniqueRecord.primaryVrm !== techRecord.primaryVrm) {
            const isPrimaryVrmValid = fromValidation.validatePrimaryVrm.validate(techRecord.primaryVrm);
            if (isPrimaryVrmValid.error) {
                return Promise.reject({ statusCode: 400, body: formatErrorMessage_1.formatErrorMessage("PrimaryVrm is invalid") });
            }
            const primaryVrmRecords = await this.techRecordsDAO.getBySearchTerm(techRecord.primaryVrm, Enums_1.SEARCHCRITERIA.VRM);
            if (primaryVrmRecords.Count > 0) {
                return Promise.reject({
                    statusCode: 400,
                    body: formatErrorMessage_1.formatErrorMessage(`Primary VRM ${techRecord.primaryVrm} already exists`)
                });
            }
            const previousVrm = uniqueRecord.primaryVrm;
            if (previousVrm) {
                uniqueRecord.secondaryVrms.push(previousVrm);
            }
            uniqueRecord.primaryVrm = techRecord.primaryVrm;
            techRecord.techRecord[0].reasonForCreation = `VRM updated from ${previousVrm} to ${techRecord.primaryVrm}. ` + techRecord.techRecord[0].reasonForCreation;
        }
        if (techRecord.trailerId && techRecord.techRecord[0].vehicleType === Enums_1.VEHICLE_TYPE.TRL && uniqueRecord.trailerId !== techRecord.trailerId) {
            const isTrailerIdValid = fromValidation.validateTrailerId.validate(techRecord.trailerId);
            if (isTrailerIdValid.error) {
                return Promise.reject({ statusCode: 400, body: formatErrorMessage_1.formatErrorMessage("TrailerId is invalid") });
            }
            const trailerIdRecords = await this.techRecordsDAO.getBySearchTerm(techRecord.trailerId, Enums_1.SEARCHCRITERIA.TRAILERID);
            if (trailerIdRecords.Count > 0) {
                return Promise.reject({
                    statusCode: 400,
                    body: formatErrorMessage_1.formatErrorMessage(`TrailerId ${techRecord.trailerId} already exists`)
                });
            }
            const previousTrailerId = uniqueRecord.trailerId;
            uniqueRecord.trailerId = techRecord.trailerId;
            techRecord.techRecord[0].reasonForCreation = `Trailer Id updated from ${previousTrailerId} to ${techRecord.trailerId}. ` + techRecord.techRecord[0].reasonForCreation;
        }
    }
    async createAndArchiveTechRecord(updatedTechRecord, msUserDetails, oldStatusCode) {
        const { statusCode } = updatedTechRecord.techRecord[0];
        if ((oldStatusCode && oldStatusCode === Enums_1.STATUS.ARCHIVED) || statusCode === Enums_1.STATUS.ARCHIVED) {
            return Promise.reject({ statusCode: 400, body: formatErrorMessage_1.formatErrorMessage(Enums_1.ERRORS.CANNOT_USE_UPDATE_TO_ARCHIVE) });
        }
        if (oldStatusCode && oldStatusCode === Enums_1.STATUS.CURRENT && statusCode === Enums_1.STATUS.PROVISIONAL) {
            return Promise.reject({ statusCode: 400, body: formatErrorMessage_1.formatErrorMessage(Enums_1.ERRORS.CANNOT_CHANGE_CURRENT_TO_PROVISIONAL) });
        }
        const isPayloadValid = fromValidation.validatePayload(updatedTechRecord.techRecord[0], false);
        this.checkValidationErrors(isPayloadValid);
        updatedTechRecord.techRecord[0] = isPayloadValid.value;
        return this.getTechRecordsList(updatedTechRecord.systemNumber, Enums_1.STATUS.ALL, Enums_1.SEARCHCRITERIA.SYSTEM_NUMBER)
            .then(async (data) => {
            if (data.length !== 1) {
                // systemNumber search should return a unique record
                throw new HTTPError_1.default(500, Enums_1.ERRORS.NO_UNIQUE_RECORD);
            }
            const techRecordWithAllStatues = data[0];
            const statusCodeToSearch = oldStatusCode ? oldStatusCode : statusCode;
            await this.updateAttributesOutsideTechRecordsArray(techRecordWithAllStatues, updatedTechRecord);
            const techRecToArchive = this.getTechRecordToArchive(techRecordWithAllStatues, statusCodeToSearch);
            const currentTechRec = techRecordWithAllStatues.techRecord.find((techRec) => techRec.statusCode === Enums_1.STATUS.CURRENT);
            // check if vehicle already has a current and the provisional has been updated to current the mark old current as archived
            if (currentTechRec && oldStatusCode && oldStatusCode === Enums_1.STATUS.PROVISIONAL && statusCode === Enums_1.STATUS.CURRENT) {
                currentTechRec.statusCode = Enums_1.STATUS.ARCHIVED;
                const date = new Date().toISOString();
                currentTechRec.lastUpdatedAt = date;
                currentTechRec.lastUpdatedByName = msUserDetails.msUser;
                currentTechRec.lastUpdatedById = msUserDetails.msOid;
            }
            const newRecord = lodash_1.cloneDeep(techRecToArchive);
            lodash_1.mergeWith(newRecord, updatedTechRecord.techRecord[0], this.arrayCustomizer);
            if (oldStatusCode) {
                newRecord.statusCode = statusCode;
            }
            this.setAuditDetails(newRecord, techRecToArchive, msUserDetails);
            techRecToArchive.statusCode = Enums_1.STATUS.ARCHIVED;
            fromValidation.populateFields(newRecord);
            const { systemNumber, vin, primaryVrm, trailerId } = techRecordWithAllStatues;
            newRecord.recordCompleteness = ComputeRecordCompleteness_1.computeRecordCompleteness({ systemNumber, vin, primaryVrm, trailerId, techRecord: [newRecord] });
            techRecordWithAllStatues.techRecord.push(newRecord);
            return techRecordWithAllStatues;
        })
            .catch((error) => {
            throw new HTTPError_1.default(error.statusCode, error.body);
        });
    }
    arrayCustomizer(objValue, srcValue) {
        if (lodash_1.isArray(objValue) && lodash_1.isArray(srcValue)) {
            return srcValue;
        }
    }
    getTechRecordToArchive(techRecord, statusCode) {
        const recordsToArchive = techRecord.techRecord.filter((record) => record.statusCode === statusCode);
        if (recordsToArchive.length > 1) {
            throw new HTTPError_1.default(500, `Vehicle has more than one tech-record with status ${statusCode}`);
        }
        else if (recordsToArchive.length === 0) {
            throw new HTTPError_1.default(404, `Vehicle has no tech-records with status ${statusCode}`);
        }
        else {
            return recordsToArchive[0];
        }
    }
    setAuditDetails(newTechRecord, oldTechRecord, msUserDetails) {
        const date = new Date().toISOString();
        newTechRecord.createdAt = date;
        newTechRecord.createdByName = msUserDetails.msUser;
        newTechRecord.createdById = msUserDetails.msOid;
        delete newTechRecord.lastUpdatedAt;
        delete newTechRecord.lastUpdatedById;
        delete newTechRecord.lastUpdatedByName;
        oldTechRecord.lastUpdatedAt = date;
        oldTechRecord.lastUpdatedByName = msUserDetails.msUser;
        oldTechRecord.lastUpdatedById = msUserDetails.msOid;
        let updateType = Enums_1.UPDATE_TYPE.TECH_RECORD_UPDATE;
        if (newTechRecord.adrDetails || oldTechRecord.adrDetails) {
            updateType = lodash_1.isEqual(newTechRecord.adrDetails, oldTechRecord.adrDetails) ? Enums_1.UPDATE_TYPE.TECH_RECORD_UPDATE : Enums_1.UPDATE_TYPE.ADR;
        }
        oldTechRecord.updateType = updateType;
    }
    insertTechRecordsList(techRecordItems) {
        return this.techRecordsDAO.createMultiple(techRecordItems)
            .then((data) => {
            if (data.UnprocessedItems) {
                return data.UnprocessedItems;
            }
        })
            .catch((error) => {
            console.error(error);
            throw new HTTPError_1.default(500, Enums_1.HTTPRESPONSE.INTERNAL_SERVER_ERROR);
        });
    }
    deleteTechRecordsList(techRecordItemKeys) {
        return this.techRecordsDAO.deleteMultiple(techRecordItemKeys)
            .then((data) => {
            if (data.UnprocessedItems) {
                return data.UnprocessedItems;
            }
        })
            .catch((error) => {
            console.error(error);
            throw new HTTPError_1.default(500, Enums_1.HTTPRESPONSE.INTERNAL_SERVER_ERROR);
        });
    }
    setCreatedAuditDetails(techRecord, createdByName, createdById, date) {
        techRecord.createdAt = date;
        techRecord.createdByName = createdByName;
        techRecord.createdById = createdById;
        delete techRecord.lastUpdatedAt;
        delete techRecord.lastUpdatedById;
        delete techRecord.lastUpdatedByName;
    }
    setLastUpdatedAuditDetails(techRecord, createdByName, createdById, date) {
        techRecord.lastUpdatedAt = date;
        techRecord.lastUpdatedByName = createdByName;
        techRecord.lastUpdatedById = createdById;
    }
    async prepareTechRecordForStatusUpdate(systemNumber, newStatus = Enums_1.STATUS.CURRENT, createdById, createdByName) {
        const techRecordWrapper = await this.getTechRecordsList(systemNumber, Enums_1.STATUS.ALL, Enums_1.SEARCHCRITERIA.SYSTEM_NUMBER);
        if (techRecordWrapper.length !== 1) {
            // systemNumber search should return a single record
            throw new HTTPError_1.default(500, Enums_1.ERRORS.NO_UNIQUE_RECORD);
        }
        const uniqueRecord = techRecordWrapper[0];
        const provisionalTechRecords = uniqueRecord.techRecord.filter((techRecord) => techRecord.statusCode === Enums_1.STATUS.PROVISIONAL);
        const currentTechRecords = uniqueRecord.techRecord.filter((techRecord) => techRecord.statusCode === Enums_1.STATUS.CURRENT);
        let newTechRecord;
        if (provisionalTechRecords.length === 1) {
            provisionalTechRecords[0].statusCode = Enums_1.STATUS.ARCHIVED;
            newTechRecord = lodash_1.cloneDeep(provisionalTechRecords[0]);
            newTechRecord.statusCode = newStatus;
            const date = new Date().toISOString();
            this.setCreatedAuditDetails(newTechRecord, createdByName, createdById, date);
            this.setLastUpdatedAuditDetails(provisionalTechRecords[0], createdByName, createdById, date);
            provisionalTechRecords[0].updateType = Enums_1.UPDATE_TYPE.TECH_RECORD_UPDATE;
        }
        if (currentTechRecords.length === 1) {
            currentTechRecords[0].statusCode = Enums_1.STATUS.ARCHIVED;
            const date = new Date().toISOString();
            if (!newTechRecord) {
                newTechRecord = lodash_1.cloneDeep(currentTechRecords[0]);
                newTechRecord.statusCode = newStatus;
                this.setCreatedAuditDetails(newTechRecord, createdByName, createdById, date);
            }
            this.setLastUpdatedAuditDetails(currentTechRecords[0], createdByName, createdById, date);
            currentTechRecords[0].updateType = Enums_1.UPDATE_TYPE.TECH_RECORD_UPDATE;
        }
        // if newTechRecord is undefined that means there multiple or no current/provisional records were found
        if (!newTechRecord) {
            throw new HTTPError_1.default(400, "The tech record status cannot be updated to " + newStatus);
        }
        uniqueRecord.techRecord.push(newTechRecord);
        return uniqueRecord;
    }
    async updateTechRecordStatusCode(systemNumber, newStatus = Enums_1.STATUS.CURRENT, createdById, createdByName) {
        const uniqueRecord = await this.prepareTechRecordForStatusUpdate(systemNumber, newStatus, createdById, createdByName);
        let updatedTechRecord;
        try {
            updatedTechRecord = await this.techRecordsDAO.updateSingle(uniqueRecord);
        }
        catch (error) {
            throw new HTTPError_1.default(500, Enums_1.HTTPRESPONSE.INTERNAL_SERVER_ERROR);
        }
        return this.formatTechRecordItemForResponse(updatedTechRecord.Attributes);
    }
    async archiveTechRecordStatus(systemNumber, techRecordToUpdate, userDetails) {
        const allTechRecordWrapper = await this.getTechRecordsList(systemNumber, Enums_1.STATUS.ALL, Enums_1.SEARCHCRITERIA.SYSTEM_NUMBER);
        if (allTechRecordWrapper.length !== 1) {
            // systemNumber search should return a single record
            throw new HTTPError_1.default(400, formatErrorMessage_1.formatErrorMessage(Enums_1.ERRORS.NO_UNIQUE_RECORD));
        }
        const techRecordWithAllStatues = allTechRecordWrapper[0];
        const techRecordToArchive = this.getTechRecordToArchive(techRecordWithAllStatues, techRecordToUpdate.techRecord[0].statusCode);
        if (techRecordToArchive.statusCode === Enums_1.STATUS.ARCHIVED) {
            throw new HTTPError_1.default(400, formatErrorMessage_1.formatErrorMessage(Enums_1.ERRORS.CANNOT_UPDATE_ARCHIVED_RECORD));
        }
        if (!lodash_1.isEqual(techRecordToArchive, techRecordToUpdate.techRecord[0])) {
            throw new HTTPError_1.default(400, formatErrorMessage_1.formatErrorMessage(Enums_1.ERRORS.CANNOT_ARCHIVE_CHANGED_RECORD));
        }
        techRecordToArchive.statusCode = Enums_1.STATUS.ARCHIVED;
        techRecordToArchive.lastUpdatedAt = new Date().toISOString();
        techRecordToArchive.lastUpdatedByName = userDetails.msUser;
        techRecordToArchive.lastUpdatedById = userDetails.msOid;
        techRecordToArchive.updateType = Enums_1.UPDATE_TYPE.TECH_RECORD_UPDATE;
        let updatedTechRecord;
        try {
            updatedTechRecord = await this.techRecordsDAO.updateSingle(techRecordWithAllStatues);
        }
        catch (error) {
            throw new HTTPError_1.default(error.statusCode, error.message);
        }
        return this.formatTechRecordItemForResponse(updatedTechRecord.Attributes);
    }
    static isStatusUpdateRequired(testStatus, testResult, testTypeId) {
        return testStatus === "submitted" && (testResult === "pass" || testResult === "prs") &&
            (this.isTestTypeFirstTest(testTypeId) || this.isTestTypeNotifiableAlteration(testTypeId));
    }
    static isTestTypeFirstTest(testTypeId) {
        const firstTestIds = ["41", "95", "65", "66", "67", "103", "104", "82", "83", "119", "120"];
        return firstTestIds.includes(testTypeId);
    }
    static isTestTypeNotifiableAlteration(testTypeId) {
        const notifiableAlterationIds = ["47", "48"];
        return notifiableAlterationIds.includes(testTypeId);
    }
    getTechRecordByStatus(techRecordList, statusCode) {
        return techRecordList.techRecord.filter((techRecord) => techRecord.statusCode === statusCode);
    }
    async updateEuVehicleCategory(systemNumber, newEuVehicleCategory, createdById, createdByName) {
        const techRecordWrapper = (await this.getTechRecordsList(systemNumber, Enums_1.STATUS.ALL, Enums_1.SEARCHCRITERIA.SYSTEM_NUMBER))[0];
        const nonArchivedTechRecord = techRecordWrapper.techRecord.filter((techRecord) => techRecord.statusCode !== Enums_1.STATUS.ARCHIVED);
        if (nonArchivedTechRecord.length > 1) {
            throw new HTTPError_1.default(400, Enums_1.HTTPRESPONSE.EU_VEHICLE_CATEGORY_MORE_THAN_ONE_TECH_RECORD);
        }
        if (nonArchivedTechRecord.length === 0) {
            throw new HTTPError_1.default(400, Enums_1.ERRORS.CANNOT_UPDATE_ARCHIVED_RECORD);
        }
        if (nonArchivedTechRecord[0].euVehicleCategory) {
            return new HTTPResponse_1.default(200, Enums_1.HTTPRESPONSE.NO_EU_VEHICLE_CATEGORY_UPDATE_REQUIRED);
        }
        const statusCode = nonArchivedTechRecord[0].statusCode;
        const newTechRecord = Object.assign({}, nonArchivedTechRecord[0]);
        nonArchivedTechRecord[0].statusCode = Enums_1.STATUS.ARCHIVED;
        newTechRecord.euVehicleCategory = newEuVehicleCategory;
        newTechRecord.statusCode = statusCode;
        const date = new Date().toISOString();
        this.setCreatedAuditDetails(newTechRecord, createdByName, createdById, date);
        this.setLastUpdatedAuditDetails(nonArchivedTechRecord[0], createdByName, createdById, date);
        newTechRecord.reasonForCreation = Enums_1.REASON_FOR_CREATION.EU_VEHICLE_CATEGORY_UPDATED;
        nonArchivedTechRecord[0].updateType = Enums_1.UPDATE_TYPE.TECH_RECORD_UPDATE;
        techRecordWrapper.techRecord.push(newTechRecord);
        let updatedTechRecord;
        try {
            updatedTechRecord = await this.techRecordsDAO.updateSingle(techRecordWrapper);
        }
        catch (error) {
            throw new HTTPError_1.default(500, Enums_1.HTTPRESPONSE.INTERNAL_SERVER_ERROR);
        }
        return new HTTPResponse_1.default(200, this.formatTechRecordItemForResponse(updatedTechRecord.Attributes));
    }
    addProvisionalTechRecord(techRecord, msUserDetails) {
        return this.addNewProvisionalRecord(techRecord, msUserDetails)
            .then((data) => {
            return this.techRecordsDAO.updateSingle(data)
                .then((updatedData) => {
                return this.formatTechRecordItemForResponse(Object.assign({}, updatedData.Attributes));
            })
                .catch((error) => {
                throw new HTTPError_1.default(error.statusCode, error.message);
            });
        })
            .catch((error) => {
            throw new HTTPError_1.default(error.statusCode, error.body);
        });
    }
    addNewProvisionalRecord(techRecordToAdd, msUserDetails) {
        if (techRecordToAdd.techRecord[0].statusCode !== Enums_1.STATUS.PROVISIONAL) {
            return Promise.reject({ statusCode: 400, body: Enums_1.ERRORS.STATUS_CODE_SHOULD_BE_PROVISIONAL });
        }
        const isPayloadValid = fromValidation.validatePayload(techRecordToAdd.techRecord[0]);
        if (isPayloadValid.error) {
            return Promise.reject({ statusCode: 400, body: isPayloadValid.error.details });
        }
        return this.getTechRecordsList(techRecordToAdd.systemNumber, Enums_1.STATUS.ALL, Enums_1.SEARCHCRITERIA.SYSTEM_NUMBER)
            .then((data) => {
            if (data.length !== 1) {
                // systemNumber search should return a unique record
                throw new HTTPError_1.default(500, Enums_1.ERRORS.NO_UNIQUE_RECORD);
            }
            const uniqueRecord = data[0];
            if (this.getTechRecordByStatus(uniqueRecord, Enums_1.STATUS.PROVISIONAL).length > 0) {
                throw new HTTPError_1.default(400, Enums_1.ERRORS.CURRENT_OR_PROVISIONAL_RECORD_FOUND);
            }
            techRecordToAdd.techRecord[0].createdAt = new Date().toISOString();
            techRecordToAdd.techRecord[0].createdByName = msUserDetails.msUser;
            techRecordToAdd.techRecord[0].createdById = msUserDetails.msOid;
            delete techRecordToAdd.techRecord[0].lastUpdatedAt;
            delete techRecordToAdd.techRecord[0].lastUpdatedById;
            delete techRecordToAdd.techRecord[0].lastUpdatedByName;
            techRecordToAdd.techRecord[0].updateType = Enums_1.UPDATE_TYPE.TECH_RECORD_UPDATE;
            uniqueRecord.techRecord.push(techRecordToAdd.techRecord[0]);
            return uniqueRecord;
        })
            .catch((error) => {
            throw new HTTPError_1.default(error.statusCode, error.body);
        });
    }
}
exports.default = TechRecordsService;
