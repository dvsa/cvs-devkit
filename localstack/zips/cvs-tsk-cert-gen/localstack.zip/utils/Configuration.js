"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
// @ts-ignore
const yml = __importStar(require("node-yaml"));
/**
 * Configuration class for retrieving project config
 */
class Configuration {
    constructor(configPath) {
        const config = yml.readSync(configPath);
        // Replace environment variable references
        let stringifiedConfig = JSON.stringify(config);
        const envRegex = /\${(\w+\b):?(\w+\b)?}/g;
        const matches = stringifiedConfig.match(envRegex);
        if (matches) {
            matches.forEach((match) => {
                envRegex.lastIndex = 0;
                const captureGroups = envRegex.exec(match);
                // Insert the environment variable if available. If not, insert placeholder. If no placeholder, leave it as is.
                stringifiedConfig = stringifiedConfig.replace(match, (process.env[captureGroups[1]] || captureGroups[2] || captureGroups[1]));
            });
        }
        this.config = JSON.parse(stringifiedConfig);
    }
    /**
     * Retrieves the singleton instance of Configuration
     * @returns Configuration
     */
    static getInstance() {
        if (!this.instance) {
            this.instance = new Configuration("../config/config.yml");
        }
        return Configuration.instance;
    }
    /**
     * Retrieves the entire config as an object
     * @returns any
     */
    getConfig() {
        return this.config;
    }
    /**
     * Retrieves the Lambda Invoke config
     * @returns IInvokeConfig
     */
    getInvokeConfig() {
        if (!this.config.invoke) {
            throw new Error("Lambda Invoke config is not defined in the config file.");
        }
        // Not defining BRANCH will default to local
        const env = (!process.env.BRANCH || process.env.BRANCH === "local") ? "local" : process.env.BRANCH;
        return this.config.invoke[env];
    }
    /**
     * Retrieves the S3 config
     * @returns IS3Config
     */
    getS3Config() {
        if (!this.config.s3) {
            throw new Error("DynamoDB config is not defined in the config file.");
        }
        // Not defining BRANCH will default to local
        const env = (!process.env.BRANCH || process.env.BRANCH === "local") ? "local" : process.env.BRANCH;
        return this.config.s3[env];
    }
    /**
     * Retrieves the MOT config
     * @returns IMOTConfig
     */
    getMOTConfig() {
        if (!this.config.mot) {
            throw new Error("The MOT config is not defined in the config file.");
        }
        return this.config.mot;
    }
}
exports.Configuration = Configuration;
