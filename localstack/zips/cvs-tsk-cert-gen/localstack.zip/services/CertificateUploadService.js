"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const ServiceDecorator_1 = require("../models/injector/ServiceDecorator");
const S3BucketService_1 = require("./S3BucketService");
/**
 * Service class for uploading certificates to S3
 */
let CertificateUploadService = class CertificateUploadService {
    constructor(s3BucketService) {
        this.s3BucketService = s3BucketService;
    }
    /**
     * Uploads a generated certificate to S3 bucket
     * @param payload
     */
    uploadCertificate(payload) {
        let shouldEmailCertificate = payload.shouldEmailCertificate;
        if (shouldEmailCertificate !== "false") {
            shouldEmailCertificate = "true";
        }
        const metadata = {
            "vrm": payload.vrm,
            "test-type-name": payload.testTypeName,
            "test-type-result": payload.testTypeResult,
            "date-of-issue": payload.dateOfIssue,
            "cert-type": payload.certificateType,
            "file-format": payload.fileFormat,
            "file-size": payload.fileSize,
            "cert-index": payload.certificateOrder.current.toString(),
            "total-certs": payload.certificateOrder.total.toString(),
            "email": payload.email,
            "should-email-certificate": shouldEmailCertificate
        };
        return this.s3BucketService.upload(`cvs-cert-${process.env.BUCKET}`, payload.fileName, payload.certificate, metadata);
    }
};
CertificateUploadService = __decorate([
    ServiceDecorator_1.Service(),
    __metadata("design:paramtypes", [S3BucketService_1.S3BucketService])
], CertificateUploadService);
exports.CertificateUploadService = CertificateUploadService;
