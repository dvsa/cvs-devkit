"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const Configuration_1 = require("../utils/Configuration");
const aws_sdk_1 = require("aws-sdk");
const ServiceDecorator_1 = require("../models/injector/ServiceDecorator");
const HTTPError_1 = require("../models/HTTPError");
const Enums_1 = require("../models/Enums");
/* tslint:disable */
const AWSXRay = require("aws-xray-sdk");
/* tslint:enable */
/**
 * Service class for invoking external lambda functions
 */
let LambdaService = class LambdaService {
    constructor(lambdaClient) {
        const config = Configuration_1.Configuration.getInstance().getInvokeConfig();
        this.lambdaClient = AWSXRay.captureAWSClient(lambdaClient);
        aws_sdk_1.config.lambda = config.params;
    }
    /**
     * Invokes a lambda function based on the given parameters
     * @param params - InvocationRequest params
     */
    async invoke(params) {
        return this.lambdaClient.invoke(params)
            .promise();
    }
    /**
     * Validates the invocation response
     * @param response - the invocation response
     */
    validateInvocationResponse(response) {
        if (!response.Payload || response.Payload === "" || (response.StatusCode && response.StatusCode >= 400)) {
            throw new HTTPError_1.HTTPError(500, `${Enums_1.ERRORS.LAMBDA_INVOCATION_ERROR} ${response.StatusCode} ${Enums_1.ERRORS.EMPTY_PAYLOAD}`);
        }
        const payload = JSON.parse(response.Payload);
        if (payload.statusCode >= 400) {
            throw new HTTPError_1.HTTPError(500, `${Enums_1.ERRORS.LAMBDA_INVOCATION_ERROR} ${payload.statusCode} ${payload.body}`);
        }
        if (!payload.body) {
            throw new HTTPError_1.HTTPError(400, `${Enums_1.ERRORS.LAMBDA_INVOCATION_BAD_DATA} ${JSON.stringify(payload)}.`);
        }
        return payload;
    }
};
LambdaService = __decorate([
    ServiceDecorator_1.Service(),
    __metadata("design:paramtypes", [aws_sdk_1.Lambda])
], LambdaService);
exports.LambdaService = LambdaService;
