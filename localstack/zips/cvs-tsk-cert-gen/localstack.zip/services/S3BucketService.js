"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const s3_1 = __importDefault(require("aws-sdk/clients/s3"));
const aws_sdk_1 = require("aws-sdk");
const ServiceDecorator_1 = require("../models/injector/ServiceDecorator");
const Configuration_1 = require("../utils/Configuration");
/* tslint:disable */
const AWSXRay = require("aws-xray-sdk");
/* tslint:enable */
/**
 * Service class for communicating with Simple Storage Service
 */
let S3BucketService = class S3BucketService {
    constructor(s3Client) {
        const config = Configuration_1.Configuration.getInstance().getS3Config();
        this.s3Client = AWSXRay.captureAWSClient(s3Client);
        aws_sdk_1.config.s3 = config;
    }
    /**
     * Uploads a file to an S3 bucket
     * @param bucketName - the bucket to upload to
     * @param fileName - the name of the file
     * @param content - contents of the file
     * @param metadata - optional metadata
     */
    upload(bucketName, fileName, content, metadata) {
        return this.s3Client.upload({
            Bucket: bucketName,
            Key: `${process.env.BRANCH}/${fileName}`,
            Body: content,
            Metadata: metadata
        }).promise();
    }
    /**
     * Downloads a file from an S3 bucket
     * @param bucketName - the bucket from which to download
     * @param fileName - the name of the file
     */
    download(bucketName, fileName) {
        return this.s3Client.getObject({
            Bucket: bucketName,
            Key: `${process.env.BRANCH}/${fileName}`,
        }).promise();
    }
};
S3BucketService = __decorate([
    ServiceDecorator_1.Service(),
    __metadata("design:paramtypes", [s3_1.default])
], S3BucketService);
exports.S3BucketService = S3BucketService;
