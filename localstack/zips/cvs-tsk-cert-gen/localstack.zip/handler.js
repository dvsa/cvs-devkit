"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const certGen_1 = require("./functions/certGen");
exports.handler = certGen_1.certGen;
const aws_sdk_1 = require("aws-sdk");
const isOffline = (!process.env.BRANCH || process.env.BRANCH === "local");
if (isOffline) {
    aws_sdk_1.config.credentials = {
        accessKeyId: "accessKey1",
        secretAccessKey: "verySecretKey1"
    };
}
