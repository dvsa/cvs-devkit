"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Injector_1 = require("../models/injector/Injector");
const CertificateGenerationService_1 = require("../services/CertificateGenerationService");
const CertificateUploadService_1 = require("../services/CertificateUploadService");
const Enums_1 = require("../models/Enums");
/**
 * λ function to process an SQS message detailing info for certificate generation
 * @param event - DynamoDB Stream event
 * @param context - λ Context
 * @param callback - callback function
 */
const certGen = async (event, context, callback) => {
    if (!event || !event.Records || !Array.isArray(event.Records) || !event.Records.length) {
        console.error("ERROR: event is not defined.");
        throw new Error("Event is empty");
    }
    const certificateGenerationService = Injector_1.Injector.resolve(CertificateGenerationService_1.CertificateGenerationService);
    const certificateUploadService = Injector_1.Injector.resolve(CertificateUploadService_1.CertificateUploadService);
    const certificateUploadPromises = [];
    event.Records.forEach((record) => {
        const testResult = JSON.parse(record.body);
        if (testResult.testResultId.match("\\b[a-zA-Z0-9]{8}\\b-\\b[a-zA-Z0-9]{4}\\b-\\b[a-zA-Z0-9]{4}\\b-\\b[a-zA-Z0-9]{4}\\b-\\b[a-zA-Z0-9]{12}\\b")) {
            // Check for retroError flag for a testResult and cvsTestUpdated for the test-type and do not generate certificates if set to true
            const generatedCertificateResponse = certificateGenerationService.generateCertificate(testResult)
                .then((response) => {
                return certificateUploadService.uploadCertificate(response);
            });
            certificateUploadPromises.push(generatedCertificateResponse);
        }
        else {
            console.error(`${Enums_1.ERRORS.TESTRESULT_ID}`, testResult.testResultId);
            throw new Error("Bad Test Record: " + testResult.testResultId);
        }
    });
    return Promise.all(certificateUploadPromises)
        .catch((error) => {
        console.error(error);
        throw error;
    });
};
exports.certGen = certGen;
