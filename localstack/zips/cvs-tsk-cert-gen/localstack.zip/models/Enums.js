"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ERRORS;
(function (ERRORS) {
    ERRORS["TESTRESULT_ID"] = "Record does not have valid testResultId for certificate generation.";
    ERRORS["LAMBDA_INVOCATION_ERROR"] = "Lambda invocation returned error:";
    ERRORS["EMPTY_PAYLOAD"] = "with empty payload.";
    ERRORS["LAMBDA_INVOCATION_BAD_DATA"] = "Lambda invocation returned bad data:";
    ERRORS["RETRO_ERROR_OR_CVS_UPDATED"] = "Not eligible for certificate generation.";
})(ERRORS = exports.ERRORS || (exports.ERRORS = {}));
var VEHICLE_TYPES;
(function (VEHICLE_TYPES) {
    VEHICLE_TYPES["PSV"] = "psv";
    VEHICLE_TYPES["HGV"] = "hgv";
    VEHICLE_TYPES["TRL"] = "trl";
})(VEHICLE_TYPES = exports.VEHICLE_TYPES || (exports.VEHICLE_TYPES = {}));
var TEST_RESULTS;
(function (TEST_RESULTS) {
    TEST_RESULTS["PASS"] = "pass";
    TEST_RESULTS["FAIL"] = "fail";
    TEST_RESULTS["PRS"] = "prs";
})(TEST_RESULTS = exports.TEST_RESULTS || (exports.TEST_RESULTS = {}));
var CERTIFICATE_DATA;
(function (CERTIFICATE_DATA) {
    CERTIFICATE_DATA["RWT_DATA"] = "RWT_DATA";
    CERTIFICATE_DATA["PASS_DATA"] = "PASS_DATA";
    CERTIFICATE_DATA["FAIL_DATA"] = "FAIL_DATA";
    CERTIFICATE_DATA["ADR_DATA"] = "ADR_DATA";
})(CERTIFICATE_DATA = exports.CERTIFICATE_DATA || (exports.CERTIFICATE_DATA = {}));
exports.HGV_TRL_ROADWORTHINESS_TEST_TYPES = {
    IDS: ["62", "63", "91", "101", "122"]
};
