"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Injector_1 = require("./Injector");
/**
 * @returns {GenericClassDecorator<Type<any>>}
 * @constructor
 */
exports.Service = () => {
    return (target) => {
        Injector_1.Injector.resolve(target);
    };
};
