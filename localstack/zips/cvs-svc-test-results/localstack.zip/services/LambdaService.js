"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* tslint:disable */
let AWS;
// if (process.env._X_AMZN_TRACE_ID) {
//   AWS = require("aws-xray-sdk").captureAWS(require("aws-sdk"));
// } else {
//   console.log("Serverless Offline detected; skipping AWS X-Ray setup");
//   AWS = require("aws-sdk");
// }
AWS = require("aws-sdk");
/* tslint:enable */
const Configuration_1 = require("../utils/Configuration");
const validateInvocationResponse_1 = require("../utils/validateInvocationResponse");
const lambdaInvokeEndpoints = Configuration_1.Configuration.getInstance().getEndpoints();
/**
 * Helper service for interactions with other lambdas
 */
class LambdaService {
    static invoke(lambdaName, lambdaEvent) {
        console.log("LambdaService");
        console.log("LAMBDA created is:\n", lambdaInvokeEndpoints.params);
        // TODO: Change cfg for localstack and develop locally local-global should go away in fact
        const lambda = new AWS.Lambda(lambdaInvokeEndpoints.params);
        console.log("FunctionName to be invoked:\n", lambdaName);
        console.log("Payload: \n", JSON.stringify(lambdaEvent));
        return lambda
            .invoke({
            FunctionName: lambdaName,
            InvocationType: "RequestResponse",
            Payload: JSON.stringify(lambdaEvent)
        })
            .promise()
            .then((data) => {
            console.log("data back:\n");
            console.log(data);
            const payload = validateInvocationResponse_1.validateInvocationResponse(data);
            const body = JSON.parse(payload.body);
            return body;
        });
    }
}
exports.LambdaService = LambdaService;
