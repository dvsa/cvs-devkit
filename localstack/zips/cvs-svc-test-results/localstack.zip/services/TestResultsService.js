"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const joi_1 = require("joi");
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const lodash_1 = require("lodash");
const enums = __importStar(require("../assets/Enums"));
const models = __importStar(require("../models"));
const utils = __importStar(require("../utils"));
const VehicleTestController_1 = require("../handlers/VehicleTestController");
const TestDataProvider_1 = require("../handlers/expiry/providers/TestDataProvider");
const DateProvider_1 = require("../handlers/expiry/providers/DateProvider");
const mappingUtil_1 = require("../utils/mappingUtil");
/**
 * Service for retrieving and creating Test Results from/into the db
 * @returns Promise
 */
class TestResultsService {
    constructor(testResultsDAO) {
        this.testResultsDAO = testResultsDAO;
        this.vehicleTestController = models.Injector.resolve(VehicleTestController_1.VehicleTestController, [TestDataProvider_1.TestDataProvider, DateProvider_1.DateProvider]);
        this.vehicleTestController.dataProvider.testResultsDAO = this.testResultsDAO;
    }
    async getTestResultBySystemNumber(filters) {
        try {
            return await this.vehicleTestController.getTestResultBySystemNumber(filters);
        }
        catch (error) {
            return TestResultsService.handleError(error);
        }
    }
    async getTestResultsByTesterStaffId(filters) {
        try {
            return await this.vehicleTestController.getTestResultByTestStaffId(filters);
        }
        catch (error) {
            return TestResultsService.handleError(error);
        }
    }
    async updateTestResult(systemNumber, payload, msUserDetails) {
        utils.MappingUtil.removeNonEditableAttributes(payload);
        let validationSchema = utils.ValidationUtil.getValidationSchema(payload.vehicleType, payload.testStatus);
        const testTypesValidationErrors = utils.ValidationUtil.validateTestTypes(payload);
        if (testTypesValidationErrors) {
            return Promise.reject(new models.HTTPError(400, { errors: testTypesValidationErrors }));
        }
        // temporarily remove testTypes to validate only vehicle details and append testTypes to the payload again after the validation
        const { testTypes } = payload;
        delete payload.testTypes;
        validationSchema = validationSchema.keys({
            countryOfRegistration: joi_1.string()
                .valid(enums.COUNTRY_OF_REGISTRATION)
                .required(),
            testTypes: joi_1.any().forbidden(),
        });
        validationSchema = validationSchema.optionalKeys([
            "testEndTimestamp",
            "systemNumber",
            "vin",
        ]);
        const validation = joi_1.validate(payload, validationSchema);
        if (validation !== null && validation.error) {
            return Promise.reject(new models.HTTPError(400, {
                errors: mappingUtil_1.MappingUtil.mapErrorMessage(validation),
            }));
        }
        payload.testTypes = testTypes;
        try {
            const result = await this.testResultsDAO.getBySystemNumber(systemNumber);
            const response = {
                Count: result.Count,
                Items: result.Items,
            };
            const testResults = utils.ValidationUtil.getTestResultItems(response);
            const oldTestResult = this.getTestResultToArchive(testResults, payload.testResultId);
            oldTestResult.testVersion = enums.TEST_VERSION.ARCHIVED;
            const newTestResult = lodash_1.cloneDeep(oldTestResult);
            newTestResult.testVersion = enums.TEST_VERSION.CURRENT;
            lodash_1.mergeWith(newTestResult, payload, mappingUtil_1.MappingUtil.arrayCustomizer);
            const vehicleSubclass = newTestResult.vehicleSubclass && newTestResult.vehicleSubclass.length
                ? newTestResult.vehicleSubclass[0]
                : undefined;
            const newTestTypes = await this.vehicleTestController.dataProvider.getTestTypesWithTestCodesAndClassification(newTestResult.testTypes, {
                vehicleType: newTestResult.vehicleType,
                vehicleSize: newTestResult.vehicleSize,
                vehicleConfiguration: newTestResult.vehicleConfiguration,
                vehicleAxles: newTestResult.noOfAxles,
                euVehicleCategory: newTestResult.euVehicleCategory,
                vehicleClass: newTestResult.vehicleClass.code,
                vehicleSubclass,
                vehicleWheels: newTestResult.numberOfWheelsDriven,
            });
            // @ts-ignore
            newTestResult.testTypes = newTestTypes;
            await this.checkTestTypeStartAndEndTimestamp(oldTestResult, newTestResult);
            mappingUtil_1.MappingUtil.cleanDefectsArrayForSpecialistTests(newTestResult);
            mappingUtil_1.MappingUtil.setAuditDetails(newTestResult, oldTestResult, msUserDetails);
            if (!newTestResult.testHistory) {
                newTestResult.testHistory = [oldTestResult];
            }
            else {
                delete oldTestResult.testHistory;
                newTestResult.testHistory.push(oldTestResult);
            }
            try {
                await this.testResultsDAO.updateTestResult(newTestResult);
                return newTestResult;
            }
            catch (dynamoError) {
                throw new models.HTTPError(500, dynamoError.message);
            }
        }
        catch (error) {
            throw new models.HTTPError(error.statusCode, error.body);
        }
    }
    async checkTestTypeStartAndEndTimestamp(oldTestResult, newTestResult) {
        moment_timezone_1.default.tz.setDefault("UTC");
        const params = {
            fromStartTime: moment_timezone_1.default(oldTestResult.testStartTimestamp)
                .startOf("day")
                .toDate(),
            toStartTime: oldTestResult.testStartTimestamp,
            activityType: "visit",
            testStationPNumber: oldTestResult.testStationPNumber,
            testerStaffId: oldTestResult.testerStaffId,
        };
        try {
            const activities = await this.testResultsDAO.getActivity(params);
            if (activities.length > 1) {
                return Promise.reject({
                    statusCode: 500,
                    body: enums.ERRORS.NoUniqueActivityFound,
                });
            }
            const activity = activities[0];
            for (const testType of newTestResult.testTypes) {
                if (moment_timezone_1.default(testType.testTypeStartTimestamp).isAfter(activity.endTime) ||
                    moment_timezone_1.default(testType.testTypeStartTimestamp).isBefore(activity.startTime)) {
                    return Promise.reject({
                        statusCode: 400,
                        body: `The testTypeStartTimestamp must be within the visit, between ${activity.startTime} and ${activity.endTime}`,
                    });
                }
                if (moment_timezone_1.default(testType.testTypeEndTimestamp).isAfter(activity.endTime) ||
                    moment_timezone_1.default(testType.testTypeEndTimestamp).isBefore(activity.startTime)) {
                    return Promise.reject({
                        statusCode: 400,
                        body: `The testTypeEndTimestamp must be within the visit, between ${activity.startTime} and ${activity.endTime}`,
                    });
                }
                if (moment_timezone_1.default(testType.testTypeStartTimestamp).isAfter(testType.testTypeEndTimestamp)) {
                    return Promise.reject({
                        statusCode: 400,
                        body: enums.ERRORS.StartTimeBeforeEndTime,
                    });
                }
            }
        }
        catch (err) {
            if (err.statusCode !== 404) {
                return Promise.reject({
                    statusCode: err.statusCode,
                    body: `Activities microservice error: ${err.body}`,
                });
            }
        }
    }
    getTestResultToArchive(testResults, testResultId) {
        testResults = testResults.filter((testResult) => {
            return (testResult.testResultId === testResultId &&
                (testResult.testVersion === enums.TEST_VERSION.CURRENT ||
                    !testResult.testVersion));
        });
        if (testResults.length !== 1) {
            throw new models.HTTPError(404, enums.ERRORS.NoResourceMatch);
        }
        return testResults[0];
    }
    async insertTestResult(payload) {
        try {
            const result = await this.vehicleTestController.insertTestResult(payload);
            return result;
        }
        catch (error) {
            console.error("TestResultService.insertTestResult ->", error);
            const rejection = [201, 400].includes(error.statusCode)
                ? error
                : new models.HTTPError(500, enums.MESSAGES.INTERNAL_SERVER_ERROR);
            return Promise.reject(rejection);
        }
    }
    static handleError(error) {
        console.error(error);
        const httpError = error;
        if (!(httpError && [400, 404].includes(httpError.statusCode))) {
            return Promise.reject(new models.HTTPError(500, enums.MESSAGES.INTERNAL_SERVER_ERROR));
        }
        return Promise.reject(error);
    }
}
exports.TestResultsService = TestResultsService;
