"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ERRORS;
(function (ERRORS) {
    ERRORS["NotifyConfigNotDefined"] = "The Notify config is not defined in the config file.";
    ERRORS["DynamoDBConfigNotDefined"] = "DynamoDB config is not defined in the config file.";
    ERRORS["LambdaInvokeConfigNotDefined"] = "Lambda Invoke config is not defined in the config file.";
    ERRORS["EventIsEmpty"] = "Event is empty";
    ERRORS["NoBranch"] = "Please define BRANCH environment variable";
    ERRORS["NoResourceMatch"] = "No resources match the search criteria";
    ERRORS["MissingFieldsOnLEC"] = "Mandatory fields missing on LEC test type";
    ERRORS["WrongVehicleTypeOnLEC"] = "Wrong vehicle type for conducting a LEC test";
    ERRORS["NoCertificateNumberOnAdr"] = "Certificate number not present on ADR test type";
    ERRORS["NoCertificateNumberOnTir"] = "Certificate number not present on TIR test type";
    ERRORS["NoExpiryDate"] = "Expiry date not present on ADR test type";
    ERRORS["IncorrectTestStatus"] = "\"testStatus\" should be one of [\"submitted\", \"cancelled\"]";
    ERRORS["PayloadCannotBeEmpty"] = "Payload cannot be empty";
    ERRORS["NoLECExpiryDate"] = "Expiry Date not present on LEC test type";
    ERRORS["NoModificationType"] = "Modification type not present on LEC test type";
    ERRORS["NoEmissionStandard"] = "Emission standard not present on LEC test type";
    ERRORS["NoFuelType"] = "Fuel Type not present on LEC test type";
    ERRORS["NoSmokeTestKLimitApplied"] = "Smoke Test K Limit Applied not present on LEC test type";
    ERRORS["CountryOfRegistrationMandatory"] = "\"countryOfRegistration\" is mandatory";
    ERRORS["EuVehicleCategoryMandatory"] = "\"euVehicleCategory\" is mandatory";
    ERRORS["NoUniqueActivityFound"] = "More than one activity found";
    ERRORS["StartTimeBeforeEndTime"] = "testTypeStartTimestamp must be before testTypeEndTimestamp";
    ERRORS["OdometerReadingMandatory"] = "\"odometerReading\" is mandatory";
    ERRORS["OdometerReadingUnitsMandatory"] = "\"odometerReadingUnits\" is mandatory";
    ERRORS["ExpiryConfigMissing"] = "Invalid Expiry config!";
    ERRORS["MethodNotImplemented"] = "Method not implemented.";
})(ERRORS = exports.ERRORS || (exports.ERRORS = {}));
var TESTING_ERRORS;
(function (TESTING_ERRORS) {
    TESTING_ERRORS["NoDeficiencyCategory"] = "/location/deficiencyText/stdForProhibition are null for a defect with deficiency category other than advisory";
    TESTING_ERRORS["FuelTypeInvalid"] = "\"fuelType\" must be one of [diesel, gas-cng, gas-lng, gas-lpg, petrol, fuel cell, full electric, null]";
    TESTING_ERRORS["ModTypeDescriptionInvalid"] = "\"description\" must be one of [particulate trap, modification or change of engine, gas engine]";
    TESTING_ERRORS["EmissionStandardInvalid"] = "\"emissionStandard\" must be one of [0.10 g/kWh Euro 3 PM, 0.03 g/kWh Euro IV PM, Euro 3, Euro 4, Euro 6, Euro VI, Full Electric, null]";
    TESTING_ERRORS["ModTypeCodeInvalid"] = "\"code\" must be one of [p, m, g]";
    TESTING_ERRORS["VehicleSubclassIsNotAllowed"] = "\"vehicleSubclass\" is not allowed";
    TESTING_ERRORS["VehicleSubclassIsRequired"] = "\"vehicleSubclass\" is required";
    TESTING_ERRORS["EuVehicleCategoryMustBeOneOf"] = "\"euVehicleCategory\" must be one of [m1, null]";
    TESTING_ERRORS["VehicleClassIsRequired"] = "\"vehicleClass\" is required";
    TESTING_ERRORS["VehicleClassCodeIsInvalid"] = "\"code\" must be one of [1, 2, 3, n, s, t, l, v, 4, 5, 7, p, u]";
    TESTING_ERRORS["VehicleClassInvalid"] = "\"vehicleClass\" must be an object";
})(TESTING_ERRORS = exports.TESTING_ERRORS || (exports.TESTING_ERRORS = {}));
var HTTPRESPONSE;
(function (HTTPRESPONSE) {
    HTTPRESPONSE["AWS_EVENT_EMPTY"] = "AWS event is empty. Check your test event.";
    HTTPRESPONSE["NOT_VALID_JSON"] = "Body is not a valid JSON.";
})(HTTPRESPONSE = exports.HTTPRESPONSE || (exports.HTTPRESPONSE = {}));
var HTTPMethods;
(function (HTTPMethods) {
    HTTPMethods["GET"] = "GET";
    HTTPMethods["POST"] = "POST";
    HTTPMethods["PUT"] = "PUT";
    HTTPMethods["DELETE"] = "DELETE";
})(HTTPMethods = exports.HTTPMethods || (exports.HTTPMethods = {}));
var MESSAGES;
(function (MESSAGES) {
    MESSAGES["INVALID_JSON"] = "Body is not a valid JSON.";
    MESSAGES["INTERNAL_SERVER_ERROR"] = "Internal Server Error";
    MESSAGES["RECORD_CREATED"] = "Test records created";
    MESSAGES["BAD_REQUEST"] = "Bad request";
    MESSAGES["ID_ALREADY_EXISTS"] = "Test Result id already exists";
    MESSAGES["CONDITIONAL_REQUEST_FAILED"] = "The conditional request failed";
    MESSAGES["REASON_FOR_ABANDONING_NOT_PRESENT"] = "Reason for Abandoning not present on all abandoned tests";
})(MESSAGES = exports.MESSAGES || (exports.MESSAGES = {}));
var VEHICLE_TYPE;
(function (VEHICLE_TYPE) {
    VEHICLE_TYPE["PSV"] = "psv";
    VEHICLE_TYPE["HGV"] = "hgv";
    VEHICLE_TYPE["TRL"] = "trl";
})(VEHICLE_TYPE = exports.VEHICLE_TYPE || (exports.VEHICLE_TYPE = {}));
var EXPIRY_STRATEGY;
(function (EXPIRY_STRATEGY) {
    EXPIRY_STRATEGY["PSV_DEFAULT"] = "PsvDefaultExpiryStrategy";
    EXPIRY_STRATEGY["PSV_MOST_RECENT"] = "PsvMostRecentExpiryStrategy";
    EXPIRY_STRATEGY["PSV_REGN_ANNIVERSARY"] = "PsvRegistrationAnniversaryStrategy";
    EXPIRY_STRATEGY["HGV_TRL_FIRST_TEST"] = "HgvTrlFirstTestStrategy";
    EXPIRY_STRATEGY["HGV_TRL_ANNUAL_TEST"] = "HgvTrlAnnualTestStrategy";
    EXPIRY_STRATEGY["HGV_TRL_MOST_RECENT"] = "HgvTrlMostRecentExpiryStrategy";
})(EXPIRY_STRATEGY = exports.EXPIRY_STRATEGY || (exports.EXPIRY_STRATEGY = {}));
exports.VEHICLE_TYPES = {
    PSV: "psv",
    HGV: "hgv",
    TRL: "trl",
    LGV: "lgv",
    MOTORCYCLE: "motorcycle",
    CAR: "car"
};
exports.TEST_TYPE_CLASSIFICATION = {
    ANNUAL_WITH_CERTIFICATE: "Annual With Certificate"
};
exports.TEST_RESULT = {
    PASS: "pass",
    FAIL: "fail",
    ABANDONED: "abandoned",
    PRS: "prs"
};
exports.TEST_STATUS = {
    SUBMITTED: "submitted",
    CANCELLED: "cancelled"
};
exports.TEST_VERSION = {
    CURRENT: "current",
    ARCHIVED: "archived",
    ALL: "all"
};
exports.REASON_FOR_CREATION = {
    TEST_CONDUCTED: "Test conducted"
};
exports.HGV_TRL_ROADWORTHINESS_TEST_TYPES = {
    IDS: ["122", "91", "101", "62", "63"]
};
exports.COIF_EXPIRY_TEST_TYPES = {
    IDS: ["142", "146", "175", "177"]
};
exports.LEC_TEST_TYPES = {
    IDS: ["39", "44", "45"]
};
exports.ADR_TEST_TYPES = {
    IDS: ["50", "59", "60"]
};
exports.TIR_TEST_TYPES = {
    IDS: ["49", "56", "57"]
};
exports.COUNTRY_OF_REGISTRATION = [
    "gb",
    "gba",
    "gbg",
    "gbj",
    "gbm",
    "gbz",
    "a",
    "b",
    "bih",
    "bg",
    "hr",
    "cy",
    "cz",
    "dk",
    "est",
    "fin",
    "f",
    "d",
    "gr",
    "h",
    "irl",
    "i",
    "lv",
    "lt",
    "l",
    "m",
    "nl",
    "n",
    "pl",
    "p",
    "ro",
    "sk",
    "slo",
    "e",
    "s",
    "ch",
    "non-eu",
    "not-known"
];
exports.TEST_CODES_FOR_CALCULATING_EXPIRY = {
    CODES: [
        "AAT1", "AAT2", "AAT3", "AAT4", "AAT5",
        "FFT1", "FFT2", "FFT3", "FFT4", "FFT5",
        "RPT1", "RPT2", "RPT3", "RPT4", "RPT5",
        "RST1", "RST2", "RST3", "RST4", "RST5",
        "RGT1", "RGT2", "RGT3", "RGT4", "RGT5",
        "RIT1", "RIT2", "RIT3", "RIT4", "RIT5",
        "RHT",
        "P1T1", "P1T2", "P1T3", "P1T4", "P1T5",
        "P3T1", "P3T2", "P3T3", "P3T4", "P3T5",
        "P6T1", "P6T2", "P6T3", "P6T4", "P6T5",
        "P7T1", "P7T2", "P7T3", "P7T4", "P7T5",
        "P4T1", "P4T2", "P4T3", "P4T4", "P4T5",
        "AAV2", "AAV3", "AAV4", "AAV5",
        "FFV2", "FFV3", "FFV4", "FFV5",
        "RPV2", "RPV3", "RPV4", "RPV5",
        "RSV2", "RSV3", "RSV4", "RSV5",
        "RGV2", "RGV3", "RGV4", "RGV5",
        "RIV2", "RIV3", "RIV4", "RIV5",
        "P1V2", "P1V3", "P1V4", "P1V5",
        "P3V2", "P3V3", "P3V4", "P3V5",
        "P6V2", "P6V3", "P6V4", "P6V5",
        "P4V2", "P4V3", "P4V4", "P4V5",
        "P7V2", "P7V3", "P7V4", "P7V5",
        "AAL", "AAS", "ADL",
        "WDL", "WDS", "WBL", "WBS",
        "RHL", "RPL", "RPS",
        "WHL", "WHS",
        "RGL", "RSL", "RSS",
        "P1L", "P1S",
        "P8L", "P8S",
        "P6L", "P6S",
        "WIS", "WIL",
        "WFL", "WFS",
        "WEL", "WES",
        "CEL", "CES",
        "CHL", "CHS",
        "CKL", "CKS",
        "CML", "CMS"
    ]
};
// CVSB-10300 - the following constants are based on the grouping of the test-types in the excel "Use_for_dynamic_functionality - CVSB-10298 only" sheet
// tests for PSV - Annual test, Class 6A seatbelt installation check(annual test, first test), Paid/Part paid annual test retest
// Paid/Part paid prohibition clearance(full inspection, retest with certificate), Prohibition clearance(retest with/without class 6A seatbelt)
exports.TEST_TYPES_GROUP1 = [
    "1", "3", "4", "7", "8", "10", "14", "18", "21", "27", "28", "93"
];
// tests for PSV - Paid/Part paid prohibition clearance(full/partial/retest without cert)
exports.TEST_TYPES_GROUP2 = [
    "15", "16", "23", "19", "22"
];
// 38 through 36 - tests for PSV - Notifiable alteration check, voluntary brake test, voluntary multi check, voluntary speed limiter check
// voluntary smoke test, voluntary headlamp aim test, vitesse 100 replacement, vitesse 100 application, voluntary tempo 100
// 86 through 90 - tests for HGV - voluntary multi-check, voluntary speed limiter check, voluntary smoke and headlamp aim test
// 87 through 85 - tests for HGV and TRL - voluntary shaker plate check, Free/Paid notifiable alteration, voluntary break test
exports.TEST_TYPES_GROUP3_4_8 = [
    "38", "30", "33", "34", "32", "31", "100", "121", "36", "86", "88", "89", "90", "87", "47", "48", "85"
];
// 56 and 49 - tests for HGV and TRL - Paid TIR retest, TIR test
// 57 - test for TRL - Free TIR retest
exports.TEST_TYPES_GROUP5_13 = [
    "56", "49", "57"
];
// 62, 63, 122 - tests for HGV and TRL - Paid/Part paid roadworthiness retest, Voluntary roadworthiness test
// 101, 91 - tests for TRL - Paid roadworthiness retest, Voluntary roadworthiness test
exports.TEST_TYPES_GROUP6_11 = [
    "62", "63", "122", "101", "91"
];
// ADR tests for HGV and TRL
exports.TEST_TYPES_GROUP7 = [
    "59", "60", "50"
];
// tests for HGV and TRL - Annual tests, First tests, Annual retests, Paid/Part paid prohibition clearance
exports.TEST_TYPES_GROUP9_10 = [
    "76", "95", "94", "53", "54", "65", "66", "70", "79", "82", "83", "41", "40", "98", "99", "103", "104", "67", "107", "113", "116", "119", "120"
];
// tests for TRL - Paid/Part paid prohibition clearance(retest, full inspection, part inspection, without cert)
exports.TEST_TYPES_GROUP12_14 = [
    "117", "108", "109", "110", "114", "71", "72", "73", "77", "80"
];
// 39 - LEC with annual test for PSV, 45 - LEC without annual test for HGV, 44 - LEC with annual test for HGV
exports.TEST_TYPES_GROUP15_16 = [
    "39", "45", "44"
];
// CVSB-10372 - the following constants are based on the grouping of the test-types for specialist tests in the excel "specialist test fields mapping"
// Test/Retest - Free/Paid - IVA inspection, MSVA inspection
exports.TEST_TYPES_GROUP1_SPEC_TEST = [
    "125", "126", "186", "187", "128", "188", "189", "129", "130", "133", "134", "135", "136", "138", "139", "140", "150", "151",
    "158", "159", "161", "192", "193", "162", "194", "195", "163", "166", "167", "169", "170", "172", "173", "181", "182"
];
// Test/Retest COIF with annual test, Seatbelt installation check COIF with annual test
exports.TEST_TYPES_GROUP2_SPEC_TEST = [
    "142", "146", "175", "177"
];
// Test/Retest COIF without annual test, Type approved to bus directive COIF, Annex 7 COIF, TILT COIF retest
exports.TEST_TYPES_GROUP3_SPEC_TEST = [
    "143", "144", "148", "176", "178", "179",
];
// Test Seatbelt installation check COIF without annual test
exports.TEST_TYPES_GROUP4_SPEC_TEST = [
    "147"
];
// Test/Retest Normal/Basic voluntary IVA inspection
exports.TEST_TYPES_GROUP5_SPEC_TEST = [
    "153", "190", "191", "154", "184", "196", "197", "185",
];
exports.SPECIALIST_TEST_TYPE_IDS = [
    "125", "126", "186", "187", "128", "188", "189", "129", "130", "133", "134", "135", "136", "138", "139", "140", "150", "151",
    "158", "159", "161", "192", "193", "162", "194", "195", "163", "166", "167", "169", "170", "172", "173", "181", "182",
    "142", "146", "175", "177", "143", "144", "148", "176", "178", "179", "147", "153", "190", "191", "154", "184", "196", "197", "185"
];
