"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(require("./TestResultsSchemaHGVCancelled"));
__export(require("./TestResultsSchemaHGVSubmitted"));
__export(require("./TestResultsSchemaPSVCancelled"));
__export(require("./TestResultsSchemaPSVSubmitted"));
__export(require("./TestResultsSchemaTRLCancelled"));
__export(require("./TestResultsSchemaTRLSubmitted"));
__export(require("./TestResultsSchemaLGVCancelled"));
__export(require("./TestResultsSchemaLGVSubmitted"));
__export(require("./TestResultsSchemaCarCancelled"));
__export(require("./TestResultsSchemaCarSubmitted"));
__export(require("./TestResultsSchemaMotorcycleCancelled"));
__export(require("./TestResultsSchemaMotorcycleSubmitted"));
__export(require("./test-types/testTypesSchemaPut"));
__export(require("./test-types/testTypesSchemaSpecialistTestsPut"));
