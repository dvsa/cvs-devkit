"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const Joi = __importStar(require("joi"));
exports.testTypesCommonSchemaSpecialistTests = Joi.object().keys({
    name: Joi.string().required(),
    testTypeName: Joi.string().required(),
    testTypeId: Joi.string().required(),
    testTypeStartTimestamp: Joi.date().iso().required(),
    testTypeEndTimestamp: Joi.date().iso().required(),
    testResult: Joi.any().only(["fail", "pass", "prs", "abandoned"]).required(),
    prohibitionIssued: Joi.boolean().required(),
    reasonForAbandoning: Joi.string().when("$hasTestResult", {
        is: "abandoned",
        then: Joi.string().required(),
        otherwise: Joi.string().optional().allow(null)
    }),
    additionalNotesRecorded: Joi.string().max(500).allow("", null),
    additionalCommentsForAbandon: Joi.string().max(500).allow("", null),
    customDefects: Joi.array().items(Joi.object().keys({
        referenceNumber: Joi.string().max(10).required(),
        defectName: Joi.string().max(200).required(),
        defectNotes: Joi.string().max(200).required()
    })).required(),
    testCode: Joi.string().required(),
    testNumber: Joi.string().required(),
    createdAt: Joi.string().optional(),
    lastUpdatedAt: Joi.string().optional(),
    certificateLink: Joi.string().optional(),
    testTypeClassification: Joi.string().required()
}).required();
exports.testTypesSpecialistGroup1 = exports.testTypesCommonSchemaSpecialistTests.keys({
    certificateNumber: Joi.string().required()
});
exports.testTypesSpecialistGroup2 = exports.testTypesCommonSchemaSpecialistTests.keys({
    certificateNumber: Joi.string().required(),
    secondaryCertificateNumber: Joi.string().alphanum().max(20).required(),
    testExpiryDate: Joi.date().iso().required(),
    testAnniversaryDate: Joi.date().iso().required(),
    numberOfSeatbeltsFitted: Joi.number().required(),
    lastSeatbeltInstallationCheckDate: Joi.date().required(),
    seatbeltInstallationCheckDate: Joi.boolean().required()
});
exports.testTypesSpecialistGroup3 = exports.testTypesCommonSchemaSpecialistTests.keys({
    secondaryCertificateNumber: Joi.string().alphanum().max(20).required()
});
exports.testTypesSpecialistGroup4 = exports.testTypesCommonSchemaSpecialistTests.keys({
    secondaryCertificateNumber: Joi.string().alphanum().max(20).required(),
    numberOfSeatbeltsFitted: Joi.number().required(),
    lastSeatbeltInstallationCheckDate: Joi.date().required(),
    seatbeltInstallationCheckDate: Joi.boolean().required()
});
exports.testTypesSpecialistGroup5 = exports.testTypesCommonSchemaSpecialistTests;
