"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const SpecialistTestsCommonSchemaCancelled_1 = require("./SpecialistTestsCommonSchemaCancelled");
exports.motorcycleCancelled = SpecialistTestsCommonSchemaCancelled_1.testResultsCommonSchemaSpecialistTestsCancelled;
