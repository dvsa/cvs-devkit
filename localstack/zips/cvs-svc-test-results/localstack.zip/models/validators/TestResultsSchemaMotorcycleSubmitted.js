"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const Joi = __importStar(require("joi"));
const SpecialistTestsCommonSchemaSubmitted_1 = require("./SpecialistTestsCommonSchemaSubmitted");
exports.motorcycleSubmitted = SpecialistTestsCommonSchemaSubmitted_1.testResultsCommonSchemaSpecialistTestsSubmitted.keys({
    vehicleClass: Joi.object().keys({
        code: Joi.any().only(["1", "2", "3", "n", "s", "t", "l", "v", "4", "5", "7", "p", "u"]).required(),
        description: Joi.any().only([
            "motorbikes up to 200cc",
            "motorbikes over 200cc or with a sidecar",
            "3 wheelers",
            "not applicable",
            "small psv (ie: less than or equal to 22 seats)",
            "trailer",
            "large psv(ie: greater than 23 seats)",
            "heavy goods vehicle",
            "MOT class 4",
            "MOT class 5",
            "MOT class 7",
            "PSV of unknown or unspecified size",
            "Not Known"
        ])
    }).required(),
});
