"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Configuration_1 = require("../utils/Configuration");
const LambdaService_1 = require("../services/LambdaService");
/* tslint:disable */
let AWS;
if (process.env._X_AMZN_TRACE_ID) {
    AWS = require("aws-xray-sdk").captureAWS(require("aws-sdk"));
}
else {
    console.log("Serverless Offline detected; skipping AWS X-Ray setup");
    AWS = require("aws-sdk");
}
/* tslint:enable */
class TestResultsDAO {
    constructor() {
        const config = Configuration_1.Configuration.getInstance().getDynamoDBConfig();
        console.log("TestResultsDAO config:\n", config);
        this.tableName = config.table;
        if (!TestResultsDAO.docClient) {
            TestResultsDAO.docClient = new AWS.DynamoDB.DocumentClient(config.params);
        }
        if (!TestResultsDAO.lambdaInvokeEndpoints) {
            TestResultsDAO.lambdaInvokeEndpoints = Configuration_1.Configuration.getInstance().getEndpoints();
        }
    }
    getBySystemNumber(systemNumber) {
        const params = {
            TableName: this.tableName,
            IndexName: "SysNumIndex",
            KeyConditionExpression: "#systemNumber = :systemNumber",
            ExpressionAttributeNames: {
                "#systemNumber": "systemNumber",
            },
            ExpressionAttributeValues: {
                ":systemNumber": systemNumber,
            },
        };
        console.log("getBySystemNumber: PARAMS ->", params);
        return TestResultsDAO.docClient.query(params).promise();
    }
    getByTesterStaffId(testerStaffId) {
        const params = {
            TableName: this.tableName,
            IndexName: "TesterStaffIdIndex",
            KeyConditionExpression: "#testerStaffId = :testerStaffId",
            ExpressionAttributeNames: {
                "#testerStaffId": "testerStaffId",
            },
            ExpressionAttributeValues: {
                ":testerStaffId": testerStaffId,
            },
        };
        console.log("getByTesterStaffId: PARAMS ->", params);
        return this.queryAllData(params);
    }
    createSingle(payload) {
        const query = {
            TableName: this.tableName,
            Item: payload,
            ConditionExpression: "testResultId <> :testResultIdVal",
            ExpressionAttributeValues: {
                ":testResultIdVal": payload.testResultId,
            },
        };
        return TestResultsDAO.docClient.put(query).promise();
    }
    createMultiple(testResultsItems) {
        const params = this.generateBatchWritePartialParams();
        testResultsItems.forEach((testResultItem) => {
            params.RequestItems[this.tableName].push({
                PutRequest: {
                    Item: testResultItem,
                },
            });
        });
        return TestResultsDAO.docClient.batchWrite(params).promise();
    }
    deleteMultiple(systemNumberIdPairsToBeDeleted) {
        const params = this.generateBatchWritePartialParams();
        systemNumberIdPairsToBeDeleted.forEach((systemNumberIdPairToBeDeleted) => {
            const systemNumberToBeDeleted = Object.keys(systemNumberIdPairToBeDeleted)[0];
            const testResultIdToBeDeleted = systemNumberIdPairToBeDeleted[systemNumberToBeDeleted];
            params.RequestItems[this.tableName].push({
                DeleteRequest: {
                    Key: {
                        systemNumber: systemNumberToBeDeleted,
                        testResultId: testResultIdToBeDeleted,
                    },
                },
            });
        });
        return TestResultsDAO.docClient.batchWrite(params).promise();
    }
    generateBatchWritePartialParams() {
        return {
            RequestItems: {
                [this.tableName]: Array(),
            },
        };
    }
    async getTestCodesAndClassificationFromTestTypes(testTypeId, testTypeParams) {
        const fields = "defaultTestCode,linkedTestCode,testTypeClassification";
        const { vehicleType, vehicleSize, vehicleConfiguration, vehicleAxles, euVehicleCategory, vehicleClass, vehicleSubclass, vehicleWheels, } = testTypeParams;
        const event = {
            path: "/test-types/" + testTypeId,
            queryStringParameters: {
                vehicleType,
                vehicleSize,
                vehicleConfiguration,
                vehicleAxles,
                euVehicleCategory,
                vehicleClass,
                vehicleSubclass,
                vehicleWheels,
                fields,
            },
            pathParameters: {
                id: testTypeId,
            },
            httpMethod: "GET",
            resource: "/test-types/{id}",
        };
        const lambdaName = TestResultsDAO.lambdaInvokeEndpoints.functions.getTestTypesById.name;
        try {
            console.log("queryString for get Test: ", event);
            console.log("getTestCodesAndClassificationFromTestTypes()");
            console.log("lambdaName called is:\n", lambdaName);
            const lambdaResult = LambdaService_1.LambdaService.invoke(lambdaName, event);
            return lambdaResult;
        }
        catch (error) {
            console.error(`error during lambda invocation: ${lambdaName} and ${event}, \nwith error:${error}`);
        }
        // TODO Add Mocks CVSB-19153
        // return Promise.resolve({
        //   testTypeClassification: "foo",
        //   linkedTestCode: "linkedTestCode",
        //   defaultTestCode: "defaultTestCode",
        // });
    }
    async createTestNumber() {
        const event = {
            path: "/test-number/",
            httpMethod: "POST",
            resource: "/test-number/",
        };
        const lambdaName = TestResultsDAO.lambdaInvokeEndpoints.functions.getTestNumber.name;
        try {
            console.log("createTestNumber()");
            console.log("lambdaName called is:\n", lambdaName);
            const lambdaResult = LambdaService_1.LambdaService.invoke(lambdaName, event);
            return lambdaResult;
        }
        catch (error) {
            console.error(`error during lambda invocation: ${lambdaName} and ${event}, \nwith error:${error}`);
        }
        // TODO Add Mocks CVSB-19153
        // return Promise.resolve({
        //   id: "W01",
        //   certLetter: "A",
        //   sequenceNumber: "003",
        //   testNumber: "W01A00330",
        //   testNumberKey: 1,
        // });
    }
    getActivity(filters) {
        const event = {
            path: "/activities/details",
            queryStringParameters: {
                fromStartTime: filters.fromStartTime,
                toStartTime: filters.toStartTime,
                activityType: filters.activityType,
                testStationPNumber: filters.testStationPNumber,
                testerStaffId: filters.testerStaffId,
            },
            httpMethod: "GET",
            resource: "/activities/details",
        };
        const lambdaName = TestResultsDAO.lambdaInvokeEndpoints.functions.getActivity.name;
        try {
            console.log("getActivity()");
            console.log("lambdaName called is:\n", lambdaName);
            const lambdaResult = LambdaService_1.LambdaService.invoke(lambdaName, event);
            return lambdaResult;
        }
        catch (error) {
            console.error(`error during lambda invocation: ${lambdaName} and ${event}, \nwith error:${error}`);
        }
        // TODO Add Mocks - CVSB-19153
        // return [
        //   {
        //     testerStaffId: "62ef-ccd-4f-9-b72",
        //     testerName: "mail@mail.com",
        //     testStationName: "Name",
        //     activityDay: "2021-02-22",
        //     parentId: "db1c62a8-43c3-469e-ae9a-19a43583d127",
        //     testStationPNumber: "09-4129632",
        //     testStationType: "gvts",
        //     startTime: new Date(Date.now() - 1000000).toISOString(),
        //     activityType: "unaccountable time",
        //     // endTime: new Date(Date.now() + 1000000).toISOString(),
        //     endTime: null,
        //     waitReason: [],
        //     notes: null,
        //     testStationEmail: "mail@mail.com",
        //     id: "d015f-c4646-49877-bc559-11d0f6dd8",
        //   },
        // ];
    }
    updateTestResult(updatedTestResult) {
        const query = {
            TransactItems: [
                {
                    Put: {
                        TableName: this.tableName,
                        Item: updatedTestResult,
                        ConditionExpression: "systemNumber = :systemNumber AND testResultId = :oldTestResultId AND vin = :vin",
                        ExpressionAttributeValues: {
                            ":systemNumber": updatedTestResult.systemNumber,
                            ":vin": updatedTestResult.vin,
                            ":oldTestResultId": updatedTestResult.testResultId,
                        },
                    },
                },
            ],
        };
        return TestResultsDAO.docClient.transactWrite(query).promise();
    }
    async queryAllData(params, allData = []) {
        const data = await TestResultsDAO.docClient.query(params).promise();
        if (data.Items && data.Items.length > 0) {
            allData = [...allData, ...data.Items];
        }
        if (data.LastEvaluatedKey) {
            params.ExclusiveStartKey = data.LastEvaluatedKey;
            return this.queryAllData(params, allData);
        }
        else {
            return allData;
        }
    }
}
exports.TestResultsDAO = TestResultsDAO;
