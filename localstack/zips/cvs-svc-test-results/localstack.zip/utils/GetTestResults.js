"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Enums_1 = require("../assets/Enums");
class GetTestResults {
    static filterTestResultsByParam(testResults, filterName, filterValue) {
        return testResults.filter((testResult) => {
            return testResult[filterName] === filterValue;
        });
    }
    static filterTestResultsByTestVersion(testResults, testVersion = Enums_1.TEST_VERSION.CURRENT) {
        let result = [];
        if (testVersion === Enums_1.TEST_VERSION.ALL) {
            return testResults;
        }
        for (const testResult of testResults) {
            if (testVersion === Enums_1.TEST_VERSION.CURRENT && (testResult.testVersion === Enums_1.TEST_VERSION.CURRENT || !testResult.testVersion)) {
                delete testResult.testHistory;
                result.push(testResult);
            }
            else if (testVersion === Enums_1.TEST_VERSION.ARCHIVED) {
                if (testResult.testVersion === Enums_1.TEST_VERSION.ARCHIVED) {
                    result.push(testResult);
                    if (testResult.testHistory) {
                        result = result.concat(testResult.testHistory);
                        delete testResult.testHistory;
                    }
                }
                else {
                    result = testResult.testHistory || [];
                }
            }
        }
        return result;
    }
    static removeTestHistory(testResults) {
        for (const testResult of testResults) {
            delete testResult.testHistory;
        }
        return testResults;
    }
    static filterTestResultsByDeletionFlag(testResults) {
        return testResults.filter((testResult) => {
            return !testResult.deletionFlag === true;
        });
    }
    static filterTestTypesByDeletionFlag(testResults) {
        testResults.forEach((testResult) => {
            const filteredTestTypes = testResult.testTypes.filter((testType) => {
                return !testType.deletionFlag === true;
            });
            testResult.testTypes = filteredTestTypes;
        });
        return testResults;
    }
}
exports.GetTestResults = GetTestResults;
