"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const lodash_1 = require("lodash");
const enums = __importStar(require("../assets/Enums"));
const HTTPError_1 = require("../models/HTTPError");
const DateProvider_1 = require("../handlers/expiry/providers/DateProvider");
class MappingUtil {
    static getSubSegment(newSubSegment) {
        let subSegment = null;
        if (!process.env._X_AMZN_TRACE_ID) {
            console.log("Serverless Offline detected; skipping AWS X-Ray setup");
            return subSegment;
        }
        const AWS = require("aws-xray-sdk");
        const segment = AWS.getSegment();
        AWS.capturePromise();
        if (segment) {
            subSegment = segment.addNewSubsegment(newSubSegment);
        }
        return subSegment;
    }
    static getTestResultsBySystemNumberFilters(event, subSegment) {
        let toDate = DateProvider_1.DateProvider.getEndOfDay();
        let fromDate = DateProvider_1.DateProvider.getTwoYearsFromDate(toDate);
        let testStatus = enums.TEST_STATUS.SUBMITTED;
        let testVersion = enums.TEST_VERSION.CURRENT;
        let resultId;
        if (event.queryStringParameters) {
            const { toDateTime, fromDateTime, status, testResultId, version, } = event.queryStringParameters;
            if (toDateTime === "" || fromDateTime === "") {
                const errorDate = toDateTime === "" ? "toDate" : "fromDate";
                if (subSegment) {
                    subSegment.addError(`Bad Request - ${errorDate} empty`);
                }
                console.log(`Bad Request in getTestResultsBySystemNumber - ${errorDate} empty`);
                throw new HTTPError_1.HTTPError(400, enums.MESSAGES.BAD_REQUEST);
            }
            toDate = toDateTime ? new Date(toDateTime) : DateProvider_1.DateProvider.getEndOfDay();
            fromDate = fromDateTime
                ? new Date(fromDateTime)
                : DateProvider_1.DateProvider.getTwoYearsFromDate(toDateTime);
            if (status) {
                testStatus = status;
            }
            if (testResultId) {
                resultId = testResultId;
            }
            if (version) {
                testVersion = version;
            }
        }
        const filters = {
            systemNumber: event.pathParameters.systemNumber,
            testStatus,
            toDateTime: toDate,
            fromDateTime: fromDate,
            testResultId: resultId,
            testVersion,
        };
        return filters;
    }
    static getTestResultsByTesterStaffIdFilters(event, subSegment) {
        const BAD_REQUEST_MISSING_FIELDS = "Bad request in getTestResultsByTesterStaffId - missing required parameters";
        if (!event.queryStringParameters) {
            throw new HTTPError_1.HTTPError(400, enums.MESSAGES.BAD_REQUEST);
        }
        const { testerStaffId, toDateTime, fromDateTime, testStationPNumber, testStatus, } = event.queryStringParameters;
        if (!testerStaffId || !toDateTime || !fromDateTime) {
            console.log(BAD_REQUEST_MISSING_FIELDS);
            if (subSegment) {
                subSegment.addError(BAD_REQUEST_MISSING_FIELDS);
            }
            throw new HTTPError_1.HTTPError(400, enums.MESSAGES.BAD_REQUEST);
        }
        const filters = {
            testerStaffId,
            testStatus,
            testStationPNumber,
            toDateTime: new Date(toDateTime),
            fromDateTime: new Date(fromDateTime),
        };
        return filters;
    }
    static cleanDefectsArrayForSpecialistTests(testResult) {
        testResult.testTypes.forEach((testType) => {
            if (enums.SPECIALIST_TEST_TYPE_IDS.includes(testType.testTypeId)) {
                testType.defects = [];
            }
        });
    }
    static setCreatedAtAndLastUpdatedAtDates(payload) {
        const createdAtDate = new Date().toISOString();
        payload.createdAt = createdAtDate;
        payload.createdById = payload.testerStaffId;
        payload.createdByName = payload.testerName;
        payload.testVersion = enums.TEST_VERSION.CURRENT;
        payload.reasonForCreation = enums.REASON_FOR_CREATION.TEST_CONDUCTED;
        payload.testTypes.forEach((testType) => {
            Object.assign(testType, {
                createdAt: createdAtDate,
                lastUpdatedAt: createdAtDate,
            });
        });
        return payload;
    }
    static setAuditDetails(newTestResult, oldTestResult, msUserDetails) {
        const date = new Date().toISOString();
        newTestResult.createdAt = date;
        newTestResult.createdByName = msUserDetails.msUser;
        newTestResult.createdById = msUserDetails.msOid;
        delete newTestResult.lastUpdatedAt;
        delete newTestResult.lastUpdatedById;
        delete newTestResult.lastUpdatedByName;
        oldTestResult.lastUpdatedAt = date;
        oldTestResult.lastUpdatedByName = msUserDetails.msUser;
        oldTestResult.lastUpdatedById = msUserDetails.msOid;
        newTestResult.shouldEmailCertificate = "false";
        oldTestResult.shouldEmailCertificate = "false;";
    }
    static arrayCustomizer(objValue, srcValue) {
        if (lodash_1.isArray(objValue) && lodash_1.isArray(srcValue)) {
            return srcValue;
        }
    }
    static removeNonEditableAttributes(testResult) {
        delete testResult.vehicleId;
        delete testResult.testEndTimestamp;
        delete testResult.testVersion;
        delete testResult.systemNumber;
        delete testResult.vin;
    }
    static mapErrorMessage(validation) {
        return validation.error.details.map((detail) => {
            return detail.message;
        });
    }
}
exports.MappingUtil = MappingUtil;
MappingUtil.addTestcodeToTestTypes = (service, params
// not sure why Ts complains as TestType has testTypeClassification key...
) => async (testType, _, testTypes) => {
    const { testTypeId } = testType;
    const { defaultTestCode, linkedTestCode, testTypeClassification, } = await service.getTestCodesAndClassificationFromTestTypes(testTypeId, params);
    return Object.assign(Object.assign({}, testType), { testTypeClassification, testCode: testTypes.length > 1 && linkedTestCode
            ? linkedTestCode
            : defaultTestCode });
};
MappingUtil.addTestNumberToTestTypes = (service) => async (testType) => {
    const { testNumber } = await service.createTestNumber();
    return Object.assign(Object.assign({}, testType), { testNumber });
};
