"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Enums_1 = require("../assets/Enums");
class LoggingUtil {
    /**
     * Function to log certain defects and advisory silently
     *
     * To be removed with CVSB-19020
     */
    static logDefectsReporting(testResult) {
        if (testResult.testStatus === Enums_1.TEST_STATUS.CANCELLED) {
            return;
        }
        testResult.testTypes.forEach((testType) => {
            if (testType.testResult !== Enums_1.TEST_RESULT.ABANDONED) {
                testType.defects.forEach((defect) => {
                    var _a, _b;
                    if (LoggingUtil.reportingDeficiencyRef.includes(defect.deficiencyRef)) {
                        const logObject = Object.assign({ vin: testResult.vin, vrm: testResult.vrm, additionalNotesRecorded: testType.additionalNotesRecorded, deficiencyRef: defect.deficiencyRef, deficiencyCategory: defect.deficiencyCategory, defectNotes: (_a = defect === null || defect === void 0 ? void 0 : defect.additionalInformation) === null || _a === void 0 ? void 0 : _a.notes }, (_b = defect === null || defect === void 0 ? void 0 : defect.additionalInformation) === null || _b === void 0 ? void 0 : _b.location);
                        console.info("Defects reporting: ", logObject);
                    }
                });
            }
        });
    }
}
exports.LoggingUtil = LoggingUtil;
LoggingUtil.reportingDeficiencyRef = ["8.1.i", "8.1.j.i", "8.1.j.ii", "8.1", "8.2"];
