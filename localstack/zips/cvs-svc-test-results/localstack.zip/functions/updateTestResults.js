"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const TestResultsDAO_1 = require("../models/TestResultsDAO");
const TestResultsService_1 = require("../services/TestResultsService");
const HTTPResponse_1 = require("../models/HTTPResponse");
const Enums_1 = require("../assets/Enums");
const mappingUtil_1 = require("../utils/mappingUtil");
async function updateTestResults(event) {
    const subseg = mappingUtil_1.MappingUtil.getSubSegment("updateTestResults");
    const testResultsDAO = new TestResultsDAO_1.TestResultsDAO();
    const testResultsService = new TestResultsService_1.TestResultsService(testResultsDAO);
    const systemNumber = event.pathParameters.systemNumber;
    const testResult = event.body.testResult;
    const msUserDetails = event.body.msUserDetails;
    try {
        if (!testResult) {
            const errorMessage = Enums_1.MESSAGES.BAD_REQUEST + " testResult not provided";
            if (subseg) {
                subseg.addError(errorMessage);
            }
            return Promise.resolve(new HTTPResponse_1.HTTPResponse(400, errorMessage));
        }
        if (!msUserDetails || !msUserDetails.msUser || !msUserDetails.msOid) {
            const errorMessage = Enums_1.MESSAGES.BAD_REQUEST + " msUserDetails not provided";
            if (subseg) {
                subseg.addError(errorMessage);
            }
            return Promise.resolve(new HTTPResponse_1.HTTPResponse(400, errorMessage));
        }
        try {
            const data = await testResultsService.updateTestResult(systemNumber, testResult, msUserDetails);
            return new HTTPResponse_1.HTTPResponse(200, data);
        }
        catch (error) {
            console.log("Error in updateTestResults > updateTestResults: ", error);
            if (subseg) {
                subseg.addError(error.body);
            }
            return new HTTPResponse_1.HTTPResponse(error.statusCode, error.body);
        }
    }
    finally {
        if (subseg) {
            subseg.close();
        }
    }
}
exports.updateTestResults = updateTestResults;
