"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const TestResultsDAO_1 = require("../models/TestResultsDAO");
const TestResultsService_1 = require("../services/TestResultsService");
const HTTPResponse_1 = require("../models/HTTPResponse");
const mappingUtil_1 = require("../utils/mappingUtil");
async function getTestResultsBySystemNumber(event) {
    const subSegment = mappingUtil_1.MappingUtil.getSubSegment("getTestResultsBySystemNumber");
    const testResultsDAO = new TestResultsDAO_1.TestResultsDAO();
    const testResultsService = new TestResultsService_1.TestResultsService(testResultsDAO);
    try {
        const data = await testResultsService.getTestResultBySystemNumber(mappingUtil_1.MappingUtil.getTestResultsBySystemNumberFilters(event, subSegment));
        return new HTTPResponse_1.HTTPResponse(200, data);
    }
    catch (error) {
        if (subSegment) {
            subSegment.addError(error.body);
        }
        console.log("Error in getTestResultsBySystemNumber: ", error);
        return new HTTPResponse_1.HTTPResponse(error.statusCode, error.body);
    }
    finally {
        if (subSegment) {
            subSegment.close();
        }
    }
}
exports.getTestResultsBySystemNumber = getTestResultsBySystemNumber;
