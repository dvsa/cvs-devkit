"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const TestResultsDAO_1 = require("../models/TestResultsDAO");
const TestResultsService_1 = require("../services/TestResultsService");
const HTTPResponse_1 = require("../models/HTTPResponse");
const Enums_1 = require("../assets/Enums");
const mappingUtil_1 = require("../utils/mappingUtil");
async function postTestResults(event) {
    const subseg = mappingUtil_1.MappingUtil.getSubSegment("postTestResults");
    const testResultsDAO = new TestResultsDAO_1.TestResultsDAO();
    const testResultsService = new TestResultsService_1.TestResultsService(testResultsDAO);
    const payload = event.body;
    try {
        if (!payload) {
            if (subseg) {
                subseg.addError(Enums_1.MESSAGES.INVALID_JSON);
            }
            return Promise.resolve(new HTTPResponse_1.HTTPResponse(400, Enums_1.MESSAGES.INVALID_JSON));
        }
        await testResultsService.insertTestResult(payload);
        return new HTTPResponse_1.HTTPResponse(201, Enums_1.MESSAGES.RECORD_CREATED);
    }
    catch (error) {
        console.log("Error in postTestResults > insertTestResults: ", error);
        if (subseg) {
            subseg.addError(error.body);
        }
        return new HTTPResponse_1.HTTPResponse(error.statusCode, error.body);
    }
    finally {
        if (subseg) {
            subseg.close();
        }
    }
}
exports.postTestResults = postTestResults;
