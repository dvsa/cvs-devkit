"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
var VehicleTestController_1;
Object.defineProperty(exports, "__esModule", { value: true });
const enums = __importStar(require("../assets/Enums"));
const utils = __importStar(require("../utils"));
const models = __importStar(require("../models"));
const ExpiryDateStrategyFactory_1 = require("./expiry/ExpiryDateStrategyFactory");
const ServiceDecorator_1 = require("../models/injector/ServiceDecorator");
const TestDataProvider_1 = require("./expiry/providers/TestDataProvider");
const DateProvider_1 = require("./expiry/providers/DateProvider");
let VehicleTestController = VehicleTestController_1 = class VehicleTestController {
    constructor(dataProvider, dateProvider) {
        this.dataProvider = dataProvider;
        this.dateProvider = dateProvider;
    }
    //#region [rgba(52, 152, 219, 0.15)] Public functions
    /**
     * To fetch test results by SystemNumber
     * @param filters test results filters for search
     */
    async getTestResultBySystemNumber(filters) {
        if (!filters.systemNumber ||
            !utils.ValidationUtil.validateGetTestResultFilters(filters)) {
            throw new models.HTTPError(400, enums.MESSAGES.BAD_REQUEST);
        }
        const result = await this.dataProvider.getTestResultBySystemNumber(filters);
        if (result.length === 0) {
            throw new models.HTTPError(404, enums.ERRORS.NoResourceMatch);
        }
        return result;
    }
    /**
     * To fetch test results by Tester Staff Id
     * @param filters test results filters for search
     */
    async getTestResultByTestStaffId(filters) {
        if (!filters.testerStaffId ||
            !utils.ValidationUtil.validateGetTestResultFilters(filters)) {
            throw new models.HTTPError(400, enums.MESSAGES.BAD_REQUEST);
        }
        const result = await this.dataProvider.getTestResultByTesterStaffId(filters);
        if (result.length === 0) {
            throw new models.HTTPError(404, enums.ERRORS.NoResourceMatch);
        }
        return result;
    }
    /**
     * A factory method used to fetch a strategy for calculating expiry date based on a strategy mapping JSON file.
     * @param testTypeForExpiry an input object which is used to calculate expiry based on test type.
     */
    getExpiryStrategy(testTestForExpiry) {
        const selectedStrategy = ExpiryDateStrategyFactory_1.ExpiryDateStrategyFactory.GetExpiryStrategy(testTestForExpiry, this.dateProvider);
        return selectedStrategy;
    }
    async insertTestResult(payload) {
        var _a, _b;
        try {
            utils.ValidationUtil.validateInsertTestResultPayload(payload);
            console.info("validation is success");
            payload = utils.MappingUtil.setCreatedAtAndLastUpdatedAtDates(payload);
            const testTypeParams = {
                vehicleType: payload.vehicleType,
                vehicleSize: payload.vehicleSize,
                vehicleConfiguration: payload.vehicleConfiguration,
                vehicleAxles: payload.noOfAxles,
                euVehicleCategory: payload.euVehicleCategory,
                vehicleClass: (_a = payload.vehicleClass) === null || _a === void 0 ? void 0 : _a.code,
                vehicleSubclass: (_b = payload.vehicleSubclass) === null || _b === void 0 ? void 0 : _b[0],
                vehicleWheels: payload.numberOfWheelsDriven,
            };
            const testTypesWithTestCodesAndClassification = await this.dataProvider.getTestTypesWithTestCodesAndClassification(payload.testTypes, testTypeParams);
            payload.testTypes = testTypesWithTestCodesAndClassification;
            const payloadWithTestNumber = await this.dataProvider.setTestNumberForEachTestType(payload);
            // @ts-ignore
            payload.testTypes = payloadWithTestNumber;
            const payloadWithExpiryDate = await this.generateExpiryDate(payload);
            const payloadWithCertificateNumber = VehicleTestController_1.AssignCertificateNumberToTestTypes(payloadWithExpiryDate);
            const payloadWithAnniversaryDate = VehicleTestController_1.calculateAnniversaryDate(payloadWithCertificateNumber);
            payloadWithAnniversaryDate.vehicleId = payloadWithAnniversaryDate.vrm;
            const result = await this.dataProvider.insertTestResult(payloadWithAnniversaryDate);
            return result;
        }
        catch (error) {
            if (error.statusCode === 400 &&
                error.message === enums.MESSAGES.CONDITIONAL_REQUEST_FAILED) {
                console.info("TestResultService.insertTestResult: Test Result id already exists", error);
                error = new models.HTTPResponse(201, enums.MESSAGES.ID_ALREADY_EXISTS);
            }
            throw error;
        }
    }
    //#endregion
    //#region [rgba(0, 205, 30, 0.1)] Private functions
    /**
     * Note: When performing actions on a moment instance, it gets mutated
     * Note: Expiry dates on the payload should be set at the UTC start of day.
     *
     * @param payload
     */
    async generateExpiryDate(payload) {
        try {
            if (payload.testStatus !== enums.TEST_STATUS.SUBMITTED ||
                utils.ValidationUtil.isNotAllowedVehicleTypeForExpiry(payload.vehicleType)) {
                return payload;
            }
            const expiryTestTypes = payload.testTypes.filter((testType) => utils.ValidationUtil.isAllowedTestTypeForExpiry(testType));
            const recentExpiry = await this.dataProvider.getMostRecentExpiryDate(payload.systemNumber);
            expiryTestTypes.forEach((testType, index) => {
                const testTypeForExpiry = {
                    testType,
                    vehicleType: enums.VEHICLE_TYPE[payload.vehicleType.toUpperCase()],
                    recentExpiry,
                    regnOrFirstUseDate: VehicleTestController_1.getRegistrationOrFirstUseDate(payload),
                    hasHistory: !DateProvider_1.DateProvider.isSameAsEpoc(recentExpiry),
                    hasRegistration: DateProvider_1.DateProvider.isValidDate(VehicleTestController_1.getRegistrationOrFirstUseDate(payload)),
                };
                console.log("testTypeForExpiry");
                console.log(testTypeForExpiry);
                const strategy = this.getExpiryStrategy(testTypeForExpiry);
                console.log(strategy.constructor.name);
                testType.testExpiryDate = strategy.getExpiryDate();
            });
            console.log("generateExpiryDate: testTypes ->", payload.testTypes);
            return Promise.resolve(payload);
        }
        catch (error) {
            console.error("Error in error generateExpiryDate", error);
            throw new models.HTTPError(500, enums.MESSAGES.INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * This function will not remove the certificate number on the test types which already have it set
     */
    static AssignCertificateNumberToTestTypes(payload) {
        if (payload.testStatus !== enums.TEST_STATUS.SUBMITTED) {
            return payload;
        }
        payload.testTypes.forEach((testType) => {
            if (this.shouldGenerateCertificateNumber(testType, payload.vehicleType)) {
                testType.certificateNumber = testType.testNumber;
            }
        });
        return payload;
    }
    static calculateAnniversaryDate(payload) {
        const { vehicleType } = payload;
        payload.testTypes.forEach((testType) => {
            const { testExpiryDate } = testType;
            if (!testExpiryDate) {
                return;
            }
            testType.testAnniversaryDate =
                vehicleType === enums.VEHICLE_TYPES.PSV
                    ? DateProvider_1.DateProvider.getPsvAnniversaryDate(testExpiryDate)
                    : testExpiryDate;
        });
        return payload;
    }
    static getRegistrationOrFirstUseDate(payload) {
        return payload.vehicleType === enums.VEHICLE_TYPES.TRL
            ? payload.firstUseDate
            : payload.regnDate;
    }
    static shouldGenerateCertificateNumber(testType, vehicleType) {
        if (testType.testTypeClassification ===
            enums.TEST_TYPE_CLASSIFICATION.ANNUAL_WITH_CERTIFICATE &&
            testType.testResult !== enums.TEST_RESULT.ABANDONED) {
            if (utils.ValidationUtil.isTestTypeAdr(testType) ||
                utils.ValidationUtil.isTestTypeLec(testType)) {
                return false;
            }
            if (utils.ValidationUtil.isHGVTRLRoadworthinessTest(testType.testTypeId)) {
                return (utils.ValidationUtil.isHgvOrTrl(vehicleType) &&
                    testType.testResult !== enums.TEST_RESULT.FAIL);
            }
            return true;
        }
        return false;
    }
};
VehicleTestController = VehicleTestController_1 = __decorate([
    ServiceDecorator_1.Service(),
    __metadata("design:paramtypes", [TestDataProvider_1.TestDataProvider,
        DateProvider_1.DateProvider])
], VehicleTestController);
exports.VehicleTestController = VehicleTestController;
