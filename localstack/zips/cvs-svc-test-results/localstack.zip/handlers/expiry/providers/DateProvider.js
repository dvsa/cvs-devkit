"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var DateProvider_1;
Object.defineProperty(exports, "__esModule", { value: true });
const moment_timezone_1 = __importDefault(require("moment-timezone"));
const ServiceDecorator_1 = require("../../../models/injector/ServiceDecorator");
/**
 * Important: The local timezone in AWS lambda is GMT for all the regions.
 * dateFns only uses local timezones and therefore generates different hours when running locally or deployed in AWS.
 *
 * new Date(string) considers the ambiguous parsed string as UTC
 * new Date() creates a new date based on the local timezone
 */
let DateProvider = DateProvider_1 = class DateProvider {
    constructor() {
        this.testDate = moment_timezone_1.default(new Date()).startOf("day").toDate();
        moment_timezone_1.default.tz.setDefault("UTC");
    }
    getTestDate() {
        return this.testDate;
    }
    setTestDate(date) {
        this.testDate = moment_timezone_1.default(date).startOf("day").toDate();
    }
    //#region Static Functions
    static getEpoc() {
        return moment_timezone_1.default(new Date(0)).startOf("day").toDate();
    }
    static isSameAsEpoc(inputDate) {
        return moment_timezone_1.default(inputDate).isSame(DateProvider_1.getEpoc());
    }
    /**
     * Fetch end of date for the provided date.
     * @param inputDate The date for which end of day is needed. Default is today.
     */
    static getEndOfDay(inputDate = new Date()) {
        return moment_timezone_1.default(inputDate).endOf("day").toDate();
    }
    static getTwoYearsFromDate(inputDate) {
        return moment_timezone_1.default(inputDate).subtract(2, "years").endOf("day").toDate();
    }
    static getInstance(dateValue) {
        return moment_timezone_1.default(dateValue);
    }
    static getMaxDate(arrayOfDates) {
        return moment_timezone_1.default.max(arrayOfDates).toDate();
    }
    static getPsvAnniversaryDate(testExpiryDate) {
        return moment_timezone_1.default(testExpiryDate)
            .utc()
            .subtract(2, "months")
            .add(1, "days")
            .toISOString();
    }
    /**
     * To validate whether provided input is a date. "undefined" is validated separately because moment(undefined) = new Date(). Strict validation is performed and only two date formats are acceptable YYYY-MM-DD and YYYY-MM-DDTHH:mm:ss.SSSZ.
     * @param input The input value which is validated.
     */
    static isValidDate(input) {
        return (input !== undefined &&
            (moment_timezone_1.default(input, "YYYY-MM-DDTHH:mm:ss.SSSSSSZ", true).isValid() || // Legacy format
                moment_timezone_1.default(input, "YYYY-MM-DDTHH:mm:ss.SSSZ", true).isValid() || //  Test result API format
                moment_timezone_1.default(input, "YYYY-MM-DD", true).isValid()) && // Tech Record dates e.g. regnDate
            moment_timezone_1.default(input).isAfter(new Date(0)));
    }
    /**
     * To compare whether input date is between two months of compare date. Inlcusivty parameter represents start and end of month.
     * @param inputDate the input date.
     * @param compareDate the date to compare with.
     * @param inclusivity []= start and end included, ()= start and end excluded, [)= start included end excluded, (]= start excluded and end included.
     */
    static isBetweenTwoMonths(inputDate, compareDate, inclusivity) {
        console.log(`compareDate+2 months: ${moment_timezone_1.default(compareDate)
            .add(2, "months")
            .toISOString()}`);
        return moment_timezone_1.default(inputDate).isBetween(moment_timezone_1.default(compareDate), moment_timezone_1.default(compareDate).add(2, "months"), "days", inclusivity);
    }
    /**
     * To compare whether dates fall between a comparison period.
     * @param fromDate the input from Date
     * @param toDate the input to date
     * @param compareFromDate the compare from Date
     * @param compareToDate the compare to Date
     */
    static isBetweenDates(fromDate, toDate, compareFromDate, compareToDate) {
        return (moment_timezone_1.default(fromDate).isAfter(compareFromDate) &&
            moment_timezone_1.default(toDate).isBefore(compareToDate));
    }
    static addOneYear(inputDate) {
        return moment_timezone_1.default(inputDate).add(1, "years").startOf("day").toDate();
    }
    static addOneYearEndOfMonth(inputDate) {
        return moment_timezone_1.default(inputDate)
            .add(1, "year")
            .endOf("month")
            .startOf("day")
            .toDate();
    }
    static getEndOfMonth(inputDate) {
        return moment_timezone_1.default(inputDate).endOf("month").startOf("day").toDate();
    }
    static addOneYearISOString(inputDate) {
        return moment_timezone_1.default(inputDate).add(1, "years").toISOString();
    }
    static addOneYearStartOfDayISOString(inputDate) {
        return moment_timezone_1.default(inputDate).add(1, "year").startOf("day").toISOString();
    }
    static addOneYearMinusOneDayISOString(inputDate) {
        return moment_timezone_1.default(inputDate)
            .add(1, "year")
            .subtract(1, "day")
            .startOf("day")
            .toISOString();
    }
    static getLastDayOfMonthInNextYearISOString(inputDate) {
        return moment_timezone_1.default(inputDate)
            .add(1, "year")
            .endOf("month")
            .startOf("day")
            .toISOString();
    }
};
DateProvider = DateProvider_1 = __decorate([
    ServiceDecorator_1.Service(),
    __metadata("design:paramtypes", [])
], DateProvider);
exports.DateProvider = DateProvider;
