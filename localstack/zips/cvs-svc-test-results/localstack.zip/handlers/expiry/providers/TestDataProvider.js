"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
var TestDataProvider_1;
Object.defineProperty(exports, "__esModule", { value: true });
const ServiceDecorator_1 = require("../../../models/injector/ServiceDecorator");
const enums = __importStar(require("../../../assets/Enums"));
const utils = __importStar(require("../../../utils"));
const DateProvider_1 = require("./DateProvider");
let TestDataProvider = TestDataProvider_1 = class TestDataProvider {
    //#region [rgba(52, 152, 219, 0.15)] Public functions
    /**
     * To fetch test results by systemNumber
     * @param filters filters used to search the database
     */
    async getTestResultBySystemNumber(filters) {
        try {
            this.testResultsDAO = this.testResultsDAO;
            const { Count, Items } = await this.testResultsDAO.getBySystemNumber(filters.systemNumber);
            const response = {
                Count,
                Items,
            };
            const testResults = utils.ValidationUtil.getTestResultItems(response);
            return TestDataProvider_1.applyTestResultsFilters(testResults, filters);
        }
        catch (error) {
            console.error("TestDataProvider.getTestResultBySystemNumber: error-> ", error);
            throw error;
        }
    }
    async getTestResultByTesterStaffId(filters) {
        try {
            this.testResultsDAO = this.testResultsDAO;
            const result = await this.testResultsDAO.getByTesterStaffId(filters.testerStaffId);
            if (result && !result.length) {
                return result;
            }
            return TestDataProvider_1.applyTestResultsFilters(result, filters);
        }
        catch (error) {
            console.error("TestDataProvider.getTestResultBySystemNumber: error-> ", error);
            throw error;
        }
    }
    async getTestHistory(systemNumber) {
        const fromDateTime = new Date(1970, 1, 1);
        const toDateTime = new Date();
        let result = [];
        try {
            this.testResultsDAO = this.testResultsDAO;
            const data = await this.testResultsDAO.getBySystemNumber(systemNumber);
            console.log(`getTestHistory: Data Count -> ${data === null || data === void 0 ? void 0 : data.Count}`);
            if (!(data === null || data === void 0 ? void 0 : data.Count)) {
                return result;
            }
            result = data.Items;
            return result
                .filter((test) => test.testStatus === enums.TEST_STATUS.SUBMITTED)
                .filter((testResult) => {
                const { testStartTimestamp, testEndTimestamp } = testResult;
                if (!DateProvider_1.DateProvider.isValidDate(testStartTimestamp) ||
                    !DateProvider_1.DateProvider.isValidDate(testEndTimestamp)) {
                    console.warn(`getTestHistory: Invalid timestamp -> systemNumber: ${systemNumber}  testStartTimestamp: ${testStartTimestamp} testEndTimestamp: ${testEndTimestamp}`);
                }
                return DateProvider_1.DateProvider.isBetweenDates(testStartTimestamp, testEndTimestamp, fromDateTime, toDateTime);
            });
        }
        catch (error) {
            console.log("TestDataProvider.getTestHistory: error -> ", error);
            throw error;
        }
    }
    async getMostRecentExpiryDate(systemNumber) {
        let maxDate = DateProvider_1.DateProvider.getEpoc();
        const testResults = await this.getTestHistory(systemNumber);
        console.log(`getMostRecentExpiryDate: Filtered Data Count -> ${testResults === null || testResults === void 0 ? void 0 : testResults.length}`);
        const filteredTestTypeDates = [];
        testResults.forEach(({ testTypes }) => {
            testTypes.forEach(({ testCode, testExpiryDate }) => {
                if (testCode &&
                    TestDataProvider_1.isValidTestCodeForExpiryCalculation(testCode.toUpperCase()) &&
                    testExpiryDate &&
                    DateProvider_1.DateProvider.isValidDate(testExpiryDate)) {
                    console.log(`getMostRecentExpiryDate: Filtered Date -> ${testExpiryDate}`);
                    filteredTestTypeDates.push(DateProvider_1.DateProvider.getInstance(testExpiryDate));
                }
                if (testExpiryDate && !DateProvider_1.DateProvider.isValidDate(testExpiryDate)) {
                    console.warn(`getMostRecentExpiryDate: Invalid Expiry Date -> systemNumber: ${systemNumber} testExpiryDate: ${testExpiryDate}`);
                }
            });
            if (filteredTestTypeDates.length) {
                maxDate = DateProvider_1.DateProvider.getMaxDate(filteredTestTypeDates);
            }
        });
        console.log(`getMostRecentExpiryDate: Max Date -> ${maxDate.toString()}`);
        return maxDate;
    }
    static isValidTestCodeForExpiryCalculation(testCode) {
        return enums.TEST_CODES_FOR_CALCULATING_EXPIRY.CODES.includes(testCode);
    }
    static applyTestResultsFilters(testResults, filters) {
        const { fromDateTime, toDateTime, testStatus, testStationPNumber, testResultId, testVersion, } = filters;
        testResults = this.filterTestResultsByDeletionFlag(testResults);
        testResults = this.filterTestTypesByDeletionFlag(testResults);
        testResults = TestDataProvider_1.filterTestResultByDate(testResults, fromDateTime, toDateTime);
        testResults = this.filterTestResultsByParam(testResults, "testStatus", testStatus);
        testResults = this.filterTestResultsByParam(testResults, "testStationPNumber", testStationPNumber);
        if (!testResultId) {
            testResults = this.filterTestResultsByTestVersion(testResults, enums.TEST_VERSION.CURRENT);
            testResults = this.removeTestHistory(testResults);
            return testResults;
        }
        testResults = this.filterTestResultsByParam(testResults, "testResultId", testResultId);
        testResults = this.filterTestResultsByTestVersion(testResults, testVersion);
        return testResults;
    }
    async getTestTypesWithTestCodesAndClassification(testTypes = [], testTypeParams) {
        return await this.createNewTestTypes(testTypes, testTypeParams);
    }
    async createNewTestTypes(list, params) {
        return await Promise.all(list.map(utils.MappingUtil.addTestcodeToTestTypes(this.testResultsDAO, params)));
    }
    async setTestNumberForEachTestType(payload) {
        const { testTypes } = payload;
        if (!testTypes) {
            return payload;
        }
        return await this.createNewTestNumber(testTypes);
    }
    async createNewTestNumber(list) {
        return await Promise.all(list.map(utils.MappingUtil.addTestNumberToTestTypes(this.testResultsDAO)));
    }
    async insertTestResult(payload) {
        this.testResultsDAO = this.testResultsDAO;
        try {
            const result = await this.testResultsDAO.createSingle(payload);
            utils.LoggingUtil.logDefectsReporting(payload);
            return result.Attributes;
        }
        catch (error) {
            console.error("TestDataProvider.insertTestResult -> ", error);
            throw error;
        }
    }
    //#endregion
    //#region [rgba(0, 205, 30, 0.1)] Private Static functions
    static filterTestResultsByParam(testResults, filterName, filterValue) {
        return filterValue
            ? testResults.filter((testResult) => {
                const k = filterName;
                return testResult[k] === filterValue;
            })
            : testResults;
    }
    static filterTestResultByDate(testResults, fromDateTime, toDateTime) {
        return testResults.filter((testResult) => DateProvider_1.DateProvider.isBetweenDates(testResult.testStartTimestamp, testResult.testEndTimestamp, fromDateTime, toDateTime));
    }
    static filterTestResultsByTestVersion(testResults, testVersion = enums.TEST_VERSION.CURRENT) {
        let result = [];
        if (testVersion === enums.TEST_VERSION.ALL) {
            return testResults;
        }
        for (const testResult of testResults) {
            if (testVersion === enums.TEST_VERSION.CURRENT &&
                (testResult.testVersion === enums.TEST_VERSION.CURRENT ||
                    !testResult.testVersion)) {
                delete testResult.testHistory;
                result.push(testResult);
            }
            else if (testVersion === enums.TEST_VERSION.ARCHIVED) {
                if (testResult.testVersion === enums.TEST_VERSION.ARCHIVED) {
                    result.push(testResult);
                    if (testResult.testHistory) {
                        result = result.concat(testResult.testHistory);
                        delete testResult.testHistory;
                    }
                }
                else {
                    result = testResult.testHistory || [];
                }
            }
        }
        return result;
    }
    static removeTestHistory(testResults) {
        for (const testResult of testResults) {
            delete testResult.testHistory;
        }
        return testResults;
    }
    static filterTestResultsByDeletionFlag(testResults) {
        return testResults.filter((testResult) => {
            return !testResult.deletionFlag === true;
        });
    }
    static filterTestTypesByDeletionFlag(testResults) {
        testResults.forEach((testResult) => {
            const filteredTestTypes = testResult.testTypes.filter((testType) => {
                return !testType.deletionFlag === true;
            });
            testResult.testTypes = filteredTestTypes;
        });
        return testResults;
    }
};
TestDataProvider = TestDataProvider_1 = __decorate([
    ServiceDecorator_1.Service()
], TestDataProvider);
exports.TestDataProvider = TestDataProvider;
