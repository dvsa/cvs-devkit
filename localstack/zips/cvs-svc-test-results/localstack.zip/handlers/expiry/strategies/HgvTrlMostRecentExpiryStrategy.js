"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DateProvider_1 = require("../providers/DateProvider");
class HgvTrlMostRecentExpiryStrategy {
    constructor(testTypeForExpiry, dateProvider) {
        this.testTypeForExpiry = testTypeForExpiry;
        this.dateProvider = dateProvider;
    }
    getExpiryDate() {
        const { recentExpiry } = this.testTypeForExpiry;
        const monthOfMostRecentExpiryDate = DateProvider_1.DateProvider.getEndOfMonth(recentExpiry);
        const testDate = this.dateProvider.getTestDate();
        console.log(`recentExpiry: ${recentExpiry}`);
        console.log(`testDate: ${testDate}`);
        if (DateProvider_1.DateProvider.isBetweenTwoMonths(monthOfMostRecentExpiryDate, testDate, "[)")) {
            return DateProvider_1.DateProvider.getLastDayOfMonthInNextYearISOString(recentExpiry);
        }
        return DateProvider_1.DateProvider.getLastDayOfMonthInNextYearISOString(testDate);
    }
}
exports.HgvTrlMostRecentExpiryStrategy = HgvTrlMostRecentExpiryStrategy;
