"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DateProvider_1 = require("../providers/DateProvider");
class PsvRegistrationAnniversaryStrategy {
    constructor(testTypeForExpiry, dateProvider) {
        this.testTypeForExpiry = testTypeForExpiry;
        this.dateProvider = dateProvider;
    }
    getExpiryDate() {
        const { regnOrFirstUseDate } = this.testTypeForExpiry;
        const registrationAnniversary = DateProvider_1.DateProvider.addOneYear(regnOrFirstUseDate);
        const testDate = this.dateProvider.getTestDate();
        console.log(`registrationAnniversary: ${registrationAnniversary}`);
        console.log(`testDate: ${testDate}`);
        if (DateProvider_1.DateProvider.isBetweenTwoMonths(registrationAnniversary, testDate, "[)")) {
            return DateProvider_1.DateProvider.addOneYearISOString(registrationAnniversary);
        }
        return DateProvider_1.DateProvider.addOneYearMinusOneDayISOString(testDate);
    }
}
exports.PsvRegistrationAnniversaryStrategy = PsvRegistrationAnniversaryStrategy;
