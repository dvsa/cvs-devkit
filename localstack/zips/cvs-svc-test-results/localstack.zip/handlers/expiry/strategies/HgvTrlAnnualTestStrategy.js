"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DateProvider_1 = require("../providers/DateProvider");
class HgvTrlAnnualTestStrategy {
    constructor(testTypeForExpiry, dateProvider) {
        this.testTypeForExpiry = testTypeForExpiry;
        this.dateProvider = dateProvider;
    }
    getExpiryDate() {
        const { regnOrFirstUseDate } = this.testTypeForExpiry;
        const isValidRegn = DateProvider_1.DateProvider.isValidDate(regnOrFirstUseDate);
        const testDate = this.dateProvider.getTestDate();
        const regnAnniversary = DateProvider_1.DateProvider.addOneYearEndOfMonth(regnOrFirstUseDate);
        console.log(`regnOrFirstUseDate: ${regnOrFirstUseDate}`);
        console.log(`regnAnniversary: ${regnAnniversary}`);
        console.log(`testDate: ${testDate}`);
        if (isValidRegn && DateProvider_1.DateProvider.isBetweenTwoMonths(regnAnniversary, testDate, "()")) {
            return DateProvider_1.DateProvider.getLastDayOfMonthInNextYearISOString(regnAnniversary);
        }
        return DateProvider_1.DateProvider.getLastDayOfMonthInNextYearISOString(testDate);
    }
}
exports.HgvTrlAnnualTestStrategy = HgvTrlAnnualTestStrategy;
