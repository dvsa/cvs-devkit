"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class NoImplementationStrategy {
    constructor(testTypeForExpiry, dateProvider) {
        this.testTypeForExpiry = testTypeForExpiry;
        this.dateProvider = dateProvider;
    }
    getExpiryDate() {
        throw new Error("Method not implemented.");
    }
}
exports.NoImplementationStrategy = NoImplementationStrategy;
