"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DateProvider_1 = require("../providers/DateProvider");
class PsvDefaultExpiryStrategy {
    constructor(testTypeForExpiry, dateProvider) {
        this.testTypeForExpiry = testTypeForExpiry;
        this.dateProvider = dateProvider;
    }
    getExpiryDate() {
        return DateProvider_1.DateProvider.addOneYearMinusOneDayISOString(this.dateProvider.getTestDate());
    }
}
exports.PsvDefaultExpiryStrategy = PsvDefaultExpiryStrategy;
