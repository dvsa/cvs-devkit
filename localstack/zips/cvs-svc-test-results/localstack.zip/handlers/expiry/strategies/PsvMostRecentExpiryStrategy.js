"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const DateProvider_1 = require("../providers/DateProvider");
class PsvMostRecentExpiryStrategy {
    constructor(testTypeForExpiry, dateProvider) {
        this.testTypeForExpiry = testTypeForExpiry;
        this.dateProvider = dateProvider;
    }
    getExpiryDate() {
        const { recentExpiry } = this.testTypeForExpiry;
        const testDate = this.dateProvider.getTestDate();
        console.log(`recentExpiry: ${recentExpiry}`);
        console.log(`testDate: ${testDate}`);
        if (DateProvider_1.DateProvider.isBetweenTwoMonths(recentExpiry, testDate, "[)")) {
            return DateProvider_1.DateProvider.addOneYearISOString(recentExpiry);
        }
        return DateProvider_1.DateProvider.addOneYearMinusOneDayISOString(testDate);
    }
}
exports.PsvMostRecentExpiryStrategy = PsvMostRecentExpiryStrategy;
