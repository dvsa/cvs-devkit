"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const Enums_1 = require("../../assets/Enums");
const strategy_mapping_json_1 = __importDefault(require("../../assets/strategy-mapping.json"));
const NoImplementationStrategy_1 = require("./strategies/NoImplementationStrategy");
const PsvDefaultExpiryStrategy_1 = require("./strategies/PsvDefaultExpiryStrategy");
const PsvMostRecentExpiryStrategy_1 = require("./strategies/PsvMostRecentExpiryStrategy");
const PsvRegistrationAnniversaryStrategy_1 = require("./strategies/PsvRegistrationAnniversaryStrategy");
const HgvTrlAnnualTestStrategy_1 = require("./strategies/HgvTrlAnnualTestStrategy");
const HgvTrlMostRecentExpiryStrategy_1 = require("./strategies/HgvTrlMostRecentExpiryStrategy");
const HgvTrlFirstTestStrategy_1 = require("./strategies/HgvTrlFirstTestStrategy");
class ExpiryDateStrategyFactory {
    static GetExpiryStrategy(testTypeForExpiry, dateProvider) {
        let strategiesFound = 0;
        let selectedStrategy = new NoImplementationStrategy_1.NoImplementationStrategy(testTypeForExpiry, dateProvider);
        const vehicleConfig = ExpiryDateStrategyFactory.getStrategyMapping(testTypeForExpiry.vehicleType, strategy_mapping_json_1.default);
        vehicleConfig.forEach((config) => {
            const { hasRegistration, hasHistory } = testTypeForExpiry;
            const { isHistoryRequired, isRegistrationRequired, strategy } = config;
            if (this.isEqualOrNull(hasHistory, isHistoryRequired) &&
                this.isEqualOrNull(hasRegistration, isRegistrationRequired) &&
                config.testTypes.includes(testTypeForExpiry.testType.testTypeId)) {
                selectedStrategy = this.createStrategy(strategy, testTypeForExpiry, dateProvider);
                strategiesFound++;
            }
        });
        if (strategiesFound > 1) {
            throw new Error("Multiple strategies found!");
        }
        return selectedStrategy;
    }
    static isEqualOrNull(input, config) {
        // if input or config does not exist then don't compare
        if (config === null) {
            return true;
        }
        else {
            return input === config;
        }
    }
    static createStrategy(strategy, testTypeForExpiry, dateProvider) {
        switch (strategy) {
            case Enums_1.EXPIRY_STRATEGY.PSV_DEFAULT:
                return new PsvDefaultExpiryStrategy_1.PsvDefaultExpiryStrategy(testTypeForExpiry, dateProvider);
            case Enums_1.EXPIRY_STRATEGY.PSV_MOST_RECENT:
                return new PsvMostRecentExpiryStrategy_1.PsvMostRecentExpiryStrategy(testTypeForExpiry, dateProvider);
            case Enums_1.EXPIRY_STRATEGY.PSV_REGN_ANNIVERSARY:
                return new PsvRegistrationAnniversaryStrategy_1.PsvRegistrationAnniversaryStrategy(testTypeForExpiry, dateProvider);
            case Enums_1.EXPIRY_STRATEGY.HGV_TRL_FIRST_TEST:
                return new HgvTrlFirstTestStrategy_1.HgvTrlFirstTestStrategy(testTypeForExpiry, dateProvider);
            case Enums_1.EXPIRY_STRATEGY.HGV_TRL_ANNUAL_TEST:
                return new HgvTrlAnnualTestStrategy_1.HgvTrlAnnualTestStrategy(testTypeForExpiry, dateProvider);
            case Enums_1.EXPIRY_STRATEGY.HGV_TRL_MOST_RECENT:
                return new HgvTrlMostRecentExpiryStrategy_1.HgvTrlMostRecentExpiryStrategy(testTypeForExpiry, dateProvider);
            default:
                return new NoImplementationStrategy_1.NoImplementationStrategy(testTypeForExpiry, dateProvider);
        }
    }
    static getStrategyMapping(vehicleType, expiryConfig) {
        const vehicleConfig = expiryConfig[vehicleType];
        if (!(vehicleConfig && vehicleConfig.length)) {
            throw new Error(Enums_1.ERRORS.ExpiryConfigMissing);
        }
        return vehicleConfig;
    }
}
exports.ExpiryDateStrategyFactory = ExpiryDateStrategyFactory;
